// 1. Gắn cờ báo hiệu cho trang web biết: "Cán bộ máy này ĐÃ CÀI Extension nhé!"
document.documentElement.setAttribute('data-extension-installed', 'true');

// 2. Lắng nghe tiếng hét "YeuCauMoAnDanh" từ hàm openNopHo của trang web
function handleYeuCauMoAnDanh(e) {
    let targetUrl = e.detail.url;
    
    if (targetUrl) {
        try {
            // Kiểm tra xem extension context còn hiệu lực hay không
            if (!chrome.runtime || !chrome.runtime.id) {
                throw new Error("Extension context invalidated.");
            }
            // Bắn thông tin về cho não bộ của Extension xử lý
            chrome.runtime.sendMessage({ action: "openIncognito", url: targetUrl });
        } catch (error) {
            console.warn("[Trợ lý Nộp Hộ] Extension context bị vô hiệu hóa (có thể do extension đã reload hoặc cập nhật). Đang dọn dẹp...", error);
            
            // Gỡ bỏ cờ báo hiệu trên trang web để báo cho ứng dụng Web biết extension không còn hoạt động
            document.documentElement.removeAttribute('data-extension-installed');
            
            // Hủy đăng ký lắng nghe sự kiện để tránh lỗi tiếp theo
            document.removeEventListener("YeuCauMoAnDanh", handleYeuCauMoAnDanh);
            
            // Thông báo thân thiện cho người dùng
            alert("Extension Trợ lý Nộp Hộ đã được cập nhật hoặc tải lại.\n\nVui lòng tải lại trang web (nhấn F5) để tiếp tục sử dụng chế độ ẩn danh.");
        }
    }
}

document.addEventListener("YeuCauMoAnDanh", handleYeuCauMoAnDanh);
// popup.js - Popup logic for DVCQG Auto Sync & Review
'use strict';

document.addEventListener('DOMContentLoaded', async () => {
  const btnDvcqg = document.getElementById('btn-open-dvcqg');
  const btnRasoat = document.getElementById('btn-open-rasoat');
  const prefAutoTransfer = document.getElementById('pref-autotransfer');
  const prefAdaptiveSpeed = document.getElementById('pref-adaptive-speed');

  // Load existing config
  const { dvcqg_config } = await chrome.storage.local.get('dvcqg_config');
  if (dvcqg_config) {
    if (typeof dvcqg_config.autoTransfer === 'boolean' && prefAutoTransfer) {
      prefAutoTransfer.checked = dvcqg_config.autoTransfer;
    }
    if (typeof dvcqg_config.adaptiveSpeed === 'boolean' && prefAdaptiveSpeed) {
      prefAdaptiveSpeed.checked = dvcqg_config.adaptiveSpeed;
    }
  }

  // Save config on change
  if (prefAutoTransfer) {
    prefAutoTransfer.addEventListener('change', async (e) => {
      const res = await chrome.storage.local.get('dvcqg_config');
      const config = res.dvcqg_config || {};
      config.autoTransfer = e.target.checked;
      await chrome.storage.local.set({ dvcqg_config: config });
    });
  }

  if (prefAdaptiveSpeed) {
    prefAdaptiveSpeed.addEventListener('change', async (e) => {
      const res = await chrome.storage.local.get('dvcqg_config');
      const config = res.dvcqg_config || {};
      config.adaptiveSpeed = e.target.checked;
      await chrome.storage.local.set({ dvcqg_config: config });
    });
  }

  // Navigate to DVCQG
  btnDvcqg.addEventListener('click', async () => {
    const url = 'https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo';
    const tabs = await chrome.tabs.query({ url: `${url}*` });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    } else {
      await chrome.tabs.create({ url, active: true });
    }
    window.close();
  });

  // Navigate to Rasoat
  btnRasoat.addEventListener('click', async () => {
    const url = 'https://cdn.dnncloud.net/tthc/rasoat.html';
    const tabs = await chrome.tabs.query({ url: `${url}*` });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    } else {
      await chrome.tabs.create({ url, active: true });
    }
    window.close();
  });
});

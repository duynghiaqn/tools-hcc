// rasoat-content.js - Content script for https://cdn.dnncloud.net/tthc/rasoat.html
(function () {
  'use strict';

  console.log('[DVCQG Auto Rasoat] Content script loaded on rasoat.html');

  let isProcessing = false;

  // Listen for direct messages from background script
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'FILL_AND_ANALYZE') {
      console.log('[DVCQG Auto Rasoat] Received FILL_AND_ANALYZE message:', message.data);
      processIncomingData(message.data);
      sendResponse({ received: true });
    }
    return true;
  });

  // Check pending or last extracted data on page load
  async function checkPendingData() {
    try {
      // 1. Check pending transfer data
      const { pending_rasoat_data } = await chrome.storage.local.get('pending_rasoat_data');
      if (pending_rasoat_data && pending_rasoat_data.xml) {
        const ageMs = Date.now() - (pending_rasoat_data.timestamp || 0);
        // Process if created within the last 15 minutes
        if (ageMs < 15 * 60 * 1000) {
          console.log('[DVCQG Auto Rasoat] Found pending data in storage:', pending_rasoat_data);
          await processIncomingData(pending_rasoat_data);
          return;
        }
      }

      // 2. Check last extracted data if textarea is currently empty
      const srcEl = document.querySelector('#src');
      if (srcEl && !srcEl.value.trim()) {
        const { last_extracted_xml } = await chrome.storage.local.get('last_extracted_xml');
        if (last_extracted_xml && last_extracted_xml.xml) {
          const ageMs = Date.now() - (last_extracted_xml.timestamp || 0);
          if (ageMs < 15 * 60 * 1000) {
            console.log('[DVCQG Auto Rasoat] Auto-pasting last extracted data into empty form:', last_extracted_xml);
            await processIncomingData(last_extracted_xml);
          }
        }
      }
    } catch (e) {
      console.warn('[DVCQG Auto Rasoat] Error checking storage:', e);
    }
  }

  // Wait for elements to appear in the DOM
  function waitForElement(selector, timeoutMs = 8000) {
    return new Promise((resolve) => {
      const existing = document.querySelector(selector);
      if (existing) return resolve(existing);

      const observer = new MutationObserver(() => {
        const el = document.querySelector(selector);
        if (el) {
          observer.disconnect();
          resolve(el);
        }
      });

      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
      });

      setTimeout(() => {
        observer.disconnect();
        resolve(document.querySelector(selector));
      }, timeoutMs);
    });
  }

  // Robustly paste value into textarea ensuring all framework/vanilla event listeners catch it
  function setAndPasteTextarea(textarea, text) {
    if (!textarea) return;

    // Use native prototype setter to bypass any framework wrappers
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(textarea, text);
    }
    textarea.value = text;

    textarea.focus();

    // Dispatch input & change
    textarea.dispatchEvent(new Event('focus', { bubbles: true }));
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));

    // Dispatch paste event with real DataTransfer payload to prevent null pointer exceptions
    try {
      const dt = new DataTransfer();
      dt.setData('text/plain', text);
      dt.setData('text', text);
      const pasteEvt = new ClipboardEvent('paste', {
        clipboardData: dt,
        bubbles: true,
        cancelable: true
      });
      textarea.dispatchEvent(pasteEvt);
    } catch (e) {
      textarea.dispatchEvent(new Event('paste', { bubbles: true }));
    }
  }

  // Khôi phục và bảo toàn &amp; chuẩn W3C XML, chống lỗi unescaped & khi nạp vào trang rà soát
  function restoreXmlAmpersands(xml) {
    if (!xml || typeof xml !== 'string') return '';
    let res = xml.replace(/&amp;amp;/g, '&amp;');
    res = res.replace(/&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)/gi, '&amp;');
    return res;
  }

  // Process data: fill textarea, dates, and trigger analysis
  async function processIncomingData(data) {
    if (isProcessing || !data || !data.xml) return;
    isProcessing = true;

    try {
      const rawXml = data.xml;
      const cleanXml = typeof rawXml === 'string' ? restoreXmlAmpersands(rawXml.replace(/^\uFEFF/, '').trim()) : '';
      const { maHoSo, fromDate, toDate } = data;

      if (!cleanXml) {
        showToast('Lỗi dữ liệu', 'Dữ liệu XML trống hoặc không hợp lệ!');
        return;
      }

      // 1. Wait for textarea #src & analyze button #go
      const srcEl = await waitForElement('#src');
      const goBtn = await waitForElement('#go');

      if (!srcEl) {
        showToast('Lỗi nạp dữ liệu', 'Không tìm thấy ô nhập dữ liệu (#src) trên trang!');
        return;
      }

      // Wait a short moment if page scripts are still initializing
      let scriptReadyTries = 0;
      while (scriptReadyTries < 15 && (!goBtn || typeof goBtn.onclick !== 'function')) {
        await new Promise(r => setTimeout(r, 100));
        scriptReadyTries++;
      }

      // 1b. TỰ ĐỘNG XÓA DỮ LIỆU CŨ TRƯỚC KHI NẠP DỮ LIỆU MỚI VÀ PHÂN TÍCH
      console.log('[DVCQG Auto Rasoat] Tự động xóa dữ liệu cũ trước khi nạp dữ liệu mới và phân tích...');
      const resetBtn = document.querySelector('#reset, #btn-reset, #clear, button[type="reset"], button.btn-reset, button.btn-clear');
      if (resetBtn) {
        try { resetBtn.click(); } catch (e) {}
      }

      // Xóa sạch ô nhập dữ liệu cũ #src
      setAndPasteTextarea(srcEl, '');
      srcEl.value = '';
      srcEl.dispatchEvent(new Event('input', { bubbles: true }));
      srcEl.dispatchEvent(new Event('change', { bubbles: true }));

      // Xóa ngày cũ trên form nếu có
      const oldPf = document.querySelector('#pf');
      const oldPt = document.querySelector('#pt');
      if (oldPf) { oldPf.value = ''; oldPf.dispatchEvent(new Event('change', { bubbles: true })); }
      if (oldPt) { oldPt.value = ''; oldPt.dispatchEvent(new Event('change', { bubbles: true })); }

      // Ẩn vùng kết quả phân tích cũ nếu có
      const oldRes = document.querySelector('#res');
      if (oldRes) oldRes.classList.add('hidden');
      const oldAna = document.querySelector('#ana');
      if (oldAna) oldAna.classList.add('hidden');

      await new Promise(r => setTimeout(r, 100)); // Chờ form sạch hoàn toàn

      console.log('[DVCQG Auto Rasoat] Tự động dán dữ liệu XML vào form (#src)...');

      // Robust auto-paste into textarea
      setAndPasteTextarea(srcEl, cleanXml);

      // Verify that value was successfully received
      if (srcEl.value.trim().length === 0) {
        srcEl.value = cleanXml;
        srcEl.dispatchEvent(new Event('input', { bubbles: true }));
      }

      // Also copy to clipboard so user can easily paste elsewhere if desired
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(cleanXml).catch(() => {});
      }

      // 2. Fill dates if available
      if (fromDate) {
        const pfEl = document.querySelector('#pf');
        if (pfEl) {
          pfEl.value = fromDate;
          pfEl.dispatchEvent(new Event('change', { bubbles: true }));
          pfEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }

      if (toDate) {
        const ptEl = document.querySelector('#pt');
        if (ptEl) {
          ptEl.value = toDate;
          ptEl.dispatchEvent(new Event('change', { bubbles: true }));
          ptEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }

      // 3. Ensure "Gộp các khối cùng MaHoSo" is checked
      const mergeEl = document.querySelector('#merge');
      if (mergeEl && !mergeEl.checked) {
        mergeEl.checked = true;
        mergeEl.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // Wait 150ms before triggering analysis to allow page paste listener to settle
      await new Promise(r => setTimeout(r, 150));

      // 4. Click button "Phân tích" (#go)
      if (goBtn) {
        goBtn.click();
        console.log('[DVCQG Auto Rasoat] Đã kích hoạt nút #go (Phân tích).');
      }

      // 5. Verification check loop: ensure analysis completes successfully
      for (let attempt = 1; attempt <= 4; attempt++) {
        await new Promise(r => setTimeout(r, 600));
        const resEl = document.querySelector('#res');
        const anaEl = document.querySelector('#ana');
        const isSuccess = resEl && !resEl.classList.contains('hidden');
        const isAnalyzing = anaEl && !anaEl.classList.contains('hidden');

        if (isSuccess) {
          console.log('[DVCQG Auto Rasoat] Phân tích hoàn tất thành công!');
          await chrome.storage.local.remove('pending_rasoat_data');
          break;
        } else if (!isAnalyzing && goBtn) {
          console.log(`[DVCQG Auto Rasoat] Thử kích hoạt lại nút #go (lần ${attempt})...`);
          goBtn.click();
        }
      }

      // 6. Show celebratory toast
      const envelopeCount = (cleanXml.match(/<Envelope\b/gi) || []).length || 1;
      showToast(
        'Đã tự động dán dữ liệu thành công!',
        `Đã tự động paste ${envelopeCount} khối XML Envelope ${maHoSo ? `của hồ sơ <b>${maHoSo}</b>` : ''} vào form và hoàn tất phân tích.`
      );

    } catch (err) {
      console.error('[DVCQG Auto Rasoat] Error processing data:', err);
      showToast('Lỗi xử lý', err.message);
    } finally {
      isProcessing = false;
    }
  }

  // Display user toast notification
  function showToast(title, desc) {
    const old = document.getElementById('dvcqg-rasoat-toast');
    if (old) old.remove();

    const toast = document.createElement('div');
    toast.id = 'dvcqg-rasoat-toast';
    toast.innerHTML = `
      <div class="toast-icon">✓</div>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-desc">${desc}</div>
      </div>
      <button class="toast-close" title="Đóng">✕</button>
    `;

    document.body.appendChild(toast);

    toast.querySelector('.toast-close').addEventListener('click', () => toast.remove());

    setTimeout(() => {
      if (toast.isConnected) toast.remove();
    }, 8000);
  }

  // Add a handy floating "Dán dữ liệu" button on rasoat.html if user wants to re-paste anytime
  function addFloatingHelper() {
    if (document.getElementById('dvcqg-helper-paste')) return;

    const btn = document.createElement('button');
    btn.id = 'dvcqg-helper-paste';
    btn.type = 'button';
    btn.style.cssText = `
      position: fixed;
      bottom: 18px;
      left: 18px;
      z-index: 999999;
      background: #0b6e6e;
      color: #ffffff;
      border: none;
      border-radius: 8px;
      padding: 8px 14px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(11, 110, 110, 0.35);
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s;
    `;
    btn.innerHTML = `<span>📋 Tự động dán XML gần nhất</span>`;

    btn.addEventListener('click', async () => {
      btn.textContent = '⏳ Đang kiểm tra...';
      try {
        const { last_extracted_xml } = await chrome.storage.local.get('last_extracted_xml');
        if (last_extracted_xml && last_extracted_xml.xml) {
          await processIncomingData(last_extracted_xml);
          btn.innerHTML = `<span>✓ Đã dán thành công!</span>`;
        } else {
          // Try reading from system clipboard
          try {
            const clipText = await navigator.clipboard.readText();
            if (
              clipText &&
              clipText.includes('<Envelope') &&
              (clipText.includes('http://dichvucong.gov.vn/api/v1') ||
               clipText.includes('https://dichvucong.gov.vn/api/v1') ||
               clipText.includes('http://www.w3.org/2001/XMLSchema') ||
               clipText.includes('https://www.w3.org/2001/XMLSchema'))
            ) {
              await processIncomingData({ xml: clipText, maHoSo: 'Từ Clipboard' });
              btn.innerHTML = `<span>✓ Đã dán từ Clipboard!</span>`;
            } else {
              alert('Không tìm thấy dữ liệu XML nào được lưu gần đây hoặc trong Clipboard!');
              btn.innerHTML = `<span>📋 Tự động dán XML gần nhất</span>`;
            }
          } catch (e) {
            alert('Không tìm thấy dữ liệu XML nào được lưu gần đây!');
            btn.innerHTML = `<span>📋 Tự động dán XML gần nhất</span>`;
          }
        }
      } finally {
        setTimeout(() => {
          btn.innerHTML = `<span>📋 Tự động dán XML gần nhất</span>`;
        }, 3000);
      }
    });

    document.body.appendChild(btn);
  }

  // Initialize on page load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      checkPendingData();
      addFloatingHelper();
    });
  } else {
    checkPendingData();
    addFloatingHelper();
  }

})();

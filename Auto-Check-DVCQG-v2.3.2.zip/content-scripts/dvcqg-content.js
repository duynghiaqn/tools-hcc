// dvcqg-content.js - Content script for https://quantricong.dichvucong.gov.vn/*
(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__DVCQG_AUTO_INITIALIZED__) return;
  window.__DVCQG_AUTO_INITIALIZED__ = true;

  console.log('[DVCQG Auto] Content script loaded on', window.location.href);

  // URLs trang Rà soát DVCQG (Máy chủ chính & Dự phòng)
  const RASOAT_URL_PRIMARY = 'https://cdn.dnncloud.net/tthc/rasoat.html';
  const RASOAT_URL_GIALAI = 'https://hcc.gialai.gov.vn/tools/rasoat.html';

  // In-memory state
  const state = {
    isRunning: false,
    isStopping: false,
    extractedXmlBlocks: [], // Array of { status, xml, timestamp, maHoSo }
    capturedNetworkXml: [], // Captured via injected script
    lastExtractedCombined: '',
    networkActiveCount: 0, // Số request mạng đang active theo dõi từ injected script
    serverLatencyEstimate: 1000, // Ước tính độ trễ máy chủ DVCQG để tự thích ứng tốc độ
    config: {
      maHoSoListText: '', // Multi-line list of application codes
      fromDate: '',
      toDate: '',
      autoTransfer: true,
      rasoatUrl: RASOAT_URL_PRIMARY, // URL trang rà soát (Chính: cdn.dnncloud.net | Dự phòng: hcc.gialai.gov.vn | Tùy chỉnh)
      onlyCompleted: true, // Chỉ lấy các bản ghi có trạng thái COMPLETED hoặc SUCCESS (đặc biệt DongBoThongTinThanhToanDVC)
      smartDateSearch: true, // Automatically parse filing date from code and expand months until TraKetQuaBN
      searchDepthMonths: 3, // Độ sâu rà soát tối đa các tháng sau đó (mặc định 3 tháng)
      autoDetectToDateWithToday: true, // Tự động nhận dạng mục Đến ngày với ngày hiện tại khi tìm theo độ sâu tháng
      adaptiveSpeed: true, // Chế độ thông minh tương thích tốc độ tải (tự động chờ dữ liệu nạp 100%, chống sót dữ liệu)
      speedMode: 'adaptive', // 'adaptive' (Tự thích ứng thông minh) | 'safe' (Chờ an toàn / Mạng chậm) | 'fast' (Nhanh)
      deduplicateStatus: true, // Tránh lấy lặp lại nhiều khối trạng thái giống nhau (mỗi trạng thái chỉ lấy 1 khối duy nhất)
      maxPagesPerSearch: 3, // Cho phép qua tối đa 3 trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp
      maxPagesAllScan: 20, // Tối đa 20 trang khi quét toàn bộ dữ liệu theo khoảng thời gian không có mã hồ sơ
      selectedStatuses: {
        KhoiTaoHoSoBN: true, // BẮT BUỘC ĐẦU TIÊN CHO TẤT CẢ HỒ SƠ
        TiepNhanHoSoBN: true,
        BoSungHoSoDVC: true, // Bổ sung hồ sơ DVC / Bộ Ngành (Tùy chọn)
        CapNhatTienTrinhXuLyHoSoBN: true,
        GiaHanXuLyHoSoBN: true,
        TaoYeuCauThucHienNghiaVuTaiChinhBN: true,
        HuyYeuCauThucHienNghiaVuTaiChinhBN: true, // Tùy chọn lấy dữ liệu Hủy yêu cầu nghĩa vụ tài chính
        DongBoThongTinThanhToan: true, // Đồng bộ thông tin thanh toán (gộp chung cả DVC và Bộ/Ngành)
        TraKetQuaBN: true
      }
    }
  };

  // Helper to parse multiple application codes from text, handling table pastes (Excel/Web) cleanly
  function parseMaHoSoList(rawText) {
    if (!rawText || typeof rawText !== 'string') return [];
    const lines = rawText.split(/[\r\n]+/);
    const resultCodes = [];

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      // Handle table columns separated by tab, comma, semicolon or multiple spaces
      const tokens = line.split(/[\t,;]+/).map(t => t.trim()).filter(Boolean);

      let found = false;
      for (const token of tokens) {
        // Strip common prefix/suffix like #, bullets, quotes, leading number bullet like "1. "
        const clean = token.replace(/^[#*\-•\d.]+\s*/, '').replace(/["']/g, '').trim();

        // Skip non-codes: pure small numbers (STT), date strings, statuses, XML tags
        if (/^\d{1,4}$/.test(clean)) continue;
        if (/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(clean)) continue;
        if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) continue;
        if (/^(COMPLETED|PENDING|FAILED|ERROR|SUCCESS|HOAN_THANH|DANG_XU_LY)$/i.test(clean)) continue;
        if (/^(KhoiTaoHoSoBN|KhoiTaoHoSoDVC|TiepNhanHoSoBN|TiepNhanHoSoDVC|BoSungHoSoDVC|BoSungHoSoBN|YeuCauBoSungHoSoBN|YeuCauBoSungHoSoDVC|CapNhatTienTrinhXuLyHoSoBN|CapNhatTienTrinhXuLyHoSoDVC|GiaHanXuLyHoSoBN|GiaHanXuLyHoSoDVC|TaoYeuCauThucHienNghiaVuTaiChinhBN|TaoYeuCauThucHienNghiaVuTaiChinhDVC|HuyYeuCauThucHienNghiaVuTaiChinhBN|HuyYeuCauThucHienNghiaVuTaiChinhDVC|DongBoThongTinThanhToan|DongBoThongTinThanhToanBN|DongBoThongTinThanhToanDVC|TraKetQuaBN|TraKetQuaDVC)$/i.test(clean)) continue;

        // An application code in DVCQG is alphanumeric with hyphens/dots and at least 6 characters
        if (clean.length >= 6 && (clean.includes('-') || clean.includes('.') || /\d{6}/.test(clean))) {
          resultCodes.push(clean);
          found = true;
          break; // Take the primary application code from this table row
        }
      }

      // Fallback if line wasn't split by table delimiters but has a valid code
      if (!found && tokens.length === 1) {
        const cleanSingle = line.replace(/^[#*\-•]+\s*/, '').trim();
        if (cleanSingle.length >= 5) {
          resultCodes.push(cleanSingle);
        }
      }
    }

    // Deduplicate while preserving original order
    return Array.from(new Set(resultCodes));
  }

  // Parse filing date from application code: e.g. H21.117-260812-0008 -> 12/08/2026 (YYMMDD: 26=2026, 08=tháng 8, 12=ngày 12)
  function parseDateFromMaHoSo(maHoSo) {
    if (!maHoSo || typeof maHoSo !== 'string') return null;
    const clean = maHoSo.trim();

    // Pattern 1: Delimited segment with 6 digits (YYMMDD) or 8 digits (YYYYMMDD)
    // Delimiters can be hyphen, dot, slash, underscore, or whitespace
    // Examples: -260812-, -20260812-, .260812., /260812/, - 260812 -
    const delimitedRegex = /(?:^|[-_./\s])(\d{2}|\d{4})(\d{2})(\d{2})(?=[-_./\s]|$)/g;
    let match;
    const candidates = [];

    while ((match = delimitedRegex.exec(clean)) !== null) {
      const rawYear = parseInt(match[1], 10);
      const mm = parseInt(match[2], 10);
      const dd = parseInt(match[3], 10);

      // Validate month (1-12) and day (1-31)
      if (mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31) {
        let year = rawYear;
        if (rawYear < 100) {
          // 2-digit year: 20xx for 00..49, 19xx for 50..99
          year = rawYear >= 50 ? 1900 + rawYear : 2000 + rawYear;
        }
        // Score: high priority for modern DVCQG filing years (2018 - 2035)
        const isLikelyYear = year >= 2018 && year <= 2035;
        candidates.push({
          date: new Date(year, mm - 1, dd),
          year, mm, dd,
          score: isLikelyYear ? 100 : 40,
          index: match.index
        });
      }
    }

    if (candidates.length > 0) {
      // Sort by score descending; if equal, choose the one with higher index (towards end of code)
      candidates.sort((a, b) => (b.score - a.score) || (b.index - a.index));
      return candidates[0].date;
    }

    // Pattern 2: Any 6 consecutive digits with valid MM (1-12) and DD (1-31)
    const sixDigitRegex = /(?:^|[^\d])(\d{2})(\d{2})(\d{2})(?=[^\d]|$)/g;
    while ((match = sixDigitRegex.exec(clean)) !== null) {
      const rawYear = parseInt(match[1], 10);
      const mm = parseInt(match[2], 10);
      const dd = parseInt(match[3], 10);
      if (mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31) {
        const year = rawYear >= 50 ? 1900 + rawYear : 2000 + rawYear;
        if (year >= 2018 && year <= 2035) {
          return new Date(year, mm - 1, dd);
        }
      }
    }

    return null;
  }

  // Step definitions: Các bước nghiệp vụ từ Khởi tạo đến Trả kết quả (KhoiTaoHoSoBN là bắt buộc đầu tiên)
  // Hỗ trợ đồng thời cả các mã dịch vụ BN và DVC (đặc biệt DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN)
  const STEP_DEFINITIONS = [
    { key: 'KhoiTaoHoSoBN', aliases: ['KhoiTaoHoSoBN', 'KhoiTaoHoSoDVC'], label: '1. Khởi tạo (Bắt buộc)' },
    { key: 'TiepNhanHoSoBN', aliases: ['TiepNhanHoSoBN', 'TiepNhanHoSoDVC'], label: '2. Tiếp nhận' },
    { key: 'BoSungHoSoDVC', aliases: ['BoSungHoSoDVC', 'BoSungHoSoBN', 'YeuCauBoSungHoSoBN', 'YeuCauBoSungHoSoDVC'], label: '2b. Bổ sung HS', isOptional: true },
    { key: 'CapNhatTienTrinhXuLyHoSoBN', aliases: ['CapNhatTienTrinhXuLyHoSoBN', 'CapNhatTienTrinhXuLyHoSoDVC'], label: '3. Tiến trình' },
    { key: 'GiaHanXuLyHoSoBN', aliases: ['GiaHanXuLyHoSoBN', 'GiaHanXuLyHoSoDVC'], label: '4. Gia hạn', isOptional: true },
    { key: 'TaoYeuCauThucHienNghiaVuTaiChinhBN', aliases: ['TaoYeuCauThucHienNghiaVuTaiChinhBN', 'TaoYeuCauThucHienNghiaVuTaiChinhDVC'], label: '5. Tạo Y/c TC', isOptional: true },
    { key: 'HuyYeuCauThucHienNghiaVuTaiChinhBN', aliases: ['HuyYeuCauThucHienNghiaVuTaiChinhBN', 'HuyYeuCauThucHienNghiaVuTaiChinhDVC'], label: '6. Hủy Y/c TC', isOptional: true },
    { key: 'DongBoThongTinThanhToan', aliases: ['DongBoThongTinThanhToan', 'DongBoThongTinThanhToanBN', 'DongBoThongTinThanhToanDVC'], label: '7. Thanh toán', isOptional: true },
    { key: 'TraKetQuaBN', aliases: ['TraKetQuaBN', 'TraKetQuaDVC'], label: '8. Trả kết quả' }
  ];

  // Lấy danh sách tất cả các mã trạng thái/dịch vụ cần quét (bao gồm cả biến thể DVC và BN)
  function getTargetStatuses() {
    const list = [];
    const sel = state.config.selectedStatuses || {};
    STEP_DEFINITIONS.forEach(step => {
      const isSelected = sel[step.key] || (step.aliases && step.aliases.some(a => sel[a]));
      if (isSelected) {
        if (step.aliases) {
          step.aliases.forEach(a => { if (!list.includes(a)) list.push(a); });
        } else if (!list.includes(step.key)) {
          list.push(step.key);
        }
      }
    });
    // Đảm bảo luôn bao gồm cả DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN nếu tùy chọn thanh toán được bật
    const isPaymentSelected = sel.DongBoThongTinThanhToan !== false && (sel.DongBoThongTinThanhToan || sel.DongBoThongTinThanhToanBN !== false || sel.DongBoThongTinThanhToanDVC !== false);
    if (isPaymentSelected) {
      if (!list.includes('DongBoThongTinThanhToanDVC')) list.push('DongBoThongTinThanhToanDVC');
      if (!list.includes('DongBoThongTinThanhToanBN')) list.push('DongBoThongTinThanhToanBN');
      if (!list.includes('DongBoThongTinThanhToan')) list.push('DongBoThongTinThanhToan');
    }
    // Thêm các trạng thái tự do nếu có
    Object.keys(sel).forEach(k => {
      if (sel[k] && !list.includes(k)) list.push(k);
    });
    return list;
  }

  // Tra cứu Step definition từ tên trạng thái (hỗ trợ cả DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN)
  function findStepByStatus(statusName) {
    if (!statusName) return null;
    return STEP_DEFINITIONS.find(s => s.key === statusName || (s.aliases && s.aliases.includes(statusName))) || null;
  }

  // Cập nhật giao diện theo dõi số bước (step) đã thực hiện & hiển thị trạng thái hoàn thành chi tiết
  function updateStepTracker(records = []) {
    const statusCounts = {};
    (records || []).forEach(r => {
      if (r && r.status) {
        statusCounts[r.status] = (statusCounts[r.status] || 0) + 1;
      }
    });

    let completedCount = 0;

    STEP_DEFINITIONS.forEach(step => {
      const stepStatuses = step.aliases || [step.key];
      let count = 0;
      stepStatuses.forEach(st => {
        count += (statusCounts[st] || 0);
      });
      const isDone = count > 0;
      if (isDone) completedCount++;

      // 1. Cập nhật chip hiển thị trên bảng tiến trình step
      const chip = document.getElementById(`chip-${step.key}`);
      if (chip) {
        if (isDone) {
          chip.classList.add('completed');
          chip.classList.remove('pending');

          let doneDetail = '';
          if (step.key === 'DongBoThongTinThanhToan' || step.key === 'DongBoThongTinThanhToanBN') {
            const hasDvc = (statusCounts['DongBoThongTinThanhToanDVC'] || 0) > 0;
            const hasBn = (statusCounts['DongBoThongTinThanhToanBN'] || 0) > 0;
            if (hasDvc && hasBn) {
              doneDetail = ` (DVC + BN: ${count})`;
            } else if (hasDvc) {
              doneDetail = ` (DVC: ${count})`;
            } else if (hasBn) {
              doneDetail = ` (BN: ${count})`;
            }
          } else if (count > 1) {
            doneDetail = ` (${count})`;
          }

          chip.innerHTML = `
            <span class="step-chip-name">${step.label}</span>
            <span class="step-chip-status done">✓ HOÀN THÀNH${doneDetail}</span>
          `;
          chip.title = `${step.label}: ĐÃ HOÀN THÀNH (Trích xuất thành công ${count} khối XML)`;
        } else {
          chip.classList.remove('completed');
          chip.classList.add('pending');
          chip.innerHTML = `
            <span class="step-chip-name">${step.label}</span>
            <span class="step-chip-status wait">Chờ quét</span>
          `;
          chip.title = `${step.label}: Chưa có khối COMPLETED hoặc SUCCESS nào`;
        }
      }

      // 2. Cập nhật thẻ trạng thái bên cạnh danh mục checkbox
      const listBadge = document.getElementById(`badge-st-${step.key}`);
      if (listBadge) {
        if (isDone) {
          listBadge.className = 'dvcqg-step-state-tag done';
          let doneText = `✓ Đã lấy${count > 1 ? ` (${count})` : ''}`;
          if (step.key === 'DongBoThongTinThanhToan' || step.key === 'DongBoThongTinThanhToanBN') {
            const hasDvc = (statusCounts['DongBoThongTinThanhToanDVC'] || 0) > 0;
            const hasBn = (statusCounts['DongBoThongTinThanhToanBN'] || 0) > 0;
            if (hasDvc && hasBn) doneText = `✓ Đã lấy (DVC+BN: ${count})`;
            else if (hasDvc) doneText = `✓ Đã lấy (DVC: ${count})`;
            else if (hasBn) doneText = `✓ Đã lấy (BN: ${count})`;
          }
          listBadge.textContent = doneText;
        } else {
          listBadge.className = 'dvcqg-step-state-tag wait';
          listBadge.textContent = 'Chờ quét';
        }
      }
      if (step.aliases) {
        step.aliases.forEach(aliasKey => {
          if (aliasKey !== step.key) {
            const aliasBadge = document.getElementById(`badge-st-${aliasKey}`);
            if (aliasBadge) {
              const aCount = statusCounts[aliasKey] || 0;
              if (aCount > 0) {
                aliasBadge.className = 'dvcqg-step-state-tag done';
                aliasBadge.textContent = `✓ Đã lấy${aCount > 1 ? ` (${aCount})` : ''}`;
              } else {
                aliasBadge.className = 'dvcqg-step-state-tag wait';
                aliasBadge.textContent = 'Chờ quét';
              }
            }
          }
        });
      }
    });

    // 3. Cập nhật thanh tiến trình mini & huy hiệu tổng thể
    const badge = document.getElementById('dvcqg-step-counter-badge');
    const miniFill = document.getElementById('dvcqg-step-mini-fill');
    const pct = Math.round((completedCount / STEP_DEFINITIONS.length) * 100);

    if (miniFill) {
      miniFill.style.width = `${pct}%`;
    }

    if (badge) {
      if (completedCount === STEP_DEFINITIONS.length) {
        badge.className = 'dvcqg-step-counter-badge all-completed';
        badge.innerHTML = `✓ ${completedCount}/${STEP_DEFINITIONS.length} steps (HOÀN THÀNH 100%)`;
      } else if (statusCounts['TraKetQuaBN'] > 0) {
        badge.className = 'dvcqg-step-counter-badge has-traketqua';
        badge.innerHTML = `✓ ${completedCount}/${STEP_DEFINITIONS.length} steps (ĐÃ TRẢ KẾT QUẢ)`;
      } else if (completedCount > 0) {
        badge.className = 'dvcqg-step-counter-badge in-progress';
        badge.textContent = `${completedCount}/${STEP_DEFINITIONS.length} steps (${pct}%)`;
      } else {
        badge.className = 'dvcqg-step-counter-badge';
        badge.textContent = `0/${STEP_DEFINITIONS.length} steps`;
      }
    }

    return completedCount;
  }

  // Tạo danh sách các khoảng thời gian tra cứu thông minh:
  // - Đợt 1: KhoiTaoHoSoBN - ngày bắt đầu và kết thúc lấy theo ngày hồ sơ
  // - Đợt 2: Quét thời gian tiếp theo trong tháng nộp hồ sơ (nếu chưa phải ngày cuối tháng)
  // - Các đợt tiếp theo: Chuyển qua các tháng khác (độ sâu tối đa do người dùng cài đặt, mặc định 3 tháng sau đó)
  // NÂNG CẤP THÔNG MINH: Tự nhận dạng mục "Đến ngày" với Ngày hiện tại khi đợt quét chạm đến tháng/ngày hiện tại,
  // tuyệt đối không vượt quá ngày hiện tại hoặc tạo các đợt ở tháng tương lai!
  function generateSmartDateRanges(filingDate, maxDepth = null) {
    const ranges = [];
    if (!filingDate || isNaN(filingDate.getTime())) return ranges;

    const depthLimit = Math.max(1, parseInt(maxDepth ?? state.config.searchDepthMonths ?? 3, 10));
    const now = new Date();
    const filingYmd = formatDateYMD(filingDate);
    const filingDmy = formatDateDMY(filingDate);

    // 1. Đợt 1: Với KhoiTaoHoSoBN, ngày bắt đầu và kết thúc lấy theo ngày hồ sơ
    ranges.push({
      from: filingYmd,
      to: filingYmd,
      stage: 'KhoiTaoHoSoBN',
      monthStr: `${pad(filingDate.getMonth() + 1)}/${filingDate.getFullYear()}`,
      label: `Đợt 1 (KhoiTaoHoSoBN): ${filingDmy} ➜ ${filingDmy} [Ngày hồ sơ]`
    });

    const filingYear = filingDate.getFullYear();
    const filingMonth = filingDate.getMonth(); // 0-indexed
    const filingDay = filingDate.getDate();
    const endOfFilingMonth = new Date(filingYear, filingMonth + 1, 0);

    // 2. Đợt 2: Quét thời gian tiếp theo trong tháng nộp hồ sơ (nếu chưa phải ngày cuối tháng)
    if (filingDay < endOfFilingMonth.getDate()) {
      const nextDay = new Date(filingYear, filingMonth, filingDay + 1);
      let toEndOfMonth = endOfFilingMonth;
      const isCurrentMonth = (now.getFullYear() === filingYear && now.getMonth() === filingMonth);
      if (isCurrentMonth && now < endOfFilingMonth) {
        toEndOfMonth = now; // Tự nhận dạng Đến ngày = Ngày hiện tại nếu nộp trong tháng hiện tại
      }

      if (nextDay.getTime() <= toEndOfMonth.getTime()) {
        ranges.push({
          from: formatDateYMD(nextDay),
          to: formatDateYMD(toEndOfMonth),
          monthStr: `${pad(filingMonth + 1)}/${filingYear}`,
          isToToday: isCurrentMonth,
          label: `Thời gian tiếp theo tháng ${pad(filingMonth + 1)}/${filingYear} (${formatDateDMY(nextDay)} ➜ ${formatDateDMY(toEndOfMonth)}${isCurrentMonth ? ' [Tự nhận dạng Đến ngày = Ngày hiện tại]' : ''})`
        });
      }
    }

    // 3. Các đợt tiếp theo: Chuyển qua các tháng khác theo độ sâu thiết lập
    // QUY TẮC BẮT BUỘC: Khi chuyển sang tháng khác, Từ ngày = 01 của tháng đó (ngày đầu tháng),
    // NÂNG CẤP TỰ NHẬN DẠNG ĐẾN NGÀY VỚI NGÀY HIỆN TẠI:
    // - Nếu tháng quét là tháng hiện tại: Đến ngày = Ngày hiện tại (now).
    // - Nếu tháng quét bắt đầu sau ngày hiện tại (tháng tương lai): Dừng ngay lập tức (không thể có hồ sơ trong tương lai).
    const MAX_DEPTH_MONTHS = depthLimit;
    let curYear = filingYear;
    let curMonth = filingMonth + 1;
    if (curMonth > 11) {
      curMonth = 0;
      curYear++;
    }

    let monthDepth = 0;
    while (monthDepth < MAX_DEPTH_MONTHS) {
      monthDepth++;
      const monthStart = new Date(curYear, curMonth, 1); // BẮT BUỘC NGÀY ĐẦU THÁNG (01/MM/YYYY)
      const monthEnd = new Date(curYear, curMonth + 1, 0); // NGÀY CUỐI THÁNG

      // Nếu ngày đầu tháng đã vượt quá ngày hiện tại (tháng hoàn toàn ở tương lai): Dừng ngay
      if (monthStart.getTime() > now.getTime()) {
        break;
      }

      let toD = monthEnd;
      const isCurrentMonth = (now.getFullYear() === curYear && now.getMonth() === curMonth);
      if (isCurrentMonth) {
        toD = now; // TỰ NHẬN DẠNG MỤC "ĐẾN NGÀY" VỚI NGÀY HIỆN TẠI
      }

      ranges.push({
        from: formatDateYMD(monthStart), // BẮT BUỘC NGÀY ĐẦU THÁNG (01)
        to: formatDateYMD(toD),           // Ngày cuối tháng hoặc Ngày hiện tại
        monthStr: `${pad(curMonth + 1)}/${curYear}`,
        monthDepth,
        isToToday: isCurrentMonth,
        label: `Tháng ${pad(curMonth + 1)}/${curYear} [Sau đó +${monthDepth}/${MAX_DEPTH_MONTHS}]: Từ ${formatDateDMY(monthStart)} ➜ ${formatDateDMY(toD)} (${isCurrentMonth ? 'Tự nhận dạng Đến ngày = Ngày hiện tại' : 'cuối tháng'})`
      });

      // Nếu đã quét đến tháng hiện tại, dừng lại vì không thể quét các tháng sau đó trong tương lai
      if (isCurrentMonth) {
        break;
      }

      curMonth++;
      if (curMonth > 11) {
        curMonth = 0;
        curYear++;
      }
    }

    return ranges;
  }

  // 1. Inject Network Interceptor
  function injectNetworkScript() {
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('content-scripts/dvcqg-injected.js');
      script.onload = () => script.remove();
      (document.head || document.documentElement).appendChild(script);
      console.log('[DVCQG Auto] Injected network interceptor.');
    } catch (err) {
      console.warn('[DVCQG Auto] Could not inject network script:', err);
    }
  }
  injectNetworkScript();

  // Listen to messages from injected script
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    const { type, xml, data, url, activeRequests } = event.data;

    // Cập nhật trạng thái tải mạng thời gian thực cho chế độ thông minh tương thích tốc độ
    if (type === 'DVCQG_NETWORK_STATE') {
      state.networkActiveCount = Math.max(0, parseInt(activeRequests, 10) || 0);
      const ind = document.getElementById('dvcqg-network-indicator');
      if (ind) {
        if (state.networkActiveCount > 0) {
          ind.textContent = '⏳';
          ind.title = `Đang tải dữ liệu (${state.networkActiveCount} request)...`;
          ind.style.color = '#f59e0b';
        } else {
          ind.textContent = '🟢';
          ind.title = 'Trạng thái mạng: Sẵn sàng';
          ind.style.color = '#10b981';
        }
      }
      return;
    }

    if (type === 'DVCQG_CAPTURED_XML' && xml) {
      if (
        typeof xml === 'string' &&
        (xml.includes('http://dichvucong.gov.vn/api/v1') ||
         xml.includes('https://dichvucong.gov.vn/api/v1') ||
         xml.includes('http://www.w3.org/2001/XMLSchema') ||
         xml.includes('https://www.w3.org/2001/XMLSchema'))
      ) {
        const envs = extractDvcqgEnvelopes(xml);
        envs.forEach(envXml => {
          state.capturedNetworkXml.push({ url, xml: envXml, time: Date.now() });
        });
        if (envs.length > 0) {
          log(`Bắt được ${envs.length} khối Envelope từ mạng (${url || 'API'})`, 'info');
        }
      }
    }

    if (type === 'DVCQG_NETWORK_RESPONSE' && data) {
      scanNetworkDataForXml(data, url);
    }
  });

  // Recursive search for XML strings inside JSON API response
  function scanNetworkDataForXml(obj, url) {
    if (!obj || typeof obj !== 'object') return;
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (
        typeof val === 'string' &&
        (val.includes('<Envelope') || val.includes('&lt;Envelope') || (/<\?xml/i.test(val) && val.includes('Envelope')) || (/&lt;\?xml/i.test(val) && val.includes('Envelope'))) &&
        (val.includes('http://dichvucong.gov.vn/api/v1') ||
         val.includes('https://dichvucong.gov.vn/api/v1') ||
         val.includes('http://www.w3.org/2001/XMLSchema') ||
         val.includes('https://www.w3.org/2001/XMLSchema'))
      ) {
        const envs = extractDvcqgEnvelopes(val);
        envs.forEach(envXml => {
          state.capturedNetworkXml.push({ url, key, xml: envXml, time: Date.now() });
        });
      } else if (typeof val === 'object') {
        scanNetworkDataForXml(val, url);
      }
    }
  }

  // 2. UI Elements & Helper functions
  let rootEl = null;
  let logBoxEl = null;

  function pad(n) { return n < 10 ? '0' + n : String(n); }
  function formatDateYMD(d) {
    if (!d) return '';
    if (typeof d === 'string') {
      const clean = d.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(clean)) {
        const parts = clean.split('/');
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      d = new Date(clean);
    }
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  function formatDateDMY(d) {
    if (!d) return '';
    if (typeof d === 'string') {
      const clean = d.trim();
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(clean)) return clean;
      if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
        const parts = clean.split('-');
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      d = new Date(clean);
    }
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
  }

  function log(msg, type = 'info') {
    console.log(`[DVCQG Auto] [${type}] ${msg}`);
    if (!logBoxEl) return;
    const now = new Date();
    const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const div = document.createElement('div');
    div.className = `dvcqg-log-entry ${type}`;
    div.textContent = `[${timeStr}] ${msg}`;
    logBoxEl.appendChild(div);
    logBoxEl.scrollTop = logBoxEl.scrollHeight;
  }

  // Set input value cleanly triggering React/Angular/Vue change detection
  function setNativeValue(element, value) {
    if (!element) return;
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value')?.set;
    const prototype = Object.getPrototypeOf(element);
    const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

    if (prototypeValueSetter && valueSetter !== prototypeValueSetter) {
      prototypeValueSetter.call(element, value);
    } else if (valueSetter) {
      valueSetter.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Sleep utility
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // 3. Smart Element Locators on DVCQG Page
  function findMaHoSoInput() {
    const selectors = [
      'input[placeholder*="mã hồ sơ" i]',
      'input[placeholder*="hồ sơ" i]',
      'input[id*="mahoso" i]',
      'input[id*="ma_ho_so" i]',
      'input[name*="mahoso" i]',
      'input[name*="ma_ho_so" i]',
      'input[formcontrolname*="mahoso" i]',
      'input[formcontrolname*="maHoSo" i]',
      'input[ng-reflect-name*="mahoso" i]',
      'input[ng-reflect-name*="maHoSo" i]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }

    // Try finding by label text
    const labels = Array.from(document.querySelectorAll('label, .ant-form-item-label, .control-label'));
    for (const lbl of labels) {
      if (lbl.textContent.toLowerCase().includes('mã hồ sơ')) {
        const id = lbl.getAttribute('for');
        if (id) {
          const el = document.getElementById(id);
          if (el) return el;
        }
        const input = lbl.parentElement?.querySelector('input') || lbl.nextElementSibling?.querySelector('input');
        if (input) return input;
      }
    }

    // Fallback: search-like input
    const generalInputs = document.querySelectorAll('input[type="text"]:not([readonly])');
    for (const inp of generalInputs) {
      if (inp.offsetParent !== null && !inp.closest('#dvcqg-auto-root')) return inp;
    }
    return null;
  }

  function findDateInputs() {
    let fromInput = null;
    let toInput = null;

    // 1. Check Ant Design / NG-ZORRO Range Picker
    const rangePicker = document.querySelector('.ant-picker-range, nz-range-picker, .daterangepicker');
    if (rangePicker && !rangePicker.closest('#dvcqg-auto-root')) {
      const rInputs = Array.from(rangePicker.querySelectorAll('input')).filter(el => !el.closest('#dvcqg-auto-root'));
      if (rInputs.length >= 2) {
        return { fromInput: rInputs[0], toInput: rInputs[1] };
      }
    }

    // 2. By specific attribute selectors (placeholder, formcontrolname, id, name)
    const fromSelectors = [
      'input[placeholder*="từ ngày" i]',
      'input[placeholder*="từ" i]',
      'input[formcontrolname*="tuNgay" i]',
      'input[formcontrolname*="from" i]',
      'input[formcontrolname*="startDate" i]',
      'input[formcontrolname*="ngayBatDau" i]',
      'input[ng-reflect-name*="tuNgay" i]',
      'input[ng-reflect-name*="from" i]',
      'input[id*="tungay" i]',
      'input[id*="tu_ngay" i]',
      'input[id*="from" i]',
      'input[name*="tungay" i]',
      'input[name*="tu_ngay" i]',
      'input[name*="from" i]'
    ];
    for (const sel of fromSelectors) {
      const el = document.querySelector(sel);
      if (el && !el.closest('#dvcqg-auto-root') && el.offsetParent !== null) {
        fromInput = el;
        break;
      }
    }

    const toSelectors = [
      'input[placeholder*="đến ngày" i]',
      'input[placeholder*="đến" i]',
      'input[formcontrolname*="denNgay" i]',
      'input[formcontrolname*="to" i]',
      'input[formcontrolname*="endDate" i]',
      'input[formcontrolname*="ngayKetThuc" i]',
      'input[ng-reflect-name*="denNgay" i]',
      'input[ng-reflect-name*="to" i]',
      'input[id*="denngay" i]',
      'input[id*="den_ngay" i]',
      'input[id*="to" i]',
      'input[name*="denngay" i]',
      'input[name*="den_ngay" i]',
      'input[name*="to" i]'
    ];
    for (const sel of toSelectors) {
      const el = document.querySelector(sel);
      if (el && !el.closest('#dvcqg-auto-root') && el.offsetParent !== null) {
        toInput = el;
        break;
      }
    }

    // 3. Try finding by surrounding form label text
    if (!fromInput || !toInput) {
      const labels = Array.from(document.querySelectorAll('label, .control-label, .ant-form-item-label'));
      for (const lbl of labels) {
        const txt = lbl.textContent.toLowerCase();
        if (txt.includes('từ ngày') && !fromInput) {
          const container = lbl.closest('.ant-form-item, nz-form-item, .form-group, .form-item, .row, .col, tr, div');
          const inp = container ? container.querySelector('input:not([type="hidden"])') : null;
          if (inp && !inp.closest('#dvcqg-auto-root')) fromInput = inp;
        }
        if (txt.includes('đến ngày') && !toInput) {
          const container = lbl.closest('.ant-form-item, nz-form-item, .form-group, .form-item, .row, .col, tr, div');
          const inp = container ? container.querySelector('input:not([type="hidden"])') : null;
          if (inp && !inp.closest('#dvcqg-auto-root')) toInput = inp;
        }
      }
    }

    // 4. Fallback: by date picker classes or dd/mm/yyyy placeholders
    if (!fromInput || !toInput) {
      const dateInputs = Array.from(document.querySelectorAll(
        '.ant-picker-input input, nz-date-picker input, .ant-picker input, .ant-calendar-picker-input, input[type="date"], input[placeholder*="dd/mm/yyyy" i], input[placeholder*="DD/MM/YYYY" i], input[placeholder*="dd/MM/yyyy" i]'
      )).filter(el => !el.closest('#dvcqg-auto-root') && el.offsetParent !== null);

      if (dateInputs.length >= 2) {
        if (!fromInput) fromInput = dateInputs[0];
        if (!toInput) toInput = dateInputs[1];
      } else if (dateInputs.length === 1 && !fromInput) {
        fromInput = dateInputs[0];
      }
    }

    return { fromInput, toInput };
  }

  // Xóa sạch giá trị ô ngày trên trang (Đặc biệt dùng xóa "Đến ngày" trước để "Từ ngày" chọn được tháng mới)
  async function clearPageDateInput(inputEl) {
    if (!inputEl) return false;
    try {
      const wasReadOnly = inputEl.readOnly;
      if (wasReadOnly) inputEl.readOnly = false;

      // 1. Nếu DatePicker có nút clear dạng icon (Ant Design / NG-ZORRO)
      const pickerContainer = inputEl.closest('.ant-picker, nz-date-picker, .ant-calendar-picker, .date-picker, .ant-picker-input');
      if (pickerContainer) {
        pickerContainer.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
        const clearBtns = pickerContainer.querySelectorAll('.ant-picker-clear, .ant-calendar-picker-clear, .anticon-close-circle, .bi-x-circle, [data-icon="close-circle"], nz-picker-clear, i.anticon-close');
        for (const btn of clearBtns) {
          try {
            btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            btn.click();
            btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          } catch (e) {}
        }
        await sleep(50);
      }

      // 2. Xóa native input (không dispatch blur khi rỗng vì blur sẽ kích hoạt ng-zorro hoàn tác ngày cũ)
      inputEl.focus();
      inputEl.select?.();

      const valueSetter = Object.getOwnPropertyDescriptor(inputEl, 'value')?.set;
      const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(inputEl), 'value')?.set;
      if (prototypeValueSetter && valueSetter !== prototypeValueSetter) {
        prototypeValueSetter.call(inputEl, '');
      } else if (valueSetter) {
        valueSetter.call(inputEl, '');
      } else {
        inputEl.value = '';
      }

      // Gửi phím Backspace / Delete
      const keyBack = { key: 'Backspace', code: 'Backspace', keyCode: 8, which: 8, bubbles: true, cancelable: true };
      inputEl.dispatchEvent(new KeyboardEvent('keydown', keyBack));
      inputEl.dispatchEvent(new KeyboardEvent('keyup', keyBack));

      await sleep(20);
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));

      if (wasReadOnly) inputEl.readOnly = true;
      return true;
    } catch (err) {
      console.warn('[DVCQG Auto] Error clearing date input:', err);
      return false;
    }
  }

  // Set date value into webpage input, properly committing Ant Design / NG-ZORRO / Angular models
  async function setPageDateValue(inputEl, dateVal) {
    if (!inputEl) return false;
    if (!dateVal) {
      return await clearPageDateInput(inputEl);
    }

    const ymd = formatDateYMD(dateVal);
    const dmy = formatDateDMY(dateVal);

    // Target format: standard on Vietnamese portals is DD/MM/YYYY unless type="date"
    let targetVal = dmy;
    if (inputEl.type === 'date') {
      targetVal = ymd;
    } else {
      const ph = (inputEl.getAttribute('placeholder') || '').toLowerCase();
      if (ph.includes('yyyy-mm-dd') || ph.includes('yyyy/mm/dd')) {
        targetVal = ymd;
      }
    }

    try {
      const wasReadOnly = inputEl.readOnly;
      if (wasReadOnly) inputEl.readOnly = false;

      inputEl.focus();
      inputEl.select?.();
      await sleep(20);

      // Set native value cleanly
      setNativeValue(inputEl, targetVal);

      // Dispatch Enter key events so Ant Design / NG-ZORRO DatePicker commits value into its reactive model
      const keyOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      inputEl.dispatchEvent(new KeyboardEvent('keydown', keyOpts));
      inputEl.dispatchEvent(new KeyboardEvent('keypress', keyOpts));
      inputEl.dispatchEvent(new KeyboardEvent('keyup', keyOpts));

      await sleep(40);
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.dispatchEvent(new Event('blur', { bubbles: true }));

      if (wasReadOnly) inputEl.readOnly = true;
      return true;
    } catch (err) {
      console.warn('[DVCQG Auto] Error setting date input:', err);
      return false;
    }
  }

  // Điền bộ đôi Từ ngày & Đến ngày vào trang web một cách an toàn và thông minh
  // Tuyệt đối không để xảy ra xung đột "Từ ngày > Đến ngày" hoặc "Khoảng cách > 30 ngày"
  // làm trang web khóa/lặp ngày cuối tháng cũ!
  async function applyDateRangeToWebPage(fromYmd, toYmd) {
    const { fromInput, toInput } = findDateInputs();
    if (!fromInput && !toInput) {
      log('⚠️ Không tìm thấy ô nhập ngày trên trang web!', 'warn');
      return false;
    }

    const targetFromDmy = formatDateDMY(fromYmd);
    const targetToDmy = formatDateDMY(toYmd);

    const parseValDate = (val) => {
      if (!val) return null;
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(val)) {
        const [d, m, y] = val.split('/').map(Number);
        return new Date(y, m - 1, d);
      }
      if (/^\d{4}-\d{2}-\d{2}$/.test(val)) {
        const [y, m, d] = val.split('-').map(Number);
        return new Date(y, m - 1, d);
      }
      const dt = new Date(val);
      return isNaN(dt.getTime()) ? null : dt;
    };

    const targetFromDate = parseValDate(targetFromDmy);
    const targetToDate = parseValDate(targetToDmy);

    const curFromDate = fromInput ? parseValDate(fromInput.value) : null;
    const curToDate = toInput ? parseValDate(toInput.value) : null;

    // Kiểm tra xem có đang chuyển sang tháng mới trong tương lai hay không
    // (targetFromDate > curToDate: nếu điền Từ ngày trước sẽ bị lỗi Từ ngày > Đến ngày cũ dẫn đến kẹt ngày cuối tháng)
    const isMovingForward = targetFromDate && curToDate && targetFromDate.getTime() > curToDate.getTime();

    if (isMovingForward && toInput && fromInput) {
      log(`🔄 Chuyển tháng mới (${targetFromDmy} ➜ ${targetToDmy}): Áp dụng cơ chế bước đệm an toàn`, 'info');
      // BƯỚC ĐỆM 1: Thu hẹp khoảng cách cũ bằng cách chỉnh Từ ngày = Đến ngày hiện tại (ví dụ 31/08)
      await setPageDateValue(fromInput, curToDate);
      await sleep(100);

      // BƯỚC ĐỆM 2: Mở đường tháng mới: Đặt Đến ngày = targetFrom (ví dụ 01/09).
      // Khoảng cách giữa 01/09 và 31/08 chỉ là 1 ngày (Đến >= Từ, <= 30 ngày), hợp lệ 100%!
      await setPageDateValue(toInput, targetFromDate);
      await sleep(100);

      // BƯỚC ĐỆM 3: Đặt Từ ngày = targetFrom (ví dụ 01/09).
      // Cả hai cùng là 01/09, hợp lệ 100%!
      await setPageDateValue(fromInput, targetFromDate);
      await sleep(100);

      // BƯỚC ĐỆM 4: Mở rộng Đến ngày = targetTo (ví dụ 30/09).
      // Cùng trong tháng mới (<= 30 ngày), hợp lệ 100%!
      await setPageDateValue(toInput, targetToDate);
      await sleep(150);
    } else {
      // Trường hợp cùng tháng hoặc khởi tạo lần đầu:
      // Xóa Đến ngày trước nếu cần -> Điền Từ ngày -> Điền Đến ngày
      if (toInput) {
        await clearPageDateInput(toInput);
        await sleep(80);
      }
      if (fromInput && fromYmd) {
        await setPageDateValue(fromInput, fromYmd);
        await sleep(120);
      }
      if (toInput && toYmd) {
        await setPageDateValue(toInput, toYmd);
        await sleep(150);
      }
    }

    // Kiểm tra giá trị thực tế sau khi điền
    const actualFrom = (fromInput?.value || '').trim();
    const actualTo = (toInput?.value || '').trim();
    log(`✓ Ngày thực tế trên trang: Từ "${actualFrom}" đến "${actualTo}"`, 'info');

    // Chốt chặn sửa lỗi: Nếu vẫn bị kẹt ngày cũ (do framework không cập nhật), ép gán trực tiếp
    if (fromInput && targetFromDmy && actualFrom !== targetFromDmy && actualFrom !== fromYmd) {
      await setPageDateValue(fromInput, fromYmd);
    }
    if (toInput && targetToDmy && actualTo !== targetToDmy && actualTo !== toYmd) {
      await setPageDateValue(toInput, toYmd);
    }

    return true;
  }

  function findSearchButton() {
    const buttons = Array.from(document.querySelectorAll('button, input[type="submit"], a.btn, .btn'));
    for (const btn of buttons) {
      if (btn.closest('#dvcqg-auto-root')) continue;
      const text = (btn.textContent || btn.value || '').trim().toLowerCase();
      if (text.includes('tìm kiếm') || text.includes('tra cứu')) {
        return btn;
      }
    }
    // Icon-based search buttons
    const iconBtn = document.querySelector('button .bi-search, button .fa-search, button .anticon-search, button svg[data-icon="search"]')?.closest('button');
    if (iconBtn && !iconBtn.closest('#dvcqg-auto-root')) return iconBtn;
    return null;
  }

  // Chuẩn hóa chuỗi XML để so sánh nội dung (loại bỏ khoảng trắng thừa và đồng nhất header XML)
  function normalizeXml(xml) {
    if (!xml || typeof xml !== 'string') return '';
    // Chuẩn hóa loại bỏ khác biệt tiền tố <?xml ... ?> (hoa/thường UTF-8 vs utf-8) khi so sánh nội dung Envelope
    return xml
      .replace(/^<\?xml\b[^?]*\?>\s*/i, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Tìm nút chuyển sang trang tiếp theo (Next Page) trong phân trang Ant Design / DVCQG
  function findNextPageElement() {
    // 1. Quét tất cả button / thẻ a trên trang có chứa chữ "Trang sau"
    // Hỗ trợ chính xác Ant Design v5 trên DVCQG:
    // <button type="button" class="ant-btn css-14al3d1 ant-btn-default ant-btn-color-default ant-btn-variant-outlined flex items-center gap-1"><span class="hidden lg:inline">Trang sau</span></button>
    const allButtons = Array.from(document.querySelectorAll('button, a[role="button"], a, [role="button"]'))
      .filter(el => !el.closest('#dvcqg-auto-root'));

    for (const el of allButtons) {
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (text.includes('trang sau') || text === 'sau' || text.includes('kế tiếp') || text === 'next') {
        const isDisabled = el.disabled === true ||
                           el.hasAttribute('disabled') ||
                           el.getAttribute('aria-disabled') === 'true' ||
                           el.classList.contains('ant-btn-disabled') ||
                           el.classList.contains('disabled');
        if (!isDisabled && el.offsetParent !== null) {
          return el;
        }
        if (isDisabled) {
          return null; // Đã là trang cuối cùng
        }
      }
    }

    // 1b. Quét qua các thẻ span có chữ "Trang sau" và lấy button cha
    const spans = Array.from(document.querySelectorAll('span')).filter(el => !el.closest('#dvcqg-auto-root'));
    for (const span of spans) {
      const text = (span.textContent || '').trim().toLowerCase();
      if (text === 'trang sau') {
        const parentBtn = span.closest('button, a[role="button"], a');
        if (parentBtn && !parentBtn.closest('#dvcqg-auto-root')) {
          const isDisabled = parentBtn.disabled === true ||
                             parentBtn.hasAttribute('disabled') ||
                             parentBtn.getAttribute('aria-disabled') === 'true' ||
                             parentBtn.classList.contains('ant-btn-disabled') ||
                             parentBtn.classList.contains('disabled');
          if (!isDisabled && parentBtn.offsetParent !== null) {
            return parentBtn;
          }
          if (isDisabled) return null;
        }
      }
    }

    // 2. Ant Design / NG-ZORRO li.ant-pagination-next
    const antNextLi = document.querySelector('li.ant-pagination-next, nz-pagination li.ant-pagination-next, .ant-pagination .ant-pagination-next');
    if (antNextLi && !antNextLi.closest('#dvcqg-auto-root')) {
      const isDisabled = antNextLi.classList.contains('ant-pagination-disabled') ||
                         antNextLi.getAttribute('aria-disabled') === 'true' ||
                         antNextLi.querySelector('button[disabled]');
      if (!isDisabled) {
        const btn = antNextLi.querySelector('button, a, .ant-pagination-item-link') || antNextLi;
        return btn;
      }
      return null; // Đã là trang cuối
    }

    // 3. Thẻ số trang kế tiếp sau trang active
    const activeLi = document.querySelector('li.ant-pagination-item-active, .ant-pagination-item.ant-pagination-item-active');
    if (activeLi && !activeLi.closest('#dvcqg-auto-root')) {
      const nextLi = activeLi.nextElementSibling;
      if (nextLi && nextLi.classList.contains('ant-pagination-item') && !nextLi.classList.contains('ant-pagination-disabled')) {
        const btn = nextLi.querySelector('a, button') || nextLi;
        return btn;
      }
    }

    // 4. Phân trang Bootstrap / HTML table
    const bsNext = document.querySelector('.pagination li.next:not(.disabled) a, .pagination .page-item:not(.disabled) a[aria-label*="Next" i], .pagination [rel="next"]:not([disabled])');
    if (bsNext && !bsNext.closest('#dvcqg-auto-root') && bsNext.offsetParent !== null) {
      return bsNext;
    }

    // 5. Nút generic với aria-label hoặc title
    const genericNext = document.querySelector('button[aria-label*="next" i]:not([disabled]), a[aria-label*="next" i], button[title*="trang sau" i]:not([disabled]), button[title*="kế tiếp" i]:not([disabled])');
    if (genericNext && !genericNext.closest('#dvcqg-auto-root') && genericNext.offsetParent !== null) {
      return genericNext;
    }

    return null;
  }

  // Tự động kiểm tra và chọn 50 bản ghi/trang: <span class="ant-select-selection-item" title="50">50</span>
  async function ensurePageSize50() {
    try {
      // 1. Kiểm tra nếu trên trang đã chọn sẵn 50 bản ghi (<span class="ant-select-selection-item" title="50">50</span>)
      const current50 = Array.from(document.querySelectorAll('.ant-select-selection-item[title="50"], .ant-select-selection-item'))
        .find(el => !el.closest('#dvcqg-auto-root') && (el.getAttribute('title') === '50' || el.textContent.trim() === '50'));
      
      if (current50 && (current50.getAttribute('title') === '50' || current50.textContent.trim() === '50')) {
        return false; // Đã là 50 bản ghi/trang, không cần thao tác lại
      }

      // 2. Tìm thẻ span hiển thị số bản ghi hiện tại của Ant Design (.ant-select-selection-item)
      const selectSpans = Array.from(document.querySelectorAll('.ant-select-selection-item'))
        .filter(el => !el.closest('#dvcqg-auto-root') && el.offsetParent !== null);

      let targetSpan = null;
      for (const span of selectSpans) {
        const title = (span.getAttribute('title') || '').trim();
        const text = (span.textContent || '').trim();
        if (title === '50' || text === '50') {
          return false; // Đã là 50
        }
        // Thường có title hoặc text là các số phân trang (10, 20, 10 / trang, ...)
        if (/^\d{1,3}(\s*\/.*)?$/.test(title) || /^\d{1,3}(\s*\/.*)?$/.test(text)) {
          targetSpan = span;
          break;
        }
      }

      // Fallback: Tìm thẻ select nằm trong .ant-pagination / .ant-pagination-options
      if (!targetSpan) {
        const paginSpan = document.querySelector('.ant-pagination .ant-select-selection-item, nz-pagination .ant-select-selection-item, .ant-pagination-options .ant-select-selection-item');
        if (paginSpan && !paginSpan.closest('#dvcqg-auto-root')) {
          targetSpan = paginSpan;
        }
      }

      if (!targetSpan) {
        return false;
      }

      log('⚡ Đang tự động chuyển sang "50 bản ghi/trang" để tránh sót trạng thái KhoiTaoHoSoBN...', 'info');

      // Click vào trigger của Ant Design Select
      const trigger = targetSpan.closest('.ant-select-selector') || targetSpan.closest('.ant-select') || targetSpan;
      trigger.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      await sleep(150);

      trigger.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true }));
      trigger.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      trigger.click();
      trigger.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));

      // Đợi dropdown popup của Ant Design xuất hiện
      await sleep(350);

      // Tìm option 50: .ant-select-dropdown .ant-select-item-option[title="50"] hoặc [title="50"]
      let opt50 = document.querySelector('.ant-select-dropdown .ant-select-item-option[title="50"], .ant-select-dropdown [title="50"], .ant-select-item-option[title="50"]');
      if (!opt50) {
        const allOpts = Array.from(document.querySelectorAll('.ant-select-dropdown .ant-select-item-option, .ant-select-dropdown .ant-select-item, .cdk-overlay-container .ant-select-item-option'));
        for (const o of allOpts) {
          const t = (o.getAttribute('title') || o.textContent || '').trim();
          if (t === '50' || t.startsWith('50')) {
            opt50 = o;
            break;
          }
        }
      }

      if (opt50) {
        opt50.scrollIntoView({ behavior: 'auto', block: 'nearest' });
        opt50.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true }));
        opt50.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        opt50.click();
        opt50.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        log('✓ Đã chọn "50 bản ghi/trang" thành công! Đang chờ bảng tải dữ liệu mới...', 'success');
        await sleep(1500); // Đợi tải lại bảng 50 dòng
        return true;
      } else {
        document.body.click(); // Đóng popup nếu không tìm thấy
        await sleep(150);
      }
    } catch (err) {
      console.warn('[DVCQG Auto] Không thể tự động chọn số bản ghi 50:', err);
    }
    return false;
  }

  // =========================================================================
  // BỘ ĐỘNG CƠ TƯƠNG THÍCH TỐC ĐỘ TẢI THÔNG MINH (SMART ADAPTIVE LOADING ENGINE)
  // Tự động nhận diện mạng, spinner, bảng dữ liệu và modal để tránh bóc tách khi
  // dữ liệu chưa tải kịp (chống sót trạng thái hoặc đọc nhầm bảng cũ)
  // =========================================================================

  // Tìm bảng kết quả dữ liệu chính trên trang web
  function findTargetTable() {
    const tables = Array.from(document.querySelectorAll('table')).filter(t => !t.closest('#dvcqg-auto-root'));
    if (!tables.length) return null;
    for (const tbl of tables) {
      const rows = tbl.querySelectorAll('tbody tr');
      if (rows.length > 0) return tbl;
    }
    return tables[0];
  }

  // Đọc số lượng request mạng đang xử lý từ DOM dataset hoặc state
  function getActiveRequestsCount() {
    try {
      const docAttr = document.documentElement?.dataset?.dvcqgActiveRequests;
      if (docAttr !== undefined) {
        const parsed = parseInt(docAttr, 10);
        if (!isNaN(parsed)) return Math.max(0, parsed);
      }
    } catch (e) {}
    return Math.max(0, state.networkActiveCount || 0);
  }

  // Kiểm tra xem trang web hoặc bảng dữ liệu có đang trong trạng thái bận/tải không
  function isPageOrTableBusy(tableEl = null) {
    // 1. Kiểm tra các request mạng in-flight
    if (getActiveRequestsCount() > 0) return true;

    // 2. Kiểm tra các dấu hiệu spinner / loading overlay trong DOM
    const spinSelectors = [
      '.ant-spin-spinning',
      '.ant-spin-nested-loading > .ant-spin',
      '.ant-spin-dot',
      '.spinner-border',
      '.spinner-grow',
      '.loading',
      '.is-loading',
      '.mask-loading',
      '.el-loading-mask:not([style*="display: none"])',
      '[aria-busy="true"]',
      '.ant-btn-loading',
      'button.is-loading'
    ];
    for (const sel of spinSelectors) {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        if (!el.closest('#dvcqg-auto-root')) {
          const style = window.getComputedStyle(el);
          if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
            return true;
          }
        }
      }
    }

    // 3. Kiểm tra nút Tìm kiếm có bị disabled tạm thời do đang gửi request không
    const searchBtn = findSearchButton();
    if (searchBtn && (searchBtn.disabled || searchBtn.classList.contains('is-loading') || searchBtn.classList.contains('ant-btn-loading'))) {
      return true;
    }

    // 4. Kiểm tra placeholder "Đang tải dữ liệu..." trong bảng
    const currentTable = tableEl || findTargetTable();
    if (currentTable) {
      const placeholder = currentTable.querySelector('.ant-table-placeholder, .ant-empty, .loading-text');
      if (placeholder) {
        const txt = placeholder.textContent.toLowerCase();
        if (txt.includes('đang tải') || txt.includes('loading') || txt.includes('đang xử lý') || txt.includes('vui lòng đợi')) {
          return true;
        }
      }
    }

    return false;
  }

  // Chụp snapshot trạng thái bảng để so sánh dữ liệu trước và sau khi tìm kiếm / đổi trang
  function getTableSnapshot(targetTable = null) {
    const tbl = targetTable || findTargetTable();
    if (!tbl) return { exists: false, rowCount: 0, firstRow: '', allText: '' };
    const rows = Array.from(tbl.querySelectorAll('tbody tr'));
    const firstRow = rows[0]?.innerText?.trim() || '';
    const allText = rows.slice(0, 8).map(r => r.innerText?.trim() || '').join('||');
    return {
      exists: true,
      rowCount: rows.length,
      firstRow,
      allText
    };
  }

  // Chờ dữ liệu bảng tải hoàn tất 100% với cơ chế tương thích tốc độ tải thông minh
  async function waitForTableDataReady(prevSnapshot, targetMa = '', options = {}) {
    const startTime = Date.now();
    const isAdaptive = state.config.adaptiveSpeed;
    const speedMode = state.config.speedMode || 'adaptive'; // 'adaptive' | 'safe' | 'fast'

    // Cấu hình giới hạn thời gian và khoảng đệm theo chế độ tốc độ
    let maxWaitMs = 15000;
    let quietWaitMs = 350;
    if (speedMode === 'safe') {
      maxWaitMs = 25000;
      quietWaitMs = 650;
    } else if (speedMode === 'fast') {
      maxWaitMs = 8000;
      quietWaitMs = 200;
    }

    if (!isAdaptive) {
      await sleep(2500); // Chế độ dự phòng khi tắt tương thích
      return { elapsed: 2500, state: 'fixed_delay' };
    }

    log('⏳ [Tương thích tốc độ]: Đang theo dõi máy chủ nạp dữ liệu...', 'info');

    // GIAI ĐOẠN 1: Bắt đầu phát hiện phản hồi (trigger detection) trong tối đa 1.8s
    let triggerDetected = false;
    const triggerStart = Date.now();
    while (Date.now() - triggerStart < 1800) {
      if (isPageOrTableBusy()) {
        triggerDetected = true;
        break;
      }
      const currentSnap = getTableSnapshot();
      if (prevSnapshot && currentSnap.allText !== prevSnapshot.allText) {
        triggerDetected = true;
        break;
      }
      await sleep(70);
    }

    // GIAI ĐOẠN 2: Chờ máy chủ và DOM hoàn tất nạp dữ liệu
    while (Date.now() - startTime < maxWaitMs) {
      if (state.isStopping) break;

      const busy = isPageOrTableBusy();
      if (!busy) {
        const currentSnap = getTableSnapshot();

        // Nếu bảng vẫn giữ nguyên dữ liệu cũ của hồ sơ khác khi vừa bấm tìm kiếm, tiếp tục chờ
        const isSameOldData = prevSnapshot && prevSnapshot.rowCount > 0 && currentSnap.allText === prevSnapshot.allText;
        const hasWrongMa = targetMa && currentSnap.firstRow && !currentSnap.allText.includes(targetMa) && isSameOldData;

        if (hasWrongMa && (Date.now() - startTime < 3500)) {
          await sleep(150);
          continue;
        }

        // Đã hết bận: Chờ thêm khoảng quietWaitMs để các component React / Ant Design ổn định DOM
        await sleep(quietWaitMs);

        // Kiểm tra lại lần nữa sau khoảng quiet
        if (!isPageOrTableBusy()) {
          break;
        }
      }

      await sleep(120);
    }

    const elapsed = Date.now() - startTime;
    state.serverLatencyEstimate = Math.max(500, Math.min(8000, elapsed));

    if (elapsed > 3000) {
      log(`🐢 [Tương thích tốc độ]: Máy chủ DVCQG phản hồi chậm (~${(elapsed / 1000).toFixed(1)}s). Đã kiên nhẫn đợi dữ liệu nạp 100% để chống sót.`, 'warn');
    } else {
      log(`⚡ [Tương thích tốc độ]: Dữ liệu đã tải hoàn tất (~${(elapsed / 1000).toFixed(1)}s). Bắt đầu lấy dữ liệu.`, 'success');
    }

    return { elapsed, state: 'ready' };
  }

  // Tự động nhận diện và kích hoạt tab "Khối thông tin dữ liệu" / "Thông tin dữ liệu" / "Request Body"
  async function ensureDataTabActive(modal) {
    if (!modal) return false;
    const tabSelectors = '.ant-tabs-tab, .ant-tabs-tab-btn, .nav-link, button[role="tab"], [role="tab"], .nav-tabs li a, .nav-item a, button, [class*="tab"]';
    const tabs = Array.from(modal.querySelectorAll(tabSelectors));
    let clicked = false;

    // Tìm và click tab chứa Khối thông tin dữ liệu / Thông tin dữ liệu / Request Body
    for (const tab of tabs) {
      const txt = (tab.textContent || '').trim().toLowerCase();
      if (!txt) continue;
      // Tuyệt đối không click sang tab phản hồi / kết quả
      if (txt.includes('response') || txt.includes('phản hồi') || txt.includes('kết quả')) {
        continue;
      }

      const isTargetTab =
        txt.includes('khối thông tin dữ liệu') ||
        txt.includes('thông tin dữ liệu') ||
        txt.includes('khối thông tin') ||
        txt.includes('khối dữ liệu') ||
        txt.includes('dữ liệu gửi') ||
        txt.includes('dữ liệu yêu cầu') ||
        txt.includes('dữ liệu đồng bộ') ||
        txt.includes('dữ liệu request') ||
        txt.includes('request body') ||
        txt.includes('request') ||
        txt.includes('gói tin') ||
        txt.includes('nội dung xml') ||
        txt.includes('body') ||
        (txt.includes('dữ liệu') && !txt.includes('chung'));

      if (isTargetTab) {
        const isActive = tab.classList.contains('active') ||
                         tab.classList.contains('ant-tabs-tab-active') ||
                         tab.getAttribute('aria-selected') === 'true' ||
                         tab.closest('.ant-tabs-tab-active');
        if (!isActive) {
          tab.click();
          clicked = true;
          await sleep(150);
        }
        break;
      }
    }

    // Mở các panel accordion / collapse nếu bị thu gọn
    const collapseHeaders = Array.from(modal.querySelectorAll('.ant-collapse-header, .accordion-button, [data-toggle="collapse"]'));
    for (const header of collapseHeaders) {
      const ctxt = (header.textContent || '').trim().toLowerCase();
      if (
        ctxt.includes('khối thông tin dữ liệu') ||
        ctxt.includes('thông tin dữ liệu') ||
        ctxt.includes('khối thông tin') ||
        ctxt.includes('khối dữ liệu') ||
        ctxt.includes('dữ liệu gửi') ||
        ctxt.includes('gói tin') ||
        ctxt.includes('request')
      ) {
        const collapseItem = header.closest('.ant-collapse-item');
        if (collapseItem && !collapseItem.classList.contains('ant-collapse-item-active')) {
          header.click();
          clicked = true;
          await sleep(100);
        }
      }
    }

    return clicked;
  }

  // Chờ nội dung modal xem chi tiết và gói tin XML tải hoàn tất
  async function waitForModalDataReady(modal, statusName) {
    if (!modal) return null;
    const isAdaptive = state.config.adaptiveSpeed;

    // Đảm bảo click chuyển sang tab Khối thông tin dữ liệu
    await ensureDataTabActive(modal);

    if (!isAdaptive) {
      await sleep(800);
      await ensureDataTabActive(modal);
      return findXmlInElement(modal);
    }

    const startTime = Date.now();
    const speedMode = state.config.speedMode || 'adaptive';
    const maxWaitMs = speedMode === 'safe' ? 7000 : 4500;
    let foundXml = null;

    // Chờ tối thiểu 200ms cho modal animation
    await sleep(200);

    while (Date.now() - startTime < maxWaitMs) {
      if (state.isStopping) break;

      // 1. Tự động click các tab chứa khối thông tin dữ liệu nếu chưa active
      await ensureDataTabActive(modal);

      // 2. Tìm XML trong modal
      foundXml = findXmlInElement(modal);
      if (foundXml && isDvcqgEnvelope(foundXml)) {
        break; // Đã tìm thấy XML Envelope hợp lệ
      }

      // 3. Kiểm tra xem modal có đang hiện spinner tải không
      const modalSpin = modal.querySelector('.ant-spin-spinning, .spinner-border, .loading, [aria-busy="true"]');
      if (modalSpin || getActiveRequestsCount() > 0) {
        await sleep(150);
        continue;
      }

      await sleep(120);
    }

    const elapsed = Date.now() - startTime;
    if (elapsed > 1200) {
      log(`ℹ️ [Tương thích tốc độ]: Modal [${statusName}] nạp xong sau ${(elapsed / 1000).toFixed(1)}s.`, 'info');
    }

    return foundXml || findXmlInElement(modal);
  }

  // Chờ dữ liệu bảng trang mới nạp hoàn tất khi phân trang
  async function waitForTablePageChangeReady(prevFirstRowText, targetPage) {
    const isAdaptive = state.config.adaptiveSpeed;
    const speedMode = state.config.speedMode || 'adaptive';
    const maxWaitMs = speedMode === 'safe' ? 10000 : (isAdaptive ? 6000 : 3500);
    const intervalMs = 120;
    const startTime = Date.now();
    let loadedNewPage = false;

    while (Date.now() - startTime < maxWaitMs) {
      if (state.isStopping) break;

      const busy = isPageOrTableBusy();
      const currentTableNow = findTargetTable();
      const newFirstRow = currentTableNow?.querySelector('tbody tr')?.innerText?.trim() || '';

      if (!busy && newFirstRow && newFirstRow !== prevFirstRowText) {
        loadedNewPage = true;
        break;
      }
      await sleep(intervalMs);
    }

    await sleep(isAdaptive ? 350 : 200); // Ổn định DOM
    return loadedNewPage;
  }

  // Nhận dạng trạng thái của hàng dữ liệu bảng kết quả một cách linh hoạt, bắt trọn cả DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN
  function matchRowStatus(rowText, targetStatuses) {
    if (!rowText || typeof rowText !== 'string' || !targetStatuses || !targetStatuses.length) return null;

    // 1. Kiểm tra khớp chính xác chuỗi trạng thái đầy đủ trước (ưu tiên chuỗi dài hơn: DongBoThongTinThanhToanDVC, DongBoThongTinThanhToanBN)
    const sortedStatuses = [...targetStatuses].sort((a, b) => b.length - a.length);
    for (const st of sortedStatuses) {
      if (rowText.includes(st)) {
        return st;
      }
    }

    // 2. Kiểm tra không phân biệt hoa thường
    const lowerText = rowText.toLowerCase();
    for (const st of sortedStatuses) {
      if (lowerText.includes(st.toLowerCase())) {
        return st;
      }
    }

    // 3. Nếu hàng dữ liệu chứa từ khóa "DongBoThongTinThanhToan" hoặc "đồng bộ thông tin thanh toán" / "thanh toán DVC"
    if (
      lowerText.includes('dongbothongtinthanhtoan') ||
      lowerText.includes('đồng bộ thông tin thanh toán') ||
      lowerText.includes('dong bo thong tin thanh toan') ||
      lowerText.includes('thông tin thanh toán') ||
      lowerText.includes('thong tin thanh toan') ||
      lowerText.includes('thanh toán dvc') ||
      lowerText.includes('thanh toan dvc') ||
      lowerText.includes('thanhtoandvc')
    ) {
      if (lowerText.includes('dvc') || lowerText.includes('cổng dvc') || lowerText.includes('cong dvc') || lowerText.includes('quốc gia') || lowerText.includes('quoc gia')) {
        return targetStatuses.includes('DongBoThongTinThanhToanDVC') ? 'DongBoThongTinThanhToanDVC' : (targetStatuses.includes('DongBoThongTinThanhToanBN') ? 'DongBoThongTinThanhToanBN' : 'DongBoThongTinThanhToan');
      }
      if (lowerText.includes('bn') || lowerText.includes('bộ ngành') || lowerText.includes('bo nganh')) {
        return targetStatuses.includes('DongBoThongTinThanhToanBN') ? 'DongBoThongTinThanhToanBN' : (targetStatuses.includes('DongBoThongTinThanhToanDVC') ? 'DongBoThongTinThanhToanDVC' : 'DongBoThongTinThanhToan');
      }
      return targetStatuses.find(st => st === 'DongBoThongTinThanhToanDVC' || st === 'DongBoThongTinThanhToanBN' || st === 'DongBoThongTinThanhToan') || 'DongBoThongTinThanhToan';
    }

    // 4. Nếu hàng dữ liệu chứa từ khóa "BoSungHoSo" hoặc "bổ sung hồ sơ" / "yêu cầu bổ sung"
    if (
      lowerText.includes('bosunghoso') ||
      lowerText.includes('bổ sung hồ sơ') ||
      lowerText.includes('bo sung ho so') ||
      lowerText.includes('yêu cầu bổ sung') ||
      lowerText.includes('yeucaubosunghoso')
    ) {
      if (lowerText.includes('bn') || lowerText.includes('bộ ngành')) {
        return targetStatuses.includes('BoSungHoSoBN') ? 'BoSungHoSoBN' : (targetStatuses.includes('BoSungHoSoDVC') ? 'BoSungHoSoDVC' : 'YeuCauBoSungHoSoBN');
      }
      return targetStatuses.find(st => st === 'BoSungHoSoDVC' || st === 'BoSungHoSoBN' || st === 'YeuCauBoSungHoSoBN' || st === 'YeuCauBoSungHoSoDVC') || (targetStatuses.includes('BoSungHoSoDVC') ? 'BoSungHoSoDVC' : null);
    }

    return null;
  }

  // 4. Extraction Logic: Scanning Tables & Detail Modals với Phân trang thông minh (Hỗ trợ quét 1 mã hoặc toàn bộ hồ sơ trong khoảng thời gian)
  async function extractXmlFromTable(targetMa = '', existingRecords = [], onProgressCallback = null) {
    const isAllScan = !targetMa;
    log(`Bắt đầu phân tích bảng dữ liệu kết quả ${isAllScan ? '(Chế độ quét toàn bộ theo khoảng ngày)' : `cho mã [${targetMa}]`}...`, 'info');

    const targetStatuses = getTargetStatuses();
    const results = [];

    // Tập hợp các trạng thái đã thu thập để tránh lấy lặp lại nhiều lần
    // Nếu quét 1 mã: key = status. Nếu quét toàn bộ: key = maHoSo + '_' + status
    const collectedStatuses = new Set();
    if (state.config.deduplicateStatus) {
      (existingRecords || []).forEach(r => {
        if (r && r.status) {
          const key = isAllScan ? `${r.maHoSo || ''}_${r.status}` : r.status;
          collectedStatuses.add(key);
        }
      });
    }

    // Nếu tìm theo 1 mã: cho phép qua tối đa maxPagesPerSearch (mặc định 3 trang)
    // Nếu quét toàn bộ theo khoảng thời gian: cho phép quét tối đa maxPagesAllScan (mặc định 20 trang)
    const MAX_PAGES = isAllScan
      ? Math.max(10, parseInt(state.config.maxPagesAllScan || 20, 10))
      : Math.max(1, parseInt(state.config.maxPagesPerSearch || 3, 10));
    let currentPage = 1;

    while (currentPage <= MAX_PAGES) {
      if (state.isStopping) break;

      // Đảm bảo mở rộng 50 bản ghi/trang ở trang 1 nếu chưa chọn
      if (currentPage === 1) {
        const changed = await ensurePageSize50();
        if (changed) {
          await sleep(600);
        }
      }

      // Find table
      const tables = Array.from(document.querySelectorAll('table')).filter(t => !t.closest('#dvcqg-auto-root'));
      if (!tables.length) {
        if (currentPage === 1) log('Chưa tìm thấy bảng dữ liệu trên trang!', 'error');
        break;
      }

      // Pick the most likely table (with rows)
      let targetTable = null;
      let tableRows = [];
      for (const tbl of tables) {
        const rows = tbl.querySelectorAll('tbody tr');
        if (rows.length > 0) {
          targetTable = tbl;
          tableRows = Array.from(rows);
          break;
        }
      }

      if (!tableRows.length) {
        if (currentPage === 1) log('Bảng không có hàng dữ liệu nào (kết quả rỗng hoặc chưa load)!', 'warn');
        break;
      }

      const pageLabel = currentPage > 1 ? `[Trang ${currentPage}] ` : '';
      log(`${pageLabel}Tìm thấy ${tableRows.length} hàng dữ liệu trong bảng. Đang rà soát trạng thái từ dưới lên (hàng ${tableRows.length} ➜ 1)...`, 'info');

      for (let i = tableRows.length - 1; i >= 0; i--) {
        if (state.isStopping) break;

        const row = tableRows[i];
        const rowText = row.innerText || '';

        // Check which status matches this row (bắt trọn cả DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN)
        const matchedStatus = matchRowStatus(rowText, targetStatuses);
        if (!matchedStatus) {
          continue;
        }

        // Bóc tách Mã hồ sơ của dòng này (khi quét toàn bộ)
        let rowMa = targetMa;
        if (isAllScan) {
          const parsed = parseMaHoSoList(rowText);
          rowMa = parsed[0] || '';
          if (!rowMa) {
            // Thử duyệt từng ô td để trích xuất mã hồ sơ nếu có
            const cells = Array.from(row.querySelectorAll('td'));
            for (const cell of cells) {
              const cellText = (cell.innerText || '').trim();
              const cellParsed = parseMaHoSoList(cellText);
              if (cellParsed[0]) {
                rowMa = cellParsed[0];
                break;
              }
            }
          }
        }

        const statusKey = isAllScan ? `${rowMa || ('row_' + currentPage + '_' + (i + 1))}_${matchedStatus}` : matchedStatus;
        const isPaymentRow = matchedStatus && (matchedStatus.includes('DongBoThongTinThanhToan') || matchedStatus.includes('ThanhToan'));

        // TRÁNH LẤY LẶP: Nếu trạng thái này đã được lấy cho hồ sơ này, bỏ qua ngay (không cần mở modal)
        // Riêng với các khối thanh toán (DongBoThongTinThanhToanDVC & DongBoThongTinThanhToanBN):
        // KHÔNG bỏ qua sớm ở cấp bảng nếu khác mã trạng thái hoặc khác nội dung XML để tránh mất các đợt nộp phí / biên lai khác nhau
        if (state.config.deduplicateStatus && !isPaymentRow && collectedStatuses.has(statusKey)) {
          log(`--> ⏭ ${pageLabel}Bỏ qua dòng [${matchedStatus}] ${rowMa ? `hồ sơ ${rowMa}` : ''} vì đã có khối trạng thái này (tránh lấy lặp)`, 'info');
          continue;
        }

        // Check COMPLETED / SUCCESS status if option is enabled (hỗ trợ cả COMPLETED và SUCCESS, đặc biệt cho DongBoThongTinThanhToanDVC)
        if (state.config.onlyCompleted) {
          const upperText = rowText.toUpperCase();
          const isCompleted = upperText.includes('COMPLETED');
          const isSuccess = upperText.includes('SUCCESS') || upperText.includes('THÀNH CÔNG') || upperText.includes('THANH CONG');
          if (!isCompleted && !isSuccess) {
            log(`--> ${pageLabel}Bỏ qua dòng [${matchedStatus}] ${rowMa ? `(Mã: ${rowMa})` : ''} vì không ở trạng thái COMPLETED hoặc SUCCESS`, 'warn');
            continue;
          }
        }

        const statusTag = (rowText.toUpperCase().includes('SUCCESS') || rowText.includes('Thành công')) ? 'SUCCESS ✓' : 'COMPLETED ✓';
        log(`--> ${pageLabel}Phát hiện dòng trạng thái [${matchedStatus}] ${rowMa ? `(Mã: ${rowMa})` : `(hàng ${i + 1})`} - ${statusTag}`, 'info');

        // Báo tiến trình live đang duyệt dòng từ dưới lên
        const processedRows = tableRows.length - i;
        if (typeof onProgressCallback === 'function') {
          onProgressCallback({
            type: 'ROW_SCANNING',
            status: matchedStatus,
            maHoSo: rowMa || targetMa,
            row: i + 1,
            processedRows,
            totalRows: tableRows.length,
            page: currentPage,
            maxPages: MAX_PAGES,
            liveCombined: [...existingRecords, ...results]
          });
        }

        // 1. Check if XML is already embedded in row DOM or dataset
        let xml = findXmlInElement(row);

        // 2. Check if we already captured it via network (hỗ trợ cả DongBoThongTinThanhToanDVC và DongBoThongTinThanhToanBN)
        if (!xml && state.capturedNetworkXml.length) {
          const matchedStep = findStepByStatus(matchedStatus);
          const aliasStatuses = matchedStep ? (matchedStep.aliases || [matchedStep.key]) : [matchedStatus];

          const netMatch = state.capturedNetworkXml.find(item => {
            if (!item.xml || !isDvcqgEnvelope(item.xml)) return false;
            const hasStatus = aliasStatuses.some(st => item.xml.includes(st));
            if (!hasStatus) return false;
            if (rowMa && !item.xml.includes(rowMa)) return false;
            if (item.used) return false;
            return true;
          });
          if (netMatch) {
            xml = netMatch.xml;
            netMatch.used = true; // Đánh dấu đã sử dụng để không lấy lặp
            log(`${pageLabel}Lấy được Envelope [${matchedStatus}] ${rowMa ? `(Mã: ${rowMa})` : ''} từ cache mạng.`, 'success');
          }
        }

        // 3. Fallback: Click "Xem" / "Chi tiết" / eye icon to open modal
        if (!xml) {
          xml = await openRowDetailAndExtractXml(row, matchedStatus);
        }

        if (xml) {
          const cleanXml = sanitizeXmlString(xml);
          if (cleanXml && isDvcqgEnvelope(cleanXml)) {
            // Xác định chính xác service/status thực tế từ thẻ <Service> trong XML nếu có (ví dụ DongBoThongTinThanhToanDVC)
            const serviceMatch = cleanXml.match(/<Service\b[^>]*>([^<]+)<\/Service>/i);
            const actualStatus = (serviceMatch && serviceMatch[1].trim()) || matchedStatus;

            // Kiểm tra trùng lặp nội dung XML với các khối đã có
            const norm = normalizeXml(cleanXml);
            const isXmlDuplicatedInExisting = (existingRecords || []).some(r => normalizeXml(r.xml) === norm);
            const isXmlDuplicatedInResults = results.some(r => normalizeXml(r.xml) === norm);

            if (isXmlDuplicatedInExisting || isXmlDuplicatedInResults) {
              log(`--> ⏭ ${pageLabel}Bỏ qua dòng [${actualStatus}] vì nội dung XML bị trùng lặp hoàn toàn với khối đã có`, 'warn');
            } else {
              const newRecord = {
                status: actualStatus,
                xml: cleanXml,
                maHoSo: rowMa || '',
                index: results.length
              };
              results.push(newRecord);
              if (state.config.deduplicateStatus) {
                collectedStatuses.add(statusKey);
                collectedStatuses.add(actualStatus);
                collectedStatuses.add(matchedStatus);
                if (rowMa) {
                  collectedStatuses.add(`${rowMa}_${actualStatus}`);
                  collectedStatuses.add(`${rowMa}_${matchedStatus}`);
                }
              }

              // CẬP NHẬT TIẾN TRÌNH LIVE NGAY TỨC THÌ (KHÔNG ĐỢI THU THẬP XONG MỚI HIỂN THỊ)
              const liveCombined = [...existingRecords, ...results];
              const liveSteps = updateStepTracker(liveCombined);

              // Cập nhật số khối XML trích xuất tức thì lên badge
              const countEl = document.getElementById('dvcqg-extracted-count');
              if (countEl) {
                if (isAllScan) {
                  const uniqueMa = new Set(liveCombined.map(r => r.maHoSo).filter(Boolean));
                  countEl.textContent = `${liveCombined.length} khối (${uniqueMa.size} HS)`;
                } else {
                  countEl.textContent = `${liveCombined.length} khối (${liveSteps}/${STEP_DEFINITIONS.length} steps)`;
                }
              }

              // Lưu state tức thì để nút Xem XML hoặc Dừng đều có ngay dữ liệu đã thu thập
              state.extractedXmlBlocks = liveCombined;
              state.lastExtractedCombined = combineXmlBlocks(liveCombined);

              if (typeof onProgressCallback === 'function') {
                onProgressCallback({
                  type: 'RECORD_EXTRACTED',
                  record: newRecord,
                  status: matchedStatus,
                  maHoSo: rowMa || targetMa,
                  row: i + 1,
                  totalRows: tableRows.length,
                  page: currentPage,
                  maxPages: MAX_PAGES,
                  stepsCount: liveSteps,
                  liveCombined
                });
              }

              // Bóc tách encoding thực tế để log rõ ràng (UTF-8 hoặc utf-8)
              const encMatch = cleanXml.match(/encoding\s*=\s*(["']?)([^"'\s?]+)\1/i);
              const encDisplay = encMatch ? encMatch[2] : 'UTF-8';
              log(`✓ ${pageLabel}Đã trích xuất thành công Khối thông tin dữ liệu (<?xml version="1.0" encoding="${encDisplay}"?> <Envelope xmlns="http://dichvucong.gov.vn/api/v1">) của [${matchedStatus}] ${rowMa ? `(Mã: ${rowMa})` : ''}`, 'success');
            }
          } else {
            log(`⚠️ ${pageLabel}Bỏ qua dòng [${matchedStatus}]: Nội dung không phải Khối thông tin dữ liệu Envelope hợp lệ (Hỗ trợ <?xml...encoding="UTF-8"|"utf-8"?> <Envelope xmlns="http://dichvucong.gov.vn/api/v1">)`, 'warn');
          }
        } else {
          log(`⚠️ ${pageLabel}Không tìm thấy Khối thông tin dữ liệu Envelope cho dòng [${matchedStatus}]`, 'warn');
        }

        await sleep(250);
      }

      // KIỂM TRA PHÂN TRANG THÔNG MINH:
      if (!isAllScan) {
        // NÂNG CẤP THÔNG MINH: Kiểm tra xem hồ sơ này có phát sinh Yêu cầu tài chính không
        const allKnownStatuses = new Set([
          ...Array.from(collectedStatuses),
          ...(existingRecords || []).map(r => r.status),
          ...results.map(r => r.status)
        ]);
        const tableHasYeuCauTC = Array.from(allKnownStatuses).some(st => st && st.includes('TaoYeuCauThucHienNghiaVuTaiChinh'));
        const tableHasHuyTC = Array.from(allKnownStatuses).some(st => st && st.includes('HuyYeuCauThucHienNghiaVuTaiChinh'));
        const tableHasThanhToan = Array.from(allKnownStatuses).some(st => st && (st.includes('DongBoThongTinThanhToan') || st.includes('ThanhToan')));
        const requirePaymentData = tableHasYeuCauTC && !tableHasHuyTC;

        // Khi tìm 1 mã hồ sơ cụ thể: Kiểm tra xem đã lấy đủ tất cả các bước được chọn chưa (hỗ trợ các bí danh DVC / BN)
        const allSelectedDone = STEP_DEFINITIONS.every(step => {
          const isStepSelected = state.config.selectedStatuses[step.key] || (step.aliases && step.aliases.some(a => state.config.selectedStatuses[a]));
          if (!isStepSelected) return true;
          // Nếu hồ sơ có Yêu cầu tài chính (chưa bị hủy), bước thanh toán là BẮT BUỘC (không được bỏ qua theo isOptional)
          const isPaymentStep = step.key === 'DongBoThongTinThanhToan' || (step.aliases && step.aliases.includes('DongBoThongTinThanhToanBN'));
          if (isPaymentStep && requirePaymentData) {
            return tableHasThanhToan;
          }
          if (step.isOptional) return true;
          const stepStatuses = step.aliases || [step.key];
          return stepStatuses.some(st => collectedStatuses.has(st));
        });
        if (allSelectedDone) {
          log(`🎯 Đã tìm thấy đầy đủ tất cả các trạng thái yêu cầu! Hoàn tất quét bảng.`, 'success');
          break;
        }
      }

      // Kiểm tra chuyển sang trang tiếp theo
      const nextPageBtn = findNextPageElement();
      if (nextPageBtn && currentPage < MAX_PAGES) {
        if (typeof onProgressCallback === 'function') {
          onProgressCallback({
            type: 'PAGE_CHANGE',
            page: currentPage + 1,
            maxPages: MAX_PAGES,
            liveCombined: [...existingRecords, ...results]
          });
        }
        // Kiểm tra xem có đang thiếu thanh toán do hồ sơ có Yêu cầu tài chính không
        const allKnownStatusesNow = new Set([
          ...Array.from(collectedStatuses),
          ...(existingRecords || []).map(r => r.status),
          ...results.map(r => r.status)
        ]);
        const currentHasYeuCauTC = Array.from(allKnownStatusesNow).some(st => st && st.includes('TaoYeuCauThucHienNghiaVuTaiChinh'));
        const currentHasHuyTC = Array.from(allKnownStatusesNow).some(st => st && st.includes('HuyYeuCauThucHienNghiaVuTaiChinh'));
        const currentHasThanhToan = Array.from(allKnownStatusesNow).some(st => st && (st.includes('DongBoThongTinThanhToan') || st.includes('ThanhToan')));
        const requirePaymentNow = currentHasYeuCauTC && !currentHasHuyTC;

        const missingList = STEP_DEFINITIONS
          .filter(step => {
            const isStepSelected = state.config.selectedStatuses[step.key] || (step.aliases && step.aliases.some(a => state.config.selectedStatuses[a]));
            if (!isStepSelected) return false;
            const isPaymentStep = step.key === 'DongBoThongTinThanhToan' || (step.aliases && step.aliases.includes('DongBoThongTinThanhToanBN'));
            if (isPaymentStep && requirePaymentNow && !currentHasThanhToan) {
              return true; // Báo thiếu thanh toán do hồ sơ có Yêu cầu tài chính
            }
            if (step.isOptional) return false;
            const stepStatuses = step.aliases || [step.key];
            return !stepStatuses.some(st => collectedStatuses.has(st));
          })
          .map(step => {
            const isPaymentStep = step.key === 'DongBoThongTinThanhToan' || (step.aliases && step.aliases.includes('DongBoThongTinThanhToanBN'));
            if (isPaymentStep && requirePaymentNow && !currentHasThanhToan) {
              return `${step.label} (BẮT BUỘC do có Y/c tài chính)`;
            }
            return step.label;
          });
        const nextInfo = isAllScan
          ? `📄 [Trang ${currentPage}/${MAX_PAGES}]: Tiếp tục chuyển sang trang ${currentPage + 1} để quét toàn bộ hồ sơ...`
          : `📄 [Trang ${currentPage}/${MAX_PAGES}]: Chưa đủ trạng thái (đang thiếu: [${missingList.join(', ')}]). Nhấn "Trang sau" để sang trang ${currentPage + 1}...`;
        log(nextInfo, 'info');

        // Ghi lại nội dung hàng đầu tiên hiện tại để nhận biết khi nào trang mới đã tải xong
        const prevFirstRowText = targetTable?.querySelector('tbody tr')?.innerText || '';

        // Kích hoạt click "Trang sau" an toàn cho Ant Design / React
        try {
          nextPageBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          await sleep(150);
          nextPageBtn.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
          nextPageBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
          nextPageBtn.focus?.();
          nextPageBtn.click();
          nextPageBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        } catch (e) {
          nextPageBtn.click();
        }

        // Đợi dữ liệu bảng trang tiếp theo nạp xong bằng cơ chế tương thích tốc độ tải thông minh
        const loadedNewPage = await waitForTablePageChangeReady(prevFirstRowText, currentPage + 1);

        if (loadedNewPage) {
          log(`✓ Đã chuyển sang trang ${currentPage + 1} thành công. Bắt đầu quét tiếp dữ liệu...`, 'info');
        } else {
          log(`ℹ️ Đã chuyển sang trang ${currentPage + 1}. Bắt đầu quét tiếp dữ liệu...`, 'info');
        }

        currentPage++;
      } else {
        if (isAllScan) {
          log(`ℹ️ [Trang ${currentPage}]: Đã hoàn tất quét tất cả các trang kết quả trong khoảng thời gian (${currentPage} trang).`, 'success');
        } else if (currentPage >= MAX_PAGES) {
          const missingList = targetStatuses.filter(st => !collectedStatuses.has(st));
          log(`ℹ️ [Đợt này]: Đã qua tối đa ${MAX_PAGES} trang nhưng chưa tìm thấy [${missingList.join(', ')}]. Chuyển trạng thái/đợt tiếp theo...`, 'warn');
        } else if (!nextPageBtn && currentPage > 1) {
          log(`ℹ️ [Trang ${currentPage}]: Đã duyệt đến trang cuối cùng của bảng kết quả.`, 'info');
        }
        break;
      }
    }

    return results;
  }

  // Open modal for a specific row and extract Request Body với cơ chế tương thích tốc độ tải
  async function openRowDetailAndExtractXml(row, statusName) {
    const viewBtn = row.querySelector(
      'button, a, i.bi-eye, i.fa-eye, .anticon-eye, svg[data-icon="eye"], [title*="chi tiết" i], [title*="xem" i]'
    ) || row.querySelector('td:last-child button, td:last-child a');

    if (!viewBtn) {
      log(`Không tìm thấy nút xem chi tiết ở dòng [${statusName}]`, 'warn');
      return null;
    }

    log(`Đang mở chi tiết dòng [${statusName}]...`, 'info');
    viewBtn.click();

    // Chờ modal xuất hiện
    let modal = null;
    const modalStart = Date.now();
    while (Date.now() - modalStart < 3000) {
      modal = document.querySelector(
        '.modal.show, .modal[style*="display: block"], .ant-modal:not([style*="display: none"]), .ant-modal-content, [role="dialog"], .el-dialog'
      );
      if (modal) break;
      await sleep(100);
    }

    if (!modal) {
      log('Không tìm thấy modal mở ra sau khi click chi tiết!', 'warn');
      return null;
    }

    // Chế độ tương thích tốc độ tải: Chờ nội dung modal và gói tin XML nạp xong 100%
    const xml = await waitForModalDataReady(modal, statusName);

    // Close modal
    const closeBtn = modal.querySelector(
      'button.close, .ant-modal-close, button[aria-label="Close"], button:has(.bi-x), button:has(.fa-times), button[title*="Đóng" i]'
    ) || Array.from(modal.querySelectorAll('button')).find(b => b.textContent.trim().toLowerCase() === 'đóng');

    if (closeBtn) {
      closeBtn.click();
    } else {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    }
    await sleep(250);

    return xml;
  }

  // Giải mã các thẻ tag XML bị escape trong HTML mà TUYỆT ĐỐI BẢO TOÀN ký tự &amp; của dữ liệu XML gốc
  function safeDecodeXmlTags(str) {
    if (!str || typeof str !== 'string') return '';
    // Chỉ giải mã khi bản thân thẻ XML bị escape dạng &lt;Envelope hoặc &lt;?xml (không phân biệt hoa/thường)
    if (!str.includes('&lt;Envelope') && !/&lt;\?xml/i.test(str)) {
      return str;
    }

    // Nếu có chứa &amp;amp; (bị double encode trong HTML), chuyển về &amp;
    let decoded = str.replace(/&amp;amp;/g, '&amp;');

    // Chỉ decode các ký tự cấu trúc tag XML, TUYỆT ĐỐI KHÔNG decode &amp; thành &
    decoded = decoded
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'");

    return decoded;
  }

  // Đảm bảo và khôi phục tất cả các ký tự & trong XML đều là entity &amp; hợp lệ theo chuẩn W3C
  // Tuyệt đối không làm mất &amp; thành & đơn lẻ, đảm bảo toàn vẹn dữ liệu gốc ban đầu
  function restoreXmlAmpersands(xml) {
    if (!xml || typeof xml !== 'string') return '';
    // 1. Chuẩn hóa &amp;amp; (nếu bị double escape thừa) về đúng &amp;
    let res = xml.replace(/&amp;amp;/g, '&amp;');
    // 2. Chuyển bất kỳ dấu & đơn lẻ/trần nào (không phải entity XML hợp lệ) thành &amp;
    // Entity XML hợp lệ: &amp;, &lt;, &gt;, &quot;, &apos;, &#123;, &#x1A;
    res = res.replace(/&(?!amp;|lt;|gt;|quot;|apos;|#\d+;|#x[0-9a-fA-F]+;)/gi, '&amp;');
    return res;
  }

  // Chuẩn hóa và bảo đảm từng khối XML đều có đầy đủ tiền tố <?xml version="1.0" encoding="UTF-8"?> hoặc <?xml version="1.0" encoding="utf-8"?>
  // Tối ưu nhận diện linh hoạt và bảo toàn cả 2 định dạng "UTF-8" và "utf-8"
  // và khôi phục tất cả thực thể XML &amp; hợp lệ theo chuẩn W3C
  function formatEnvelopeXml(xml) {
    if (!xml || typeof xml !== 'string') return '';
    let res = restoreXmlAmpersands(xml.trim());
    
    // Kiểm tra xem đã có sẵn khai báo <?xml ... ?> hay chưa (không phân biệt hoa/thường)
    const xmlHeaderMatch = res.match(/^<\?xml\b([^?]*)\?>/i);
    if (!xmlHeaderMatch) {
      // Mặc định bổ sung đầy đủ khai báo chuẩn nếu khối dữ liệu bị thiếu (UTF-8)
      res = `<?xml version="1.0" encoding="UTF-8"?>\n${res}`;
    } else {
      const attrs = xmlHeaderMatch[1] || '';
      
      // Nhận diện encoding: tối ưu nhận cả 2 định dạng "UTF-8" và "utf-8"
      const encMatch = attrs.match(/encoding\s*=\s*(["']?)([^"'\s?]+)\1/i);
      let targetEncoding = 'UTF-8';
      if (encMatch) {
        const detectedEnc = encMatch[2];
        if (detectedEnc.toLowerCase() === 'utf-8') {
          // Bảo toàn chính xác định dạng "utf-8" (thường) hoặc "UTF-8" (hoa) của dữ liệu nguồn
          targetEncoding = (detectedEnc === 'utf-8') ? 'utf-8' : 'UTF-8';
        } else {
          targetEncoding = detectedEnc;
        }
      }
      
      // Bóc tách version nếu có (mặc định 1.0)
      const verMatch = attrs.match(/version\s*=\s*(["']?)([^"'\s?]+)\1/i);
      const targetVersion = verMatch ? verMatch[2] : '1.0';
      
      // Chuẩn hóa tiền tố <?xml ... ?> giữ nguyên định dạng "UTF-8" hoặc "utf-8"
      const cleanHeader = `<?xml version="${targetVersion}" encoding="${targetEncoding}"?>\n`;
      res = res.replace(/^<\?xml\b[^?]*\?>\s*/i, cleanHeader);
    }
    return res;
  }

  // Strict regex matching <?xml ...?> (tùy chọn) kết hợp <Envelope xmlns="http://dichvucong.gov.vn/api/v1"> hoặc <Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  const DVCQG_ENVELOPE_REGEX = /(?:<\?xml\b[^?]*\?>\s*(?:<!--[\s\S]*?-->\s*)*)?<Envelope\b(?![^>]*\bxmlns(?::\w+)?\s*=\s*["'][^"']*(?:soap-envelope|schemas\.xmlsoap\.org))(?=[^>]*(?:\bxmlns(?::\w+)?\s*=\s*["']https?:\/\/dichvucong\.gov\.vn\/api\/v1\/?["']|\bxmlns:(?:xsi|xsd)\s*=\s*["']https?:\/\/www\.w3\.org\/2001\/XMLSchema(?:-instance)?\/?["']))[^>]*>[\s\S]*?<\/Envelope>/gi;

  // Extract all valid Envelope blocks from a raw string, bảo toàn đầy đủ dữ liệu gốc ban đầu
  function extractDvcqgEnvelopes(rawStr) {
    if (!rawStr || typeof rawStr !== 'string') return [];

    // Giải mã an toàn các tag XML bị escape, tuyệt đối bảo toàn &amp; nguyên bản
    let str = safeDecodeXmlTags(rawStr);

    // Unescape JSON slashes và escape characters nếu có
    if (str.includes('\\/')) str = str.replace(/\\\//g, '/');
    if (str.includes('\\"')) str = str.replace(/\\"/g, '"');
    if (str.includes('\\r')) str = str.replace(/\\r/g, '\r');
    if (str.includes('\\n')) str = str.replace(/\\n/g, '\n');
    if (str.includes('\\t')) str = str.replace(/\\t/g, '\t');

    if (!str.includes('<Envelope')) {
      return [];
    }

    const hasDvcqgNs = str.includes('http://dichvucong.gov.vn/api/v1') || str.includes('https://dichvucong.gov.vn/api/v1');
    const hasXmlSchema = str.includes('http://www.w3.org/2001/XMLSchema') || str.includes('https://www.w3.org/2001/XMLSchema');
    if (!hasDvcqgNs && !hasXmlSchema) {
      return [];
    }

    const matches = str.match(DVCQG_ENVELOPE_REGEX);
    if (!matches) return [];

    // Định dạng khối XML Envelope chuẩn hóa: <?xml version="1.0" encoding="UTF-8"?> <Envelope xmlns="http://dichvucong.gov.vn/api/v1">
    return matches
      .map(m => formatEnvelopeXml(m.trim()))
      .filter(m => isDvcqgEnvelope(m));
  }

  // Check if a string is strictly a valid Envelope (cho phép tiền tố <?xml ...?> và chứa namespace hợp lệ)
  function isDvcqgEnvelope(str) {
    if (!str || typeof str !== 'string') return false;
    let trimmed = str.trim();
    // Bỏ tiền tố <?xml ... ?> nếu có để kiểm tra cấu trúc Envelope
    trimmed = trimmed.replace(/^<\?xml\b[^?]*\?>\s*/i, '');
    if (!trimmed.startsWith('<Envelope') || !trimmed.endsWith('</Envelope>')) {
      return false;
    }
    // Loại trừ hoàn toàn vỏ bọc SOAP Envelope ngoài cùng
    if (/<Envelope\b[^>]*\bxmlns(?::\w+)?\s*=\s*["'][^"']*(?:soap-envelope|schemas\.xmlsoap\.org)/i.test(trimmed)) {
      return false;
    }
    const hasDvcqgNs = /<Envelope\b[^>]*\bxmlns(?::\w+)?\s*=\s*["']https?:\/\/dichvucong\.gov\.vn\/api\/v1\/?["']/i.test(trimmed);
    const hasXmlSchemaNs = /<Envelope\b[^>]*\bxmlns:(?:xsi|xsd)\s*=\s*["']https?:\/\/www\.w3\.org\/2001\/XMLSchema(?:-instance)?\/?["']/i.test(trimmed);
    return hasDvcqgNs || hasXmlSchemaNs;
  }

  // Regex and helper to extract clean DVCQG Envelope XML from element
  function findXmlInElement(el) {
    if (!el) return null;

    // 1. Kiểm tra các container code, input, textarea, code view, editor
    const codeHolders = el.querySelectorAll(
      'pre, code, textarea, input, div.json-view, div.xml-view, [class*="code"], [class*="xml"], ' +
      '[class*="editor"], [class*="content"], [class*="body"], .ant-input, .form-control, ' +
      '.monaco-editor, .ace_editor, .CodeMirror'
    );
    for (const holder of codeHolders) {
      const content = holder.value || holder.getAttribute('value') || holder.textContent || holder.innerText || '';
      const list = extractDvcqgEnvelopes(content);
      if (list.length > 0) return list[0];
    }

    // 2. Tìm kiếm trong các form item / panel có nhãn "Khối thông tin dữ liệu" / "Thông tin dữ liệu"
    const allLabels = el.querySelectorAll('label, .ant-form-item-label, .title, h4, h5, strong, b, th, span');
    for (const lbl of allLabels) {
      const lblText = (lbl.textContent || '').trim().toLowerCase();
      if (
        lblText === 'khối thông tin dữ liệu' ||
        lblText === 'thông tin dữ liệu' ||
        lblText.includes('khối thông tin dữ liệu') ||
        lblText.includes('thông tin dữ liệu') ||
        lblText.includes('request body') ||
        lblText.includes('dữ liệu gửi')
      ) {
        const container = lbl.closest('.ant-form-item, .form-group, tr, div') || lbl.parentElement;
        if (container) {
          const raw = container.innerText || container.textContent || '';
          const list = extractDvcqgEnvelopes(raw);
          if (list.length > 0) return list[0];
        }
      }
    }

    // 3. Check innerText or textContent of the whole container
    const rawText = el.innerText || el.textContent || '';
    const listFromText = extractDvcqgEnvelopes(rawText);
    if (listFromText.length > 0) return listFromText[0];

    // 4. Check innerHTML in case it was encoded
    const rawHtml = el.innerHTML || '';
    const listFromHtml = extractDvcqgEnvelopes(rawHtml);
    if (listFromHtml.length > 0) return listFromHtml[0];

    return null;
  }

  function sanitizeXmlString(xml) {
    if (!xml) return '';
    const envelopes = extractDvcqgEnvelopes(xml);
    if (envelopes.length > 0) {
      return envelopes[0];
    }
    return '';
  }

  // Combine multiple XML blocks in standard order, deduplicating identical status or content
  function combineXmlBlocks(records) {
    const priority = {
      KhoiTaoHoSoBN: 1,
      KhoiTaoHoSoDVC: 1,
      TiepNhanHoSoBN: 2,
      TiepNhanHoSoDVC: 2,
      BoSungHoSoDVC: 2.5,
      BoSungHoSoBN: 2.5,
      YeuCauBoSungHoSoBN: 2.5,
      YeuCauBoSungHoSoDVC: 2.5,
      CapNhatTienTrinhXuLyHoSoBN: 3,
      CapNhatTienTrinhXuLyHoSoDVC: 3,
      GiaHanXuLyHoSoBN: 4,
      GiaHanXuLyHoSoDVC: 4,
      TaoYeuCauThucHienNghiaVuTaiChinhBN: 5,
      TaoYeuCauThucHienNghiaVuTaiChinhDVC: 5,
      HuyYeuCauThucHienNghiaVuTaiChinhBN: 6,
      HuyYeuCauThucHienNghiaVuTaiChinhDVC: 6,
      DongBoThongTinThanhToan: 7,
      DongBoThongTinThanhToanBN: 7,
      DongBoThongTinThanhToanDVC: 7,
      TraKetQuaBN: 8,
      TraKetQuaDVC: 8
    };

    // Filter to ensure strictly valid <Envelope> blocks
    const validRecords = records.filter(r => r && r.xml && isDvcqgEnvelope(r.xml));

    // Deduplicate: tránh lấy lặp nhiều khối trạng thái giống nhau hoặc khối XML giống hệt nhau
    const deduplicated = [];
    const seenStatusPerMa = new Set();
    const seenXmlSet = new Set();

    for (const r of validRecords) {
      const norm = normalizeXml(r.xml);
      if (seenXmlSet.has(norm)) continue; // Loại bỏ khối XML trùng lặp 100%

      const maKey = (r.maHoSo || 'default') + '_' + r.status;
      const isPaymentStatus = r.status.includes('DongBoThongTinThanhToan') || r.status.includes('ThanhToan');
      if (state.config.deduplicateStatus && !isPaymentStatus) {
        if (seenStatusPerMa.has(maKey)) continue; // Mỗi mã hồ sơ chỉ lấy duy nhất 1 khối cho mỗi trạng thái (cho phép nhiều giao dịch thanh toán khác nhau)
        seenStatusPerMa.add(maKey);
      }

      seenXmlSet.add(norm);
      deduplicated.push(r);
    }

    // Sort by MaHoSo and by business process (KhoiTaoHoSoBN luôn đứng vị trí 1 đầu tiên)
    deduplicated.sort((a, b) => {
      if (a.maHoSo && b.maHoSo && a.maHoSo !== b.maHoSo) {
        return a.maHoSo.localeCompare(b.maHoSo);
      }
      const pA = priority[a.status] || 99;
      const pB = priority[b.status] || 99;
      if (pA !== pB) return pA - pB;
      return (a.index || 0) - (b.index || 0);
    });

    // Cảnh báo nếu hồ sơ nào bị thiếu khối bắt buộc KhoiTaoHoSoBN đầu tiên hoặc thiếu DongBoThongTinThanhToan khi có Y/c tài chính
    const uniqueMaList = Array.from(new Set(validRecords.map(r => r.maHoSo).filter(Boolean)));
    uniqueMaList.forEach(ma => {
      const maRecords = deduplicated.filter(r => r.maHoSo === ma);
      const hasKhoiTao = maRecords.some(r => r.status === 'KhoiTaoHoSoBN' || r.status === 'KhoiTaoHoSoDVC');
      if (!hasKhoiTao) {
        log(`⚠️ Chú ý: Hồ sơ [${ma}] chưa có giá trị [KhoiTaoHoSoBN] đầu tiên!`, 'warn');
      }
      const hasYc = maRecords.some(r => r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhDVC');
      const hasHuy = maRecords.some(r => r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhDVC');
      const hasTt = maRecords.some(r => r.status.includes('DongBoThongTinThanhToan') || r.status.includes('ThanhToan'));
      if (hasYc && !hasHuy && !hasTt) {
        log(`⚠️ Chú ý: Hồ sơ [${ma}] có Yêu cầu tài chính nhưng CHƯA CÓ khối dữ liệu [DongBoThongTinThanhToan]!`, 'warn');
      }
    });

    return deduplicated.map(r => formatEnvelopeXml(r.xml.trim())).join('\n\n');
  }

  // 5. Main Auto Flow Execution (Supports batch processing of multiple codes)
  async function executeAutoFlow() {
    if (state.isRunning) return;
    state.isRunning = true;
    state.isStopping = false;
    updateUiRunningState(true);

    try {
      const rawText = state.config.maHoSoListText || '';
      let targetCodes = parseMaHoSoList(rawText);
      const fromDate = state.config.fromDate;
      const toDate = state.config.toDate;

      log('🚀 Bắt đầu quy trình tự động hóa DVCQG...', 'info');

      // Kiểm tra danh sách mã hồ sơ: Nếu có trong textarea hoặc ô input trên trang
      if (!targetCodes.length) {
        const pageInput = findMaHoSoInput();
        const pageVal = (pageInput?.value || '').trim();
        if (pageVal) {
          targetCodes = [pageVal];
          log(`Lấy mã đang có trên form: "${pageVal}"`, 'info');
        }
      }

      // NẾU KHÔNG CÓ MÃ HỒ SƠ: TỰ ĐỘNG CHUYỂN SANG CHẾ ĐỘ QUÉT TOÀN BỘ THEO KHOẢNG THỜI GIAN LỰA CHỌN (HÔM NAY, THÁNG NÀY, 30 NGÀY...)
      if (!targetCodes.length) {
        await executeScanAllByDateRange();
        return;
      }

      const total = targetCodes.length;
      log(`📋 Tổng cộng cần kiểm tra ${total} hồ sơ (Bắt buộc có KhoiTaoHoSoBN đầu tiên).`, 'info');

      // Tự động kiểm tra và chọn 50 bản ghi/trang nếu có
      await ensurePageSize50();

      const allExtractedRecords = [];

      // Batch execution loop
      for (let i = 0; i < total; i++) {
        if (state.isStopping) {
          log('⏹ Người dùng đã nhấn Dừng tiến trình!', 'warn');
          break;
        }

        const currentMa = targetCodes[i];
        updateBatchProgress(i, total, currentMa, 'Bắt đầu', total > 1 ? Math.round((i / total) * 100) : 0);
        log(`\n========================================`, 'info');
        log(`▶ [${i + 1}/${total}] Đang xử lý hồ sơ: ${currentMa}`, 'info');
        updateStepTracker([]); // Reset tracker for current application code
        state.capturedNetworkXml = []; // Xóa cache mạng để tránh nhận nhầm gói tin XML giữa các hồ sơ khác nhau

        // 1. Điền Mã hồ sơ
        const inputMaHoSo = findMaHoSoInput();
        if (inputMaHoSo) {
          setNativeValue(inputMaHoSo, currentMa);
          log(`✓ Đã điền Mã hồ sơ: "${currentMa}"`, 'success');
        } else {
          log('⚠️ Không tìm thấy ô nhập Mã hồ sơ trên trang web!', 'warn');
        }

        await sleep(300);

        // 2. Xác định các khoảng ngày tìm kiếm (Smart Dates chia theo từng tháng)
        let dateWindows = [];
        const filingDate = parseDateFromMaHoSo(currentMa);

        const depth = state.config.searchDepthMonths || 3;
        if (filingDate && (state.config.smartDateSearch || !fromDate)) {
          dateWindows = generateSmartDateRanges(filingDate, depth);
          log(`🧠 Nhận diện ngày sinh từ mã [${currentMa}]: ${formatDateDMY(filingDate)} -> Đợt 1 [KhoiTaoHoSoBN: ${formatDateDMY(filingDate)} ➜ ${formatDateDMY(filingDate)}]; rà soát các tháng sau (độ sâu ${depth} tháng sau đó, ${dateWindows.length} đợt)`, 'info');
        } else if (filingDate) {
          // Khi có ngày sinh mã: ưu tiên chia theo từng tháng để không vi phạm giới hạn 1 tháng của DVCQG
          dateWindows = generateSmartDateRanges(filingDate, depth);
          log(`🧠 Chia đợt tra cứu thông minh cho mã [${currentMa}]: ${dateWindows.length} đợt (độ sâu ${depth} tháng sau đó)`, 'info');
        } else {
          // Fallback khoảng ngày thủ công do người dùng chọn
          dateWindows = [{
            from: fromDate || '',
            to: toDate || '',
            label: 'Khoảng ngày chỉ định'
          }];
        }

        const currentMaRecords = [];

        // Tra cứu chu kỳ theo từng tháng (lấy đầy đủ từ Khởi tạo đến Trả kết quả)
        for (let w = 0; w < dateWindows.length; w++) {
          if (state.isStopping) break;

          const win = dateWindows[w];
          log(`📅 Tra cứu đợt ${w + 1}/${dateWindows.length} [${win.label}]: Từ ${formatDateDMY(win.from) || 'mặc định'} đến ${formatDateDMY(win.to) || 'mặc định'}`, 'info');

          // Cập nhật ô Từ ngày & Đến ngày trên floating panel để người dùng theo dõi trực quan
          const panelFrom = document.getElementById('dvcqg-input-from');
          const panelTo = document.getElementById('dvcqg-input-to');
          if (panelFrom && win.from) panelFrom.value = win.from;
          if (panelTo && win.to) panelTo.value = win.to;

          // Điền ngày vào form trang web: Áp dụng cơ chế bước đệm thông minh applyDateRangeToWebPage
          // để tuyệt đối không bị kẹt ngày cuối tháng cũ hay xung đột ràng buộc Từ ngày > Đến ngày
          await applyDateRangeToWebPage(win.from, win.to);

          await sleep(350);

          // Click Tìm kiếm với cơ chế tương thích tốc độ tải thông minh
          const searchBtn = findSearchButton();
          if (searchBtn) {
            const prevTableSnap = getTableSnapshot();
            searchBtn.click();
            log('✓ Đã nhấn Tìm kiếm. Đang theo dõi và chờ dữ liệu tải hoàn tất...', 'info');
            // Chờ máy chủ DVCQG nạp xong dữ liệu 100%, tự động co giãn độ trễ nếu mạng chậm
            await waitForTableDataReady(prevTableSnap, currentMa);
          }

          if (state.isStopping) break;

          // Trích xuất XML từ bảng kết quả kèm live callback cập nhật tiến trình tức thì
          const records = await extractXmlFromTable(currentMa, currentMaRecords, (evt) => {
            const liveCombined = evt.liveCombined || currentMaRecords;
            const liveSteps = evt.stepsCount || updateStepTracker(liveCombined);
            const liveStepPct = Math.round((liveSteps / STEP_DEFINITIONS.length) * 100);

            let pct;
            if (total > 1) {
              const baseProfilePct = (i / total) * 100;
              const withinProfileFraction = (liveSteps / STEP_DEFINITIONS.length) * (1 / total) * 100;
              pct = Math.min(99, Math.round(baseProfilePct + withinProfileFraction));
            } else {
              const dateWinFrac = ((w + (liveSteps / STEP_DEFINITIONS.length)) / dateWindows.length) * 100;
              pct = Math.min(99, Math.round(Math.max(liveStepPct, dateWinFrac)));
            }

            let statusDetail = '';
            if (evt.type === 'RECORD_EXTRACTED') {
              statusDetail = ` • Đã lấy [${evt.status}]`;
            } else if (evt.row) {
              statusDetail = ` • Dòng ${evt.row}/${evt.totalRows}`;
            }

            const stepInfo = `Đợt ${w + 1}/${dateWindows.length}${statusDetail} • ${liveSteps}/${STEP_DEFINITIONS.length} steps (${liveStepPct}%)`;
            updateBatchProgress(i, total, currentMa, stepInfo, pct);

            // Đồng bộ live vào mảng toàn cục để có thể dùng ngay
            const soFar = [...allExtractedRecords, ...liveCombined];
            state.extractedXmlBlocks = soFar;
            state.lastExtractedCombined = combineXmlBlocks(soFar);
          });

          if (records.length > 0) {
            records.forEach(r => r.maHoSo = currentMa);
            for (const r of records) {
              const rNorm = normalizeXml(r.xml);
              const isPayment = r.status.includes('DongBoThongTinThanhToan') || r.status.includes('ThanhToan');
              const isDuplicate = currentMaRecords.some(x => {
                if (state.config.deduplicateStatus && !isPayment && x.status === r.status) return true;
                return normalizeXml(x.xml) === rNorm;
              });

              if (!isDuplicate) {
                currentMaRecords.push(r);
              } else {
                log(`⏭ Bỏ qua khối trùng lặp [${r.status}] cho mã ${currentMa}`, 'info');
              }
            }
            log(`✓ [${currentMa}] [${win.label}]: Thu thập được ${records.length} khối XML Envelope!`, 'success');
          } else {
            log(`[${currentMa}] [${win.label}]: Không có bản ghi mới nào trong đợt này`, 'info');
          }

          // Cập nhật số step đã thực hiện
          const completedStepsCount = updateStepTracker(currentMaRecords);
          const completedNames = STEP_DEFINITIONS.filter(s => currentMaRecords.some(r => r.status === s.key || (s.aliases && s.aliases.includes(r.status)))).map(s => s.label);
          const postPct = total > 1
            ? Math.round(((i + (completedStepsCount / STEP_DEFINITIONS.length)) / total) * 100)
            : Math.round((completedStepsCount / STEP_DEFINITIONS.length) * 100);
          updateBatchProgress(i, total, currentMa, `Đợt ${w + 1}/${dateWindows.length} • ${completedStepsCount}/${STEP_DEFINITIONS.length} steps`, postPct);
          log(`📊 [${currentMa}]: Đã thực hiện ${completedStepsCount}/${STEP_DEFINITIONS.length} steps [${completedNames.join(', ')}]`, 'info');

          // Kiểm tra xem đã có từ KhoiTaoHoSoBN (BẮT BUỘC ĐẦU TIÊN) đến TraKetQuaBN chưa
          const hasKhoiTao = currentMaRecords.some(r => r.status === 'KhoiTaoHoSoBN' || r.status === 'KhoiTaoHoSoDVC');
          const hasTiepNhan = currentMaRecords.some(r => r.status === 'TiepNhanHoSoBN' || r.status === 'TiepNhanHoSoDVC');
          const hasTraKetQua = currentMaRecords.some(r => r.status === 'TraKetQuaBN' || r.status === 'TraKetQuaDVC');
          const isAllStepsCompleted = completedStepsCount === STEP_DEFINITIONS.length;

          // NÂNG CẤP THÔNG MINH: Kiểm tra hồ sơ có phát sinh Yêu cầu nghĩa vụ tài chính hay không
          const hasYeuCauTC = currentMaRecords.some(r => r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhDVC');
          const hasHuyYeuCauTC = currentMaRecords.some(r => r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhDVC');
          const requiresPayment = hasYeuCauTC && !hasHuyYeuCauTC;
          const hasThanhToan = currentMaRecords.some(r => r.status.includes('DongBoThongTinThanhToan') || r.status.includes('ThanhToan'));

          // BẮT BUỘC: Tất cả các hồ sơ kiểm tra phải có giá trị "KhoiTaoHoSoBN" đầu tiên!
          // Chu trình chỉ hoàn chỉnh khi:
          // 1. BẮT BUỘC có KhoiTaoHoSoBN
          // 2. Có TraKetQuaBN
          // 3. NẾU CÓ YÊU CẦU TÀI CHÍNH (chưa bị hủy): BẮT BUỘC PHẢI CÓ DỮ LIỆU THANH TOÁN (DongBoThongTinThanhToan)!
          const isCompleteCycle = hasKhoiTao && hasTraKetQua && (!requiresPayment || hasThanhToan);

          if (isAllStepsCompleted || isCompleteCycle) {
            const payNote = requiresPayment ? ' (kèm đầy đủ DongBoThongTinThanhToan ✓)' : '';
            log(`🎯 ĐÃ TÌM THẤY BƯỚC BẮT BUỘC ĐẦU TIÊN [KhoiTaoHoSoBN] VÀ TRẠNG THÁI CUỐI CÙNG [TraKetQuaBN]${payNote} (${completedStepsCount}/${STEP_DEFINITIONS.length} steps) cho mã ${currentMa}! Hoàn tất chu kỳ xử lý hồ sơ.`, 'success');
            break; // Hoàn tất chu kỳ xử lý hồ sơ này
          } else if (hasTraKetQua && hasKhoiTao && requiresPayment && !hasThanhToan && w < dateWindows.length - 1) {
            const nextWin = dateWindows[w + 1];
            log(`⚠️ [${currentMa}]: Đã có [KhoiTaoHoSoBN] và [TraKetQuaBN] nhưng hồ sơ có YÊU CẦU TÀI CHÍNH và CHƯA LẤY ĐƯỢC [DongBoThongTinThanhToan]! Tiếp tục rà quét thời gian tiếp theo: [${nextWin.label}] để lấy bằng được dữ liệu thanh toán...`, 'warn');
            await sleep(1500);
          } else if (hasTraKetQua && !hasKhoiTao) {
            log(`⚠️ [${currentMa}]: Đã có [TraKetQuaBN] nhưng BẮT BUỘC PHẢI CÓ giá trị [KhoiTaoHoSoBN] đầu tiên (mới đạt ${completedStepsCount}/${STEP_DEFINITIONS.length} steps). Tiếp tục tìm kiếm để lấy bằng được KhoiTaoHoSoBN...`, 'warn');
          } else if (w < dateWindows.length - 1) {
            const nextWin = dateWindows[w + 1];
            if (hasKhoiTao) {
              log(`✓ [${currentMa}]: Đã có giá trị đầu tiên [KhoiTaoHoSoBN]. Chưa thấy trạng thái cuối cùng [TraKetQuaBN] (đạt ${completedStepsCount}/${STEP_DEFINITIONS.length} steps). Tiếp tục rà quét thời gian tiếp theo: [${nextWin.label}] đến khi tìm thấy TraKetQuaBN...`, 'info');
            } else {
              log(`⚠️ [${currentMa}]: Chưa tìm thấy giá trị bắt buộc đầu tiên [KhoiTaoHoSoBN] trong ${win.label} (mới đạt ${completedStepsCount}/${STEP_DEFINITIONS.length} steps). Tiếp tục rà quét thời gian tiếp theo: [${nextWin.label}]...`, 'warn');
            }
            await sleep(1500);
          } else {
            if (!hasKhoiTao) {
              log(`❌ [${currentMa}]: CẢNH BÁO - Đã rà soát tối đa ${dateWindows.length} đợt nhưng KHÔNG TÌM THẤY giá trị [KhoiTaoHoSoBN] bắt buộc đầu tiên! (Thu được ${completedStepsCount}/${STEP_DEFINITIONS.length} steps).`, 'error');
            } else if (requiresPayment && !hasThanhToan) {
              log(`⚠️ [${currentMa}]: CẢNH BÁO - Đã rà soát tối đa ${dateWindows.length} đợt: Hồ sơ có Yêu cầu tài chính nhưng KHÔNG TÌM THẤY dữ liệu [DongBoThongTinThanhToan] (người dân có thể chưa nộp phí hoặc DVCQG chưa đồng bộ biên lai).`, 'warn');
            } else {
              log(`ℹ️ [${currentMa}]: Đã hoàn tất rà soát tối đa ${dateWindows.length} đợt (độ sâu tối đa ${depth} tháng sau tháng nộp). Thu được ${completedStepsCount}/${STEP_DEFINITIONS.length} steps.`, 'info');
            }
          }
        }

        allExtractedRecords.push(...currentMaRecords);

        // Cập nhật số khối XML tổng
        const countEl = document.getElementById('dvcqg-extracted-count');
        if (countEl) countEl.textContent = `${allExtractedRecords.length} khối`;

        // Wait before next record to avoid rate-limiting
        if (i < total - 1 && !state.isStopping) {
          log('Đang chờ 1.5s trước khi xử lý hồ sơ tiếp theo...', 'info');
          await sleep(1500);
        }
      }

      updateBatchProgress(total, total, 'Hoàn tất');

      state.extractedXmlBlocks = allExtractedRecords;

      if (!allExtractedRecords.length) {
        log('❌ Không trích xuất được khối XML nào từ các hồ sơ đã kiểm tra!', 'error');
        alert('Không tìm thấy khối XML nào từ các hồ sơ đã kiểm tra. Vui lòng kiểm tra lại bảng kết quả hoặc khoảng ngày!');
        return;
      }

      log(`\n🎉 HOÀN TẤT KIỂM TRA ${targetCodes.length} HỒ SƠ! Tổng cộng ${allExtractedRecords.length} khối XML.`, 'success');

      // 5. Ghép các khối XML
      const combined = combineXmlBlocks(allExtractedRecords);
      state.lastExtractedCombined = combined;

      // 6. Tự động chuyển sang rà soát nếu được bật
      if (state.config.autoTransfer) {
        const targetUrl = state.config.rasoatUrl || RASOAT_URL_PRIMARY;
        const targetLabel = targetUrl === RASOAT_URL_GIALAI ? 'Dự phòng Gia Lai' : (targetUrl === RASOAT_URL_PRIMARY ? 'Máy chủ chính' : targetUrl);
        log(`🚀 Đang chuyển dữ liệu XML sang trang Rà soát [${targetLabel}]...`, 'info');
        const representativeMa = targetCodes.length === 1 ? targetCodes[0] : `${targetCodes.length} hồ sơ (${targetCodes[0]}...)`;
        transferDataToRasoat(combined, representativeMa, fromDate, toDate);
      } else {
        log('Đã trích xuất xong! Bấm "Chuyển sang Rà soát" hoặc "Xem XML" để tiếp tục.', 'success');
      }

    } catch (err) {
      log(`Lỗi trong quá trình tự động: ${err.message}`, 'error');
      console.error(err);
    } finally {
      state.isRunning = false;
      state.isStopping = false;
      updateUiRunningState(false);
    }
  }

  // 5b. Chế độ quét toàn bộ dữ liệu các hồ sơ theo khoảng thời gian lựa chọn khi không có mã hồ sơ
  async function executeScanAllByDateRange() {
    log('🌐 KÍCH HOẠT CHẾ ĐỘ QUÉT TOÀN BỘ HỒ SƠ THEO KHOẢNG THỜI GIAN LỰA CHỌN...', 'info');

    // 1. Xác định khoảng ngày tìm kiếm (Hôm nay, Tháng này, 30 ngày hoặc tự chọn)
    let scanFrom = state.config.fromDate;
    let scanTo = state.config.toDate;
    const now = new Date();
    const todayStr = formatDateYMD(now);

    if (!scanFrom && !scanTo) {
      scanFrom = todayStr;
      scanTo = todayStr;
      state.config.fromDate = scanFrom;
      state.config.toDate = scanTo;
    } else if (!scanFrom) {
      scanFrom = scanTo;
      state.config.fromDate = scanFrom;
    } else if (!scanTo) {
      scanTo = scanFrom;
      state.config.toDate = scanTo;
    }

    // Đồng bộ lên giao diện panel để người dùng thấy rõ
    const panelFrom = document.getElementById('dvcqg-input-from');
    const panelTo = document.getElementById('dvcqg-input-to');
    if (panelFrom) panelFrom.value = scanFrom;
    if (panelTo) panelTo.value = scanTo;

    log(`📅 Khoảng thời gian tra cứu toàn bộ: Từ ${formatDateDMY(scanFrom)} đến ${formatDateDMY(scanTo)}`, 'info');

    // 2. Xóa trắng ô nhập Mã hồ sơ trên trang web nếu có để tìm kiếm toàn bộ hồ sơ
    const pageInput = findMaHoSoInput();
    if (pageInput) {
      setNativeValue(pageInput, '');
      log('✓ Đã xóa trắng ô Mã hồ sơ trên trang web để tìm kiếm toàn bộ hồ sơ', 'info');
    }

    // 3. Đảm bảo 50 bản ghi/trang
    await ensurePageSize50();

    updateBatchProgress(0, 1, 'Quét toàn bộ theo ngày', `Từ ${formatDateDMY(scanFrom)} đến ${formatDateDMY(scanTo)}`);
    updateStepTracker([]);
    state.capturedNetworkXml = [];

    // 4. Điền ngày vào form trang web với cơ chế bước đệm thông minh
    await applyDateRangeToWebPage(scanFrom, scanTo);
    await sleep(350);

    // 5. Click Tìm kiếm với cơ chế tương thích tốc độ tải
    const searchBtn = findSearchButton();
    if (searchBtn) {
      const prevTableSnap = getTableSnapshot();
      searchBtn.click();
      log('✓ Đã nhấn Tìm kiếm. Đang theo dõi và chờ nạp dữ liệu hoàn tất...', 'info');
      await waitForTableDataReady(prevTableSnap, '');
    }

    if (state.isStopping) {
      log('⏹ Người dùng đã nhấn Dừng tiến trình!', 'warn');
      return;
    }

    // 6. Quét toàn bộ bảng kết quả qua các trang kèm live callback cập nhật tiến trình tức thì
    const allExtractedRecords = await extractXmlFromTable('', [], (evt) => {
      const liveCombined = evt.liveCombined || [];
      const uniqueMa = new Set(liveCombined.map(r => r.maHoSo).filter(Boolean));
      const pageInfo = `Trang ${evt.page}/${evt.maxPages}`;
      const rowInfo = evt.totalRows ? ` • Dòng ${evt.row}/${evt.totalRows}` : '';
      const stepInfo = `${pageInfo}${rowInfo} • Đã lấy ${liveCombined.length} khối (${uniqueMa.size} HS)`;

      const pageProgress = ((evt.page - 1) / evt.maxPages) * 100;
      const processedRows = evt.processedRows !== undefined ? evt.processedRows : ((evt.totalRows || 1) - (evt.row || 1) + 1);
      const rowProgress = (processedRows / (evt.totalRows || 1)) * (1 / evt.maxPages) * 100;
      const pct = Math.min(99, Math.round(pageProgress + rowProgress));

      updateBatchProgress(0, 1, 'Quét toàn bộ', stepInfo, pct);
    });

    if (!allExtractedRecords.length) {
      log('❌ Không trích xuất được khối XML nào trong khoảng thời gian đã chọn!', 'error');
      alert(`Không tìm thấy hồ sơ hoặc khối XML nào trong khoảng thời gian từ ${formatDateDMY(scanFrom)} đến ${formatDateDMY(scanTo)}!`);
      return;
    }

    const uniqueMaList = Array.from(new Set(allExtractedRecords.map(r => r.maHoSo).filter(Boolean)));
    log(`\n🎉 HOÀN TẤT QUÉT TOÀN BỘ! Thu được ${allExtractedRecords.length} khối XML Envelope từ ${uniqueMaList.length} hồ sơ khác nhau.`, 'success');

    state.extractedXmlBlocks = allExtractedRecords;
    const completedStepsCount = updateStepTracker(allExtractedRecords);
    const countEl = document.getElementById('dvcqg-extracted-count');
    if (countEl) countEl.textContent = `${allExtractedRecords.length} khối (${uniqueMaList.length} HS)`;

    updateBatchProgress(1, 1, 'Hoàn tất', `${allExtractedRecords.length} khối (${uniqueMaList.length} HS)`, 100);

    // 7. Ghép các khối XML
    const combined = combineXmlBlocks(allExtractedRecords);
    state.lastExtractedCombined = combined;

    // 8. Chuyển sang Rà soát nếu được bật
    if (state.config.autoTransfer) {
      const targetUrl = state.config.rasoatUrl || RASOAT_URL_PRIMARY;
      const targetLabel = targetUrl === RASOAT_URL_GIALAI ? 'Dự phòng Gia Lai' : (targetUrl === RASOAT_URL_PRIMARY ? 'Máy chủ chính' : targetUrl);
      log(`🚀 Đang chuyển dữ liệu XML sang trang Rà soát [${targetLabel}]...`, 'info');
      const representativeMa = `Quét toàn bộ ${uniqueMaList.length} hồ sơ (${formatDateDMY(scanFrom)} - ${formatDateDMY(scanTo)})`;
      transferDataToRasoat(combined, representativeMa, scanFrom, scanTo);
    } else {
      log('Đã trích xuất xong toàn bộ! Bấm "Chuyển sang Rà soát" hoặc "Xem XML" để tiếp tục.', 'success');
    }
  }

  // Update batch progress UI with live support
  function updateBatchProgress(current, total, currentMa, stepsInfo = '', customPct = null) {
    const container = document.getElementById('dvcqg-batch-progress');
    const textEl = document.getElementById('dvcqg-progress-text');
    const pctEl = document.getElementById('dvcqg-progress-pct');
    const fillEl = document.getElementById('dvcqg-progress-fill');
    if (!container) return;

    container.style.display = 'flex';

    let pct = 0;
    if (customPct !== null && typeof customPct === 'number') {
      pct = Math.max(0, Math.min(100, Math.round(customPct)));
    } else if (total > 0) {
      pct = Math.min(100, Math.round((current / total) * 100));
    }

    const stepSuffix = stepsInfo ? ` • ${stepsInfo}` : '';
    let label = '';
    if (total > 1) {
      label = `Hồ sơ ${Math.min(current + 1, total)}/${total}: ${currentMa || ''}${stepSuffix}`;
    } else if (currentMa) {
      label = `${currentMa}${stepSuffix}`;
    } else {
      label = `Tiến trình${stepSuffix}`;
    }

    if (textEl) textEl.textContent = label;
    if (pctEl) pctEl.textContent = `${pct}%`;
    if (fillEl) fillEl.style.width = `${pct}%`;
  }

  // Quick extract from already displayed table
  async function executeCurrentTableExtract() {
    if (state.isRunning) return;
    state.isRunning = true;
    updateUiRunningState(true);

    try {
      log('⚡ Bắt đầu trích xuất trực tiếp từ bảng hiện tại...', 'info');
      await ensurePageSize50();
      const pageInp = findMaHoSoInput();
      const pageMa = (pageInp?.value || '').trim();
      updateBatchProgress(0, 1, pageMa || 'Bảng hiện tại', 'Đang trích xuất...', 10);

      const records = await extractXmlFromTable(pageMa, [], (evt) => {
        const liveCombined = evt.liveCombined || [];
        const liveSteps = evt.stepsCount || updateStepTracker(liveCombined);
        const processedRows = evt.processedRows !== undefined ? evt.processedRows : ((evt.totalRows || 1) - (evt.row || 1) + 1);
        const pct = Math.min(99, Math.round((processedRows / (evt.totalRows || 1)) * 100));
        updateBatchProgress(0, 1, pageMa || 'Bảng hiện tại', `Dòng ${evt.row}/${evt.totalRows} • ${liveSteps}/${STEP_DEFINITIONS.length} steps`, pct);
      });
      state.extractedXmlBlocks = records;

      if (!records.length) {
        log('❌ Không tìm thấy khối XML nào từ bảng hiện tại.', 'error');
        alert('Không tìm thấy khối XML nào từ bảng hiện tại.');
        return;
      }

      const stepsCount = updateStepTracker(records);
      const combined = combineXmlBlocks(records);
      state.lastExtractedCombined = combined;

      const countEl = document.getElementById('dvcqg-extracted-count');
      if (countEl) countEl.textContent = `${records.length} khối (${stepsCount}/${STEP_DEFINITIONS.length} steps)`;

      updateBatchProgress(1, 1, pageMa || 'Bảng hiện tại', `Hoàn tất (${records.length} khối XML)`, 100);
      log(`✓ Đã trích xuất xong ${records.length} khối XML Envelope (${stepsCount}/${STEP_DEFINITIONS.length} steps đã thực hiện).`, 'success');

      if (state.config.autoTransfer) {
        transferDataToRasoat(combined, 'Bảng hiện tại', state.config.fromDate, state.config.toDate);
      }
    } finally {
      state.isRunning = false;
      updateUiRunningState(false);
    }
  }

  // Gửi tin nhắn sang background với cơ chế tự động thử lại (giúp Service Worker kịp thức dậy trong MV3)
  async function sendMessageWithRetry(msg, maxRetries = 3, delayMs = 300) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      if (!chrome.runtime?.id) {
        throw new Error('Extension context invalidated (Extension đã được cập nhật hoặc nạp lại)');
      }

      const result = await new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage(msg, (response) => {
            const err = chrome.runtime.lastError;
            if (err) {
              resolve({ ok: false, error: err.message });
            } else {
              resolve({ ok: true, data: response });
            }
          });
        } catch (e) {
          resolve({ ok: false, error: e?.message || String(e) });
        }
      });

      if (result.ok) {
        return result.data;
      }

      const errMsg = result.error || '';
      const isConnectionIssue = errMsg.includes('Receiving end does not exist') ||
                                errMsg.includes('Could not establish connection');

      if (isConnectionIssue && attempt < maxRetries) {
        console.warn(`[DVCQG Auto] Service Worker đang khởi động, thử lại (${attempt}/${maxRetries}) sau ${delayMs}ms...`);
        await new Promise((r) => setTimeout(r, delayMs));
        continue;
      }

      throw new Error(errMsg);
    }
  }

  // Send data to background to open/fill rasoat.html
  async function transferDataToRasoat(xml, maHoSo, fromDate, toDate) {
    if (!xml) {
      alert('Chưa có dữ liệu XML nào được trích xuất!');
      return;
    }

    // Auto-copy XML to clipboard as an extra guarantee
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(xml).catch(() => {});
    }

    // NÂNG CẤP THÔNG MINH: Kiểm tra đối chiếu trước khi chuyển sang Rà soát
    const records = state.extractedXmlBlocks || [];
    if (records.length) {
      const uniqueMaList = Array.from(new Set(records.map(r => r.maHoSo).filter(Boolean)));
      if (!uniqueMaList.length && maHoSo && maHoSo !== 'Nhiều hồ sơ' && maHoSo !== 'Bảng hiện tại') {
        uniqueMaList.push(maHoSo);
      }
      uniqueMaList.forEach(ma => {
        const maRecs = records.filter(r => r.maHoSo === ma || !r.maHoSo);
        const hasYc = maRecs.some(r => r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'TaoYeuCauThucHienNghiaVuTaiChinhDVC' || (r.xml && r.xml.includes('TaoYeuCauThucHienNghiaVuTaiChinh')));
        const hasHuy = maRecs.some(r => r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhBN' || r.status === 'HuyYeuCauThucHienNghiaVuTaiChinhDVC' || (r.xml && r.xml.includes('HuyYeuCauThucHienNghiaVuTaiChinh')));
        const hasTt = maRecs.some(r => r.status.includes('DongBoThongTinThanhToan') || r.status.includes('ThanhToan') || (r.xml && (r.xml.includes('DongBoThongTinThanhToan') || r.xml.includes('ThanhToan'))));
        if (hasYc && !hasHuy && !hasTt) {
          log(`⚠️ [Lưu ý rà soát]: Hồ sơ [${ma}] có trạng thái YÊU CẦU TÀI CHÍNH nhưng CHƯA CÓ dữ liệu [DongBoThongTinThanhToan]!`, 'warn');
        } else if (hasYc && !hasHuy && hasTt) {
          log(`✓ [Kiểm tra đối chiếu]: Hồ sơ [${ma}] có Yêu cầu tài chính và ĐÃ LẤY ĐẦY ĐỦ khối [DongBoThongTinThanhToan] ✓`, 'success');
        }
      });
    }

    const targetUrl = state.config.rasoatUrl || RASOAT_URL_PRIMARY;
    const targetLabel = targetUrl === RASOAT_URL_GIALAI
      ? 'Dự phòng Gia Lai (hcc.gialai.gov.vn)'
      : (targetUrl === RASOAT_URL_PRIMARY ? 'Máy chủ chính (cdn.dnncloud.net)' : targetUrl);

    // Lưu trước vào chrome.storage trực tiếp từ content script để bảo đảm dữ liệu luôn sẵn sàng
    const payload = {
      xml,
      maHoSo: maHoSo || '',
      fromDate: fromDate || '',
      toDate: toDate || '',
      targetUrl,
      timestamp: Date.now()
    };

    if (chrome.storage?.local) {
      try {
        await chrome.storage.local.set({
          pending_rasoat_data: payload,
          last_extracted_xml: payload
        });
      } catch (storageErr) {
        console.warn('[DVCQG Auto] Lưu storage từ content script:', storageErr);
      }
    }

    log(`Đang gửi tín hiệu mở trang Rà soát [${targetLabel}]...`, 'info');

    try {
      const response = await sendMessageWithRetry({
        action: 'TRANSFER_TO_RASOAT',
        data: payload
      }, 3, 300);

      if (response && response.success) {
        log(`✓ Đã điều hướng sang trang Rà soát [${targetLabel}] và tự động dán dữ liệu vào form thành công!`, 'success');
      } else {
        log(`Lỗi từ Background: ${response?.error || 'Không rõ nguyên nhân'}`, 'error');
      }
    } catch (err) {
      console.warn('[DVCQG Auto] Lỗi gửi message sang background:', err);
      const isContextOrConnErr = err.message.includes('Receiving end does not exist') ||
                                 err.message.includes('Extension context invalidated') ||
                                 err.message.includes('Could not establish connection');

      // Tự động mở tab Rà soát trực tiếp bằng window.open làm cơ chế dự phòng khẩn cấp
      try {
        window.open(targetUrl, '_blank');
      } catch (openErr) {
        console.warn('[DVCQG Auto] window.open fallback thất bại:', openErr);
      }

      if (isContextOrConnErr) {
        log(`⚠️ Mất kết nối nền Extension: Đã tự động mở tab Rà soát và sao chép XML vào Clipboard!`, 'warn');
        log(`💡 Khắc phục: Vui lòng nhấn phím F5 (tải lại trang DVCQG) để nạp lại kết nối Extension nếu bạn vừa reload extension.`, 'info');
      } else {
        log(`Lỗi liên lạc Extension: ${err.message}`, 'error');
      }
    }
  }

  function updateUiRunningState(running) {
    const runBtn = document.getElementById('dvcqg-btn-run');
    const directBtn = document.getElementById('dvcqg-btn-direct');
    const stopBtn = document.getElementById('dvcqg-btn-stop');
    const progressBox = document.getElementById('dvcqg-batch-progress');

    if (runBtn) {
      runBtn.disabled = running;
      runBtn.innerHTML = running ? '⏳ Đang tự động xử lý...' : '▶ Bắt đầu Tự Động';
    }
    if (directBtn) {
      directBtn.disabled = running;
    }
    if (stopBtn) {
      stopBtn.style.display = running ? 'flex' : 'none';
      stopBtn.disabled = false;
      stopBtn.innerHTML = '<span>⏹ Dừng tiến trình</span>';
    }
    if (running && progressBox) {
      progressBox.style.display = 'flex';
    } else if (!running && progressBox) {
      // Giữ hiển thị trạng thái hoàn tất 100% trong 4s để người dùng kịp quan sát
      setTimeout(() => {
        if (!state.isRunning && progressBox) {
          progressBox.style.display = 'none';
        }
      }, 4000);
    }
  }

  // 6. Build & Mount Floating Control Panel
  function buildUi() {
    if (rootEl) return;

    // Load saved settings from chrome.storage
    chrome.storage.local.get(['dvcqg_config'], (res) => {
      if (res.dvcqg_config) {
        // Compatibility: support old maHoSo field if maHoSoListText is not set
        if (!res.dvcqg_config.maHoSoListText && res.dvcqg_config.maHoSo) {
          res.dvcqg_config.maHoSoListText = res.dvcqg_config.maHoSo;
        }
        if (res.dvcqg_config.selectedStatuses) {
          state.config.selectedStatuses = Object.assign(
            {},
            state.config.selectedStatuses,
            res.dvcqg_config.selectedStatuses
          );
          delete res.dvcqg_config.selectedStatuses;
        }
        Object.assign(state.config, res.dvcqg_config);
      }
      initDatesIfEmpty();
      renderUi();
      // Ensure date inputs reflect filing date if codes are present
      autoSelectInitialDateFromMaHoSo(false);
    });
  }

  // Tự nhận dạng mục Đến ngày với ngày hiện tại theo độ sâu tháng đã thiết lập
  function syncToDateWithDepthAndToday(force = false) {
    const inputTo = document.getElementById('dvcqg-input-to');
    const badgeTo = document.getElementById('dvcqg-badge-today');
    const now = new Date();
    const todayYmd = formatDateYMD(now);
    const todayDmy = formatDateDMY(now);

    let filingDate = null;
    const listText = state.config.maHoSoListText || '';
    const codes = parseMaHoSoList(listText);
    for (const ma of codes) {
      const d = parseDateFromMaHoSo(ma);
      if (d && (!filingDate || d < filingDate)) {
        filingDate = d;
      }
    }

    if (!filingDate && state.config.fromDate) {
      const parsedFrom = new Date(state.config.fromDate);
      if (!isNaN(parsedFrom.getTime())) filingDate = parsedFrom;
    }

    const depth = state.config.searchDepthMonths || 3;

    if (filingDate && !isNaN(filingDate.getTime())) {
      const windows = generateSmartDateRanges(filingDate, depth);
      if (windows.length > 0) {
        const lastWin = windows[windows.length - 1];
        const isToToday = (lastWin.to === todayYmd);
        const resolvedTo = lastWin.to;

        if (force || state.config.autoDetectToDateWithToday || !state.config.toDate) {
          state.config.toDate = resolvedTo;
          if (inputTo) inputTo.value = resolvedTo;
          saveConfig();
        }

        if (badgeTo) {
          badgeTo.style.display = 'inline-block';
          if (isToToday) {
            badgeTo.textContent = `🎯 Đến ngày: Hôm nay (${todayDmy})`;
            badgeTo.title = `Tự động nhận dạng Đến ngày với Ngày hiện tại theo độ sâu ${depth} tháng`;
            badgeTo.style.background = '#ccfbf1';
            badgeTo.style.color = '#0f766e';
          } else {
            badgeTo.textContent = `📅 Đến ngày: ${formatDateDMY(resolvedTo)}`;
            badgeTo.title = `Đến ngày tính theo độ sâu ${depth} tháng`;
            badgeTo.style.background = '#e0f2fe';
            badgeTo.style.color = '#0369a1';
          }
        }
        return resolvedTo;
      }
    }

    // Fallback: Tự nhận dạng Đến ngày = Ngày hiện tại
    if (force || state.config.autoDetectToDateWithToday || !state.config.toDate) {
      state.config.toDate = todayYmd;
      if (inputTo) inputTo.value = todayYmd;
      saveConfig();
    }
    if (badgeTo) {
      badgeTo.style.display = 'inline-block';
      badgeTo.textContent = `🎯 Đến ngày: Hôm nay (${todayDmy})`;
    }
    return todayYmd;
  }

  // Hiệu ứng phát sáng highlight cho 2 ô input ngày khi thay đổi tab thời gian
  function highlightDateInputs() {
    const inputFrom = document.getElementById('dvcqg-input-from');
    const inputTo = document.getElementById('dvcqg-input-to');
    [inputFrom, inputTo].forEach(el => {
      if (el) {
        el.classList.remove('dvcqg-input-glow');
        void el.offsetWidth; // Trigger reflow để kích hoạt lại animation
        el.classList.add('dvcqg-input-glow');
        setTimeout(() => el.classList.remove('dvcqg-input-glow'), 700);
      }
    });
  }

  // Đánh dấu tab thời gian đang được chọn với micro-animation nảy nhẹ
  function setActiveDatePresetButton(activeBtn) {
    document.querySelectorAll('.dvcqg-date-presets .dvcqg-preset-btn').forEach(b => {
      b.classList.remove('active', 'dvcqg-tab-pop');
    });
    if (activeBtn) {
      activeBtn.classList.add('active', 'dvcqg-tab-pop');
      setTimeout(() => activeBtn.classList.remove('dvcqg-tab-pop'), 400);
    }
  }

  // Tự động nhận diện và cập nhật trạng thái tab active dựa theo ngày hiện tại của input hoặc mã HS
  function checkAndUpdateActivePresetTab() {
    const inputFrom = document.getElementById('dvcqg-input-from');
    const inputTo = document.getElementById('dvcqg-input-to');
    if (!inputFrom || !inputTo) return;

    const from = (inputFrom.value || '').trim();
    const to = (inputTo.value || '').trim();
    const now = new Date();
    const todayStr = formatDateYMD(now);
    const startMStr = formatDateYMD(new Date(now.getFullYear(), now.getMonth(), 1));
    const endMStr = formatDateYMD(new Date(now.getFullYear(), now.getMonth() + 1, 0));
    const d30 = new Date();
    d30.setDate(d30.getDate() - 30);
    const d30Str = formatDateYMD(d30);

    let matchedPreset = null;
    if (from === todayStr && to === todayStr) {
      matchedPreset = 'today';
    } else if (from === startMStr && (to === endMStr || to === todayStr)) {
      matchedPreset = 'this-month';
    } else if (from === d30Str && to === todayStr) {
      matchedPreset = '30d';
    }

    // Nếu có mã hồ sơ và không khớp các preset cố định thì mặc định active tab "Theo mã HS"
    const textareaMa = document.getElementById('dvcqg-textarea-ma');
    const rawCodes = textareaMa ? textareaMa.value : (state.config.maHoSoListText || '');
    const codes = parseMaHoSoList(rawCodes);
    if (codes.length > 0 && !matchedPreset) {
      matchedPreset = 'by-ma';
    }

    document.querySelectorAll('.dvcqg-date-presets .dvcqg-preset-btn').forEach(b => {
      if (matchedPreset && b.dataset.preset === matchedPreset) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });
  }

  // Tự động nhận diện và TỰ ĐỘNG CHỌN CHẾ ĐỘ THỜI GIAN THEO MÃ HỒ SƠ (Không cần chọn thủ công)
  function autoSelectInitialDateFromMaHoSo(force = false) {
    const textareaMa = document.getElementById('dvcqg-textarea-ma');
    const inputFrom = document.getElementById('dvcqg-input-from');

    let rawList = textareaMa ? textareaMa.value : (state.config.maHoSoListText || '');
    let list = parseMaHoSoList(rawList);

    // Nếu chưa có trong danh sách, thử lấy mã đang nhập trên form web
    if (!list.length) {
      const pageInp = findMaHoSoInput();
      const pVal = (pageInp?.value || '').trim();
      if (pVal) list = [pVal];
    }

    if (!list.length) return false;

    // Tìm ngày nộp sớm nhất trong danh sách mã (hoặc mã đầu tiên)
    let earliestDate = null;
    let matchingMa = '';

    for (const ma of list) {
      const d = parseDateFromMaHoSo(ma);
      if (d) {
        if (!earliestDate || d < earliestDate) {
          earliestDate = d;
          matchingMa = ma;
        }
      }
    }

    if (earliestDate) {
      const ymd = formatDateYMD(earliestDate);
      const dmy = formatDateDMY(earliestDate);

      // Cập nhật Từ ngày = Ngày sinh hồ sơ
      state.config.fromDate = ymd;
      if (inputFrom) inputFrom.value = ymd;

      // NÂNG CẤP THÔNG MINH: Tự nhận dạng mục "Đến ngày" với Ngày hiện tại theo độ sâu tháng đã thiết lập
      const resolvedTo = syncToDateWithDepthAndToday(force || true);

      // Tự động kích hoạt chế độ tra cứu thông minh
      state.config.smartDateSearch = true;
      const checkSmartDate = document.getElementById('dvcqg-check-smart-date');
      if (checkSmartDate) checkSmartDate.checked = true;

      // TỰ ĐỘNG CHỌN CHẾ ĐỘ THỜI GIAN THEO MÃ HỒ SƠ: Nút "📅 Theo mã HS" tự động Active
      const btnByMa = document.querySelector('.dvcqg-preset-btn[data-preset="by-ma"]');
      if (btnByMa) {
        setActiveDatePresetButton(btnByMa);
      }
      highlightDateInputs();

      saveConfig();
      const depth = state.config.searchDepthMonths || 3;
      log(`🧠 Đã tự động chọn chế độ thời gian theo mã [${matchingMa}]: Từ ${dmy} ➜ Đến ngày ${formatDateDMY(resolvedTo)} (Độ sâu ${depth} tháng, tự nhận dạng với ngày hiện tại)`, 'success');
      return true;
    }

    return false;
  }

  function initDatesIfEmpty() {
    // Ưu tiên trích xuất ngày sinh từ danh sách mã hồ sơ và tự nhận dạng Đến ngày theo độ sâu
    const autoSet = autoSelectInitialDateFromMaHoSo(false);
    if (!autoSet) {
      const today = new Date();
      if (!state.config.toDate) {
        state.config.toDate = formatDateYMD(today);
      }
      if (!state.config.fromDate) {
        // Mặc định ngày 01 của tháng hiện tại để cùng nằm trong 1 tháng
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        state.config.fromDate = formatDateYMD(startOfMonth);
      }
    }
  }

  function renderUi() {
    rootEl = document.createElement('div');
    rootEl.id = 'dvcqg-auto-root';

    let extVersion = 'v2.3.2';
    let extVersionName = 'v2.3.2 (20/10/2026)';
    try {
      const manifest = chrome.runtime.getManifest?.();
      if (manifest && manifest.version) {
        extVersion = `v${manifest.version}`;
        extVersionName = manifest.version_name ? `v${manifest.version_name}` : `v${manifest.version} (20/10/2026)`;
      }
    } catch (e) {}

    const initialCodes = parseMaHoSoList(state.config.maHoSoListText);

    rootEl.innerHTML = `
      <!-- Launcher Button (when minimized) -->
      <button id="dvcqg-launcher" class="dvcqg-launcher-btn" style="display: none;" title="Mở bảng điều khiển Tự động DVCQG">
        <span class="pulse-dot"></span>
        <span>Auto Check DVCQG</span>
      </button>

      <!-- Main Control Panel -->
      <div id="dvcqg-panel" class="dvcqg-panel">
        <div class="dvcqg-panel-header">
          <div class="dvcqg-panel-title">
            <span>⚡ Auto Check DVCQG</span>
            <span class="dvcqg-panel-badge" id="dvcqg-panel-version" title="Tác giả: Kyn Chou | Ngày phiên bản: ${extVersionName}">${extVersion}</span>
          </div>
          <div class="dvcqg-header-actions">
            <button id="dvcqg-btn-minimize" class="dvcqg-icon-btn" title="Thu nhỏ">_</button>
            <button id="dvcqg-btn-close" class="dvcqg-icon-btn" title="Đóng">✕</button>
          </div>
        </div>

        <div class="dvcqg-panel-body">
          <!-- Danh sách Mã hồ sơ input (Hỗ trợ nhiều mã hoặc quét toàn bộ) -->
          <div class="dvcqg-form-group">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <label class="dvcqg-label">
                Danh sách mã hồ sơ 
                <span id="dvcqg-ma-count" style="color: ${initialCodes.length > 0 ? '#0b6e6e' : '#0284c7'}; font-weight: 600; text-transform: none;">${initialCodes.length > 0 ? `(${initialCodes.length} mã)` : '(Quét toàn bộ theo ngày)'}</span>
              </label>
              <div style="display: flex; gap: 4px;">
                <button id="dvcqg-btn-paste-ma" type="button" class="dvcqg-preset-btn" style="width: auto; padding: 2px 6px;" title="Tự động dán từ Clipboard">📋 Dán</button>
                <button id="dvcqg-btn-clear-ma" type="button" class="dvcqg-preset-btn btn-danger-soft" style="width: auto; padding: 2px 6px;" title="Xóa danh sách mã đã nhập và xóa luôn dữ liệu tại ô 'Mã hồ sơ' trên trang web">🗑️ Xóa</button>
              </div>
            </div>
            <textarea id="dvcqg-textarea-ma" class="dvcqg-textarea-ma" rows="3" placeholder="Nhập mã HS (mỗi dòng 1 mã) hoặc ĐỂ TRỐNG để quét toàn bộ hồ sơ theo khoảng ngày (Hôm nay, Tháng này, 30 ngày...)&#10;VD: H56.01-240101-0001">${state.config.maHoSoListText || ''}</textarea>
          </div>

          <!-- Từ ngày - Đến ngày -->
          <div class="dvcqg-form-group">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <label class="dvcqg-label">Thời gian tra cứu</label>
              <span id="dvcqg-badge-today" style="font-size: 11px; color: #0d9488; font-weight: 600; background: #ccfbf1; padding: 2px 6px; border-radius: 4px; display: inline-block;" title="Tự động nhận dạng Đến ngày với Ngày hiện tại theo độ sâu tháng">🎯 Tự nhận dạng Đến ngày</span>
            </div>
            <div class="dvcqg-date-grid">
              <div>
                <input id="dvcqg-input-from" type="date" class="dvcqg-input-date" value="${state.config.fromDate || ''}" title="Từ ngày">
              </div>
              <div>
                <input id="dvcqg-input-to" type="date" class="dvcqg-input-date" value="${state.config.toDate || ''}" title="Đến ngày (tự nhận dạng với ngày hiện tại theo độ sâu tháng)">
              </div>
            </div>
            <div class="dvcqg-date-presets">
              <button type="button" class="dvcqg-preset-btn highlight" data-preset="by-ma" title="Tự động nhận diện Từ ngày theo mã và Đến ngày theo độ sâu/ngày hiện tại">📅 Theo mã HS</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="to-today" title="Tự nhận dạng Đến ngày là ngày hiện tại hôm nay">📅 Đến hôm nay</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="this-month" title="Đầu tháng đến ngày hiện tại">Tháng này</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="today">Hôm nay</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="30d">30 ngày</button>
            </div>
            <!-- Smart Date Search Option -->
            <label class="dvcqg-checkbox-item" style="margin-top: 6px; font-size: 11px; color: #0b6e6e; font-weight: 600;">
              <input type="checkbox" id="dvcqg-check-smart-date" ${state.config.smartDateSearch ? 'checked' : ''}>
              <span>🧠 Tra cứu thông minh: Bắt đầu từ KhoiTaoHoSoBN, tự nhận dạng Đến ngày theo độ sâu</span>
            </label>
            <!-- Tùy chỉnh độ sâu rà soát & Tự nhận dạng Đến ngày với ngày hiện tại -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; padding: 4px 8px; background: #f0fdfa; border: 1px solid #ccfbf1; border-radius: 6px; font-size: 11px;">
              <span style="color: #0f766e; font-weight: 600;" title="Độ sâu rà soát tháng sau tự động nhận dạng Đến ngày với ngày hiện tại">🔍 Độ sâu rà soát tháng sau:</span>
              <select id="dvcqg-select-search-depth" style="padding: 2px 6px; border: 1px solid #0d9488; border-radius: 4px; font-size: 11px; font-weight: bold; color: #0f766e; background: #fff; cursor: pointer;">
                <option value="1" ${(state.config.searchDepthMonths ?? 3) === 1 ? 'selected' : ''}>1 tháng sau</option>
                <option value="2" ${(state.config.searchDepthMonths ?? 3) === 2 ? 'selected' : ''}>2 tháng sau</option>
                <option value="3" ${(state.config.searchDepthMonths ?? 3) === 3 ? 'selected' : ''}>3 tháng sau (Mặc định)</option>
                <option value="4" ${(state.config.searchDepthMonths ?? 3) === 4 ? 'selected' : ''}>4 tháng sau</option>
                <option value="5" ${(state.config.searchDepthMonths ?? 3) === 5 ? 'selected' : ''}>5 tháng sau</option>
                <option value="6" ${(state.config.searchDepthMonths ?? 3) === 6 ? 'selected' : ''}>6 tháng sau</option>
                <option value="12" ${(state.config.searchDepthMonths ?? 3) === 12 ? 'selected' : ''}>12 tháng sau</option>
              </select>
            </div>
            <!-- Chế độ thông minh tương thích tốc độ tải -->
            <div style="margin-top: 6px; padding: 6px 8px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <label class="dvcqg-checkbox-item" style="margin: 0; font-size: 11px; color: #0f766e; font-weight: 700;">
                  <input type="checkbox" id="dvcqg-check-adaptive-speed" ${state.config.adaptiveSpeed ? 'checked' : ''}>
                  <span title="Tự động kiểm tra mạng, spinner và bảng dữ liệu nạp xong 100% trước khi bóc tách, chống sót dữ liệu khi mạng chậm">🧠 Tương thích tốc độ tải</span>
                </label>
                <span id="dvcqg-network-indicator" style="font-size: 11px; cursor: help;" title="Trạng thái mạng: Sẵn sàng">🟢</span>
              </div>
              <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 4px; font-size: 11px;">
                <span style="color: #64748b;">Chế độ tốc độ:</span>
                <select id="dvcqg-select-speed-mode" style="padding: 1px 4px; border: 1px solid #cbd5e1; border-radius: 4px; font-size: 11px; color: #334155; background: #fff; cursor: pointer;">
                  <option value="adaptive" ${(state.config.speedMode || 'adaptive') === 'adaptive' ? 'selected' : ''}>⚡ Tự thích ứng (Khuyên dùng)</option>
                  <option value="safe" ${(state.config.speedMode || 'adaptive') === 'safe' ? 'selected' : ''}>🐢 Chờ an toàn (Mạng chậm/Lag)</option>
                  <option value="fast" ${(state.config.speedMode || 'adaptive') === 'fast' ? 'selected' : ''}>🚀 Tốc độ cao</option>
                </select>
              </div>
            </div>
            <!-- Cho phép qua tối đa 3 trang nếu chưa tìm thấy -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; padding: 4px 8px; background: #f0fdfa; border: 1px solid #ccfbf1; border-radius: 6px; font-size: 11px;">
              <span style="color: #0f766e; font-weight: 600;" title="Cho phép qua tối đa bao nhiêu trang nếu chưa tìm thấy đủ trạng thái trước khi chuyển sang đợt tiếp theo">📄 Qua tối đa trang/đợt:</span>
              <select id="dvcqg-select-max-pages" style="padding: 2px 6px; border: 1px solid #0d9488; border-radius: 4px; font-size: 11px; font-weight: bold; color: #0f766e; background: #fff; cursor: pointer;">
                <option value="1" ${(state.config.maxPagesPerSearch ?? 3) === 1 ? 'selected' : ''}>1 trang</option>
                <option value="2" ${(state.config.maxPagesPerSearch ?? 3) === 2 ? 'selected' : ''}>2 trang</option>
                <option value="3" ${(state.config.maxPagesPerSearch ?? 3) === 3 ? 'selected' : ''}>3 trang (Mặc định)</option>
                <option value="5" ${(state.config.maxPagesPerSearch ?? 3) === 5 ? 'selected' : ''}>5 trang</option>
              </select>
            </div>
          </div>

          <!-- Lọc trạng thái đồng bộ -->
          <div class="dvcqg-status-box">
            <div class="dvcqg-status-title">
              <span>TRẠNG THÁI CẦN TRÍCH XUẤT</span>
              <span id="dvcqg-extracted-count" style="color: #0b6e6e; font-weight: bold;">0 khối</span>
            </div>
            <div class="dvcqg-status-list">
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-KhoiTaoHoSoBN" checked disabled title="KhoiTaoHoSoBN là giá trị bắt buộc đầu tiên cho tất cả hồ sơ">
                <span class="code-badge" style="background:#e0f2fe; color:#0369a1; border-color:#bae6fd;">KhoiTaoHoSoBN ★ Đầu tiên</span>
                <span class="item-desc">Khởi tạo</span>
                <span id="badge-st-KhoiTaoHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TiepNhanHoSoBN" ${state.config.selectedStatuses.TiepNhanHoSoBN ? 'checked' : ''}>
                <span class="code-badge">TiepNhanHoSoBN</span>
                <span class="item-desc">Tiếp nhận</span>
                <span id="badge-st-TiepNhanHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-BoSungHoSoDVC" ${state.config.selectedStatuses.BoSungHoSoDVC ? 'checked' : ''}>
                <span class="code-badge">BoSungHoSoDVC</span>
                <span class="item-desc">Bổ sung HS</span>
                <span id="badge-st-BoSungHoSoDVC" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-CapNhatTienTrinhXuLyHoSoBN" ${state.config.selectedStatuses.CapNhatTienTrinhXuLyHoSoBN ? 'checked' : ''}>
                <span class="code-badge">CapNhatTienTrinhXuLyHoSoBN</span>
                <span class="item-desc">Tiến trình</span>
                <span id="badge-st-CapNhatTienTrinhXuLyHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-GiaHanXuLyHoSoBN" ${state.config.selectedStatuses.GiaHanXuLyHoSoBN ? 'checked' : ''}>
                <span class="code-badge">GiaHanXuLyHoSoBN</span>
                <span class="item-desc">Gia hạn</span>
                <span id="badge-st-GiaHanXuLyHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TaoYeuCauThucHienNghiaVuTaiChinhBN" ${state.config.selectedStatuses.TaoYeuCauThucHienNghiaVuTaiChinhBN ? 'checked' : ''}>
                <span class="code-badge">TaoYeuCauThucHienNghiaVuTaiChinhBN</span>
                <span class="item-desc">Y/c tài chính</span>
                <span id="badge-st-TaoYeuCauThucHienNghiaVuTaiChinhBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-HuyYeuCauThucHienNghiaVuTaiChinhBN" ${state.config.selectedStatuses.HuyYeuCauThucHienNghiaVuTaiChinhBN ? 'checked' : ''}>
                <span class="code-badge">HuyYeuCauThucHienNghiaVuTaiChinhBN</span>
                <span class="item-desc">Hủy Y/c TC</span>
                <span id="badge-st-HuyYeuCauThucHienNghiaVuTaiChinhBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-DongBoThongTinThanhToan" ${(state.config.selectedStatuses.DongBoThongTinThanhToan !== false && (state.config.selectedStatuses.DongBoThongTinThanhToan || state.config.selectedStatuses.DongBoThongTinThanhToanBN !== false || state.config.selectedStatuses.DongBoThongTinThanhToanDVC !== false)) ? 'checked' : ''}>
                <span class="code-badge" title="Đồng bộ thông tin thanh toán (Tự động thu thập cả Cổng DVC Quốc gia và Hệ thống Bộ/Ngành)">DongBoThongTinThanhToan</span>
                <span class="item-desc">Thanh toán (DVC/BN)</span>
                <span id="badge-st-DongBoThongTinThanhToan" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TraKetQuaBN" ${state.config.selectedStatuses.TraKetQuaBN ? 'checked' : ''}>
                <span class="code-badge">TraKetQuaBN</span>
                <span class="item-desc">Trả kết quả</span>
                <span id="badge-st-TraKetQuaBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item" style="margin-top: 4px; padding-top: 4px; border-top: 1px dashed #cbd5e1; font-weight: 600; color: #047857;">
                <input type="checkbox" id="dvcqg-check-only-completed" ${state.config.onlyCompleted ? 'checked' : ''}>
                <span>Chỉ lấy trạng thái <b>COMPLETED / SUCCESS</b></span>
              </label>
              <label class="dvcqg-checkbox-item" style="margin-top: 3px; font-weight: 600; color: #0b6e6e;">
                <input type="checkbox" id="dvcqg-check-deduplicate" ${state.config.deduplicateStatus !== false ? 'checked' : ''}>
                <span title="Mỗi trạng thái (Khởi tạo, Tiếp nhận,...) chỉ lấy 1 khối duy nhất, loại bỏ hoàn toàn các khối trùng lặp">Tránh lấy lặp lại khối trạng thái giống nhau</span>
              </label>
            </div>
          </div>

          <!-- Step tracker: Hiển thị số step đã thực hiện từ Khởi tạo đến Trả kết quả -->
          <div class="dvcqg-step-tracker-box">
            <div class="dvcqg-step-tracker-header">
              <span class="dvcqg-step-tracker-title">TIẾN TRÌNH (KHỞI TẠO ➜ TRẢ KẾT QUẢ)</span>
              <span id="dvcqg-step-counter-badge" class="dvcqg-step-counter-badge">0/${STEP_DEFINITIONS.length} steps</span>
            </div>
            <!-- Mini progress bar -->
            <div class="dvcqg-step-mini-bar">
              <div id="dvcqg-step-mini-fill" class="dvcqg-step-mini-fill" style="width: 0%;"></div>
            </div>
            <div id="dvcqg-step-chips" class="dvcqg-step-chips">
              <span class="dvcqg-step-chip pending" id="chip-KhoiTaoHoSoBN" title="1. Khởi tạo hồ sơ">
                <span class="step-chip-name">1. Khởi tạo</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TiepNhanHoSoBN" title="2. Tiếp nhận hồ sơ">
                <span class="step-chip-name">2. Tiếp nhận</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-BoSungHoSoDVC" title="2b. Bổ sung hồ sơ DVC (Tùy chọn)">
                <span class="step-chip-name">2b. Bổ sung HS</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-CapNhatTienTrinhXuLyHoSoBN" title="3. Cập nhật tiến trình">
                <span class="step-chip-name">3. Tiến trình</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-GiaHanXuLyHoSoBN" title="4. Gia hạn xử lý">
                <span class="step-chip-name">4. Gia hạn</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TaoYeuCauThucHienNghiaVuTaiChinhBN" title="5. Tạo yêu cầu tài chính">
                <span class="step-chip-name">5. Tạo Y/c TC</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-HuyYeuCauThucHienNghiaVuTaiChinhBN" title="6. Hủy yêu cầu tài chính">
                <span class="step-chip-name">6. Hủy Y/c TC</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-DongBoThongTinThanhToan" title="7. Đồng bộ thanh toán (DVC / Bộ Ngành)">
                <span class="step-chip-name">7. Thanh toán</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TraKetQuaBN" title="8. Trả kết quả">
                <span class="step-chip-name">8. Trả kết quả</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
            </div>
          </div>

          <!-- Auto transfer option -->
          <label class="dvcqg-option-checkbox">
            <input type="checkbox" id="dvcqg-check-autotransfer" ${state.config.autoTransfer ? 'checked' : ''}>
            <span>Tự động mở và nạp vào trang Rà soát</span>
          </label>

          <!-- Tùy chọn Trang Rà soát mục tiêu (Máy chủ chính & Dự phòng Gia Lai & Tùy chỉnh) -->
          <div class="dvcqg-rasoat-config-box">
            <div class="dvcqg-rasoat-config-header">
              <span class="dvcqg-rasoat-config-title">🌐 Trang Rà soát mục tiêu:</span>
              <span id="dvcqg-rasoat-badge" class="dvcqg-rasoat-badge ${
                state.config.rasoatUrl === RASOAT_URL_GIALAI ? 'backup' : (state.config.rasoatUrl === RASOAT_URL_PRIMARY ? 'primary' : 'custom')
              }">${
                state.config.rasoatUrl === RASOAT_URL_GIALAI ? 'Dự phòng Gia Lai' : (state.config.rasoatUrl === RASOAT_URL_PRIMARY ? 'Chính' : 'Tùy chỉnh')
              }</span>
            </div>
            <div class="dvcqg-rasoat-selector-grid">
              <button type="button" class="dvcqg-rasoat-tab-btn ${state.config.rasoatUrl === RASOAT_URL_PRIMARY ? 'active' : ''}" data-rasoat-type="primary" title="Máy chủ chính: ${RASOAT_URL_PRIMARY}">
                <span class="rasoat-tab-title">🌐 Máy chủ chính</span>
                <span class="rasoat-tab-sub">cdn.dnncloud.net</span>
              </button>
              <button type="button" class="dvcqg-rasoat-tab-btn ${state.config.rasoatUrl === RASOAT_URL_GIALAI ? 'active' : ''}" data-rasoat-type="gialai" title="Dự phòng Gia Lai: ${RASOAT_URL_GIALAI}">
                <span class="rasoat-tab-title">🛡️ Dự phòng Gia Lai</span>
                <span class="rasoat-tab-sub">hcc.gialai.gov.vn</span>
              </button>
              <button type="button" class="dvcqg-rasoat-tab-btn ${state.config.rasoatUrl !== RASOAT_URL_PRIMARY && state.config.rasoatUrl !== RASOAT_URL_GIALAI ? 'active' : ''}" data-rasoat-type="custom" title="Tùy chỉnh URL trang rà soát khác">
                <span class="rasoat-tab-title">⚙️ Tùy chỉnh URL</span>
                <span class="rasoat-tab-sub">Tự nhập...</span>
              </button>
            </div>
            <div id="dvcqg-rasoat-custom-row" style="display: ${state.config.rasoatUrl !== RASOAT_URL_PRIMARY && state.config.rasoatUrl !== RASOAT_URL_GIALAI ? 'block' : 'none'}; margin-top: 6px;">
              <input type="url" id="dvcqg-rasoat-custom-url" class="dvcqg-input-text" style="font-size: 11px; padding: 5px 8px; width: 100%; box-sizing: border-box;" placeholder="https://domain.com/.../rasoat.html" value="${state.config.rasoatUrl !== RASOAT_URL_PRIMARY && state.config.rasoatUrl !== RASOAT_URL_GIALAI ? state.config.rasoatUrl : ''}">
            </div>
          </div>

          <!-- Batch progress bar -->
          <div id="dvcqg-batch-progress" class="dvcqg-progress-container" style="display: none;">
            <div class="dvcqg-progress-header">
              <span id="dvcqg-progress-text">Đang xử lý: 0/0 hồ sơ</span>
              <span id="dvcqg-progress-pct">0%</span>
            </div>
            <div class="dvcqg-progress-bar">
              <div id="dvcqg-progress-fill" class="dvcqg-progress-fill"></div>
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="dvcqg-action-grid">
            <button id="dvcqg-btn-run" class="dvcqg-btn-primary">
              <span>▶ Bắt đầu Tự Động</span>
            </button>
            <button id="dvcqg-btn-stop" class="dvcqg-btn-danger" style="display: none;">
              <span>⏹ Dừng tiến trình</span>
            </button>
            <button id="dvcqg-btn-direct" class="dvcqg-btn-secondary" title="Trích xuất từ bảng kết quả đang hiển thị trên màn hình">
              <span>⚡ Trích xuất bảng hiện tại</span>
            </button>
            <div class="dvcqg-sub-actions">
              <button id="dvcqg-btn-preview" class="dvcqg-btn-ghost">📋 Xem XML</button>
              <button id="dvcqg-btn-send-manual" class="dvcqg-btn-ghost">🚀 Sang Rà soát</button>
            </div>
          </div>

          <!-- Live Log Console -->
          <div id="dvcqg-log-box" class="dvcqg-log-box"></div>
        </div>

        <!-- Footer Credit -->
        <div class="dvcqg-panel-footer" style="padding: 6px 14px; font-size: 11px; color: #64748b; background: #f8fafc; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; border-radius: 0 0 12px 12px;">
          <span>Tác giả: <strong style="color: #0b6e6e;">Kyn Chou</strong></span>
          <span id="dvcqg-footer-version" style="font-weight: 500;">${extVersionName}</span>
        </div>
      </div>
    `;

    document.body.appendChild(rootEl);
    logBoxEl = document.getElementById('dvcqg-log-box');

    log('Extension sẵn sàng! Nhập danh sách mã hồ sơ và nhấn "Bắt đầu Tự Động".', 'info');

    bindUiEvents();
  }

  function bindUiEvents() {
    const launcher = document.getElementById('dvcqg-launcher');
    const panel = document.getElementById('dvcqg-panel');
    const btnMin = document.getElementById('dvcqg-btn-minimize');
    const btnClose = document.getElementById('dvcqg-btn-close');

    launcher.addEventListener('click', () => {
      launcher.style.display = 'none';
      panel.style.display = 'flex';
    });

    btnMin.addEventListener('click', () => {
      panel.style.display = 'none';
      launcher.style.display = 'flex';
    });

    btnClose.addEventListener('click', () => {
      panel.style.display = 'none';
      launcher.style.display = 'flex';
    });

    // Multi-line MaHoSo textarea sync
    const textareaMa = document.getElementById('dvcqg-textarea-ma');
    const maCountEl = document.getElementById('dvcqg-ma-count');

    function updateMaCount() {
      const list = parseMaHoSoList(textareaMa.value);
      if (maCountEl) {
        if (list.length > 0) {
          maCountEl.textContent = `(${list.length} mã)`;
          maCountEl.style.color = '#0b6e6e';
        } else {
          maCountEl.textContent = `(Quét toàn bộ theo ngày)`;
          maCountEl.style.color = '#0284c7';
        }
      }
    }

    // Bắt sự kiện Paste trực tiếp trên ô nhập mã (Ctrl+V / Cmd+V / Chuột phải)
    textareaMa.addEventListener('paste', (e) => {
      const clipboardData = e.clipboardData || window.clipboardData;
      const text = clipboardData ? clipboardData.getData('text') : '';
      if (text && text.trim()) {
        const extractedCodes = parseMaHoSoList(text);
        if (extractedCodes.length > 0) {
          e.preventDefault();
          const currentList = parseMaHoSoList(textareaMa.value);
          const combined = Array.from(new Set([...currentList, ...extractedCodes]));
          const updated = combined.join('\n');
          textareaMa.value = updated;
          state.config.maHoSoListText = updated;
          updateMaCount();
          autoSelectInitialDateFromMaHoSo(true);
          saveConfig();
          log(`📋 [Dán mã hồ sơ]: Đã nhận ${extractedCodes.length} mã hợp lệ & TỰ ĐỘNG CHỌN chế độ tra cứu thời gian theo mã (không cần chọn thủ công)!`, 'success');
          return;
        }
      }
      setTimeout(() => {
        state.config.maHoSoListText = textareaMa.value;
        updateMaCount();
        autoSelectInitialDateFromMaHoSo(true);
        saveConfig();
      }, 50);
    });

    textareaMa.addEventListener('input', (e) => {
      state.config.maHoSoListText = e.target.value;
      updateMaCount();
      autoSelectInitialDateFromMaHoSo(true);
      saveConfig();
    });

    // Paste from Clipboard into MaHoSo textarea (Xử lý lỗi dán dữ liệu thông minh)
    const btnPasteMa = document.getElementById('dvcqg-btn-paste-ma');
    if (btnPasteMa) {
      btnPasteMa.addEventListener('click', async () => {
        let text = '';
        try {
          text = await navigator.clipboard.readText();
        } catch (err) {
          // Fallback khi trình duyệt chặn clipboard: focus và thử paste hoặc prompt
          textareaMa.focus();
          try {
            document.execCommand('paste');
            text = textareaMa.value;
          } catch (e2) {}
          if (!text) {
            text = prompt('Vui lòng dán danh sách mã hồ sơ vào ô dưới đây (Ctrl+V hoặc Cmd+V):') || '';
          }
        }

        if (text && text.trim()) {
          // Trích xuất mã hồ sơ sạch từ văn bản dán vào (tự động loại bỏ các cột ngày tháng, STT, trạng thái rác)
          const extractedCodes = parseMaHoSoList(text);
          if (extractedCodes.length > 0) {
            const currentList = parseMaHoSoList(textareaMa.value);
            const combined = Array.from(new Set([...currentList, ...extractedCodes]));
            const updated = combined.join('\n');
            textareaMa.value = updated;
            state.config.maHoSoListText = updated;
            updateMaCount();
            autoSelectInitialDateFromMaHoSo(true);
            saveConfig();
            log(`✓ Đã dán thành công ${extractedCodes.length} mã hồ sơ hợp lệ vào danh sách!`, 'success');
          } else {
            const current = textareaMa.value.trim();
            const updated = current ? `${current}\n${text.trim()}` : text.trim();
            textareaMa.value = updated;
            state.config.maHoSoListText = updated;
            updateMaCount();
            autoSelectInitialDateFromMaHoSo(true);
            saveConfig();
            log('✓ Đã dán nội dung vào danh sách mã hồ sơ!', 'success');
          }
        } else {
          log('Clipboard hiện đang trống hoặc chưa được cấp quyền đọc!', 'warn');
        }
      });
    }


    // Clear MaHoSo list và xóa trắng luôn ô "Mã hồ sơ" trên trang web DVCQG
    document.getElementById('dvcqg-btn-clear-ma')?.addEventListener('click', () => {
      textareaMa.value = '';
      state.config.maHoSoListText = '';
      updateMaCount();
      saveConfig();

      // NÂNG CẤP: Thực hiện xóa luôn dữ liệu tại ô "Mã hồ sơ" trên trang web DVCQG
      const pageInput = findMaHoSoInput();
      if (pageInput) {
        setNativeValue(pageInput, '');
        pageInput.value = '';
        pageInput.dispatchEvent(new Event('input', { bubbles: true }));
        pageInput.dispatchEvent(new Event('change', { bubbles: true }));
        log('✓ Đã xóa trắng ô "Mã hồ sơ" trên form trang web DVCQG.', 'info');
      }

      log('🗑️ Đã xóa danh sách mã hồ sơ và xóa luôn ô "Mã hồ sơ" trên trang web -> Sẵn sàng chế độ Quét toàn bộ theo khoảng thời gian (Hôm nay, Tháng này, 30 ngày...).', 'info');
    });

    // Dates
    const inputFrom = document.getElementById('dvcqg-input-from');
    const inputTo = document.getElementById('dvcqg-input-to');

    inputFrom.addEventListener('change', (e) => {
      state.config.fromDate = e.target.value;
      if (e.target.value) {
        const fromD = new Date(e.target.value);
        if (!isNaN(fromD.getTime())) {
          const endOfMonth = new Date(fromD.getFullYear(), fromD.getMonth() + 1, 0);
          const currentTo = state.config.toDate ? new Date(state.config.toDate) : null;
          // Nếu Đến ngày chưa có hoặc đang vượt sang tháng khác, tự động điều chỉnh tối đa trong tháng
          if (!currentTo || currentTo.getFullYear() !== fromD.getFullYear() || currentTo.getMonth() !== fromD.getMonth()) {
            const now = new Date();
            let newTo = endOfMonth;
            if (now.getFullYear() === fromD.getFullYear() && now.getMonth() === fromD.getMonth() && now < endOfMonth) {
              newTo = now;
            }
            const newToYmd = formatDateYMD(newTo);
            state.config.toDate = newToYmd;
            if (inputTo) inputTo.value = newToYmd;
            log(`📅 Tự động điều chỉnh Đến ngày theo tháng: ${formatDateDMY(newTo)} (tối đa trong tháng)`, 'info');
          }
        }
      }
      saveConfig();
    });

    inputTo.addEventListener('change', (e) => {
      state.config.toDate = e.target.value;
      saveConfig();
    });

    inputFrom.addEventListener('change', () => {
      checkAndUpdateActivePresetTab();
    });

    inputTo.addEventListener('change', () => {
      checkAndUpdateActivePresetTab();
    });

    // Preset date buttons với hiệu ứng chọn tab sinh động
    document.querySelectorAll('.dvcqg-preset-btn[data-preset]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;
        const now = new Date();
        let toStr = formatDateYMD(now);
        let fromStr = toStr;

        // Kích hoạt hiệu ứng active tab & glow 2 ô ngày
        setActiveDatePresetButton(btn);

        if (preset === 'by-ma') {
          const success = autoSelectInitialDateFromMaHoSo(true);
          if (success) {
            highlightDateInputs();
          } else {
            log('⚠️ Chưa có mã hồ sơ hoặc không tìm thấy định dạng ngày trong mã!', 'warn');
          }
          return;
        } else if (preset === 'to-today') {
          // Tự nhận dạng mục Đến ngày là ngày hiện tại hôm nay
          toStr = formatDateYMD(now);
          inputTo.value = toStr;
          state.config.toDate = toStr;
          syncToDateWithDepthAndToday(true);
          highlightDateInputs();
          saveConfig();
          log(`🎯 Tự nhận dạng Đến ngày = Ngày hiện tại: ${formatDateDMY(toStr)}`, 'success');
          return;
        } else if (preset === 'this-month') {
          const startM = new Date(now.getFullYear(), now.getMonth(), 1);
          const endM = new Date(now.getFullYear(), now.getMonth() + 1, 0);
          fromStr = formatDateYMD(startM);
          toStr = formatDateYMD(endM);
        } else if (preset === 'today') {
          fromStr = toStr;
        } else if (preset === '7d') {
          const d = new Date();
          d.setDate(d.getDate() - 7);
          fromStr = formatDateYMD(d);
        } else if (preset === '30d') {
          const d = new Date();
          d.setDate(d.getDate() - 30);
          fromStr = formatDateYMD(d);
        } else if (preset === 'ytd') {
          fromStr = `${now.getFullYear()}-01-01`;
        }

        inputFrom.value = fromStr;
        inputTo.value = toStr;
        state.config.fromDate = fromStr;
        state.config.toDate = toStr;
        highlightDateInputs();
        saveConfig();
        log(`Đặt khoảng ngày [${btn.textContent.trim()}]: ${formatDateDMY(fromStr)} -> ${formatDateDMY(toStr)}`, 'info');
      });
    });

    // Checkboxes
    ['KhoiTaoHoSoBN', 'TiepNhanHoSoBN', 'BoSungHoSoDVC', 'CapNhatTienTrinhXuLyHoSoBN', 'GiaHanXuLyHoSoBN', 'TaoYeuCauThucHienNghiaVuTaiChinhBN', 'HuyYeuCauThucHienNghiaVuTaiChinhBN', 'DongBoThongTinThanhToan', 'TraKetQuaBN'].forEach(k => {
      const cb = document.getElementById(`st-${k}`);
      if (cb) {
        cb.addEventListener('change', (e) => {
          if (k === 'KhoiTaoHoSoBN') {
            state.config.selectedStatuses.KhoiTaoHoSoBN = true;
            cb.checked = true;
          } else {
            state.config.selectedStatuses[k] = e.target.checked;
            if (k === 'DongBoThongTinThanhToan') {
              state.config.selectedStatuses.DongBoThongTinThanhToanBN = e.target.checked;
              state.config.selectedStatuses.DongBoThongTinThanhToanDVC = e.target.checked;
            }
          }
          saveConfig();
        });
      }
    });

    const checkOnlyCompleted = document.getElementById('dvcqg-check-only-completed');
    if (checkOnlyCompleted) {
      checkOnlyCompleted.addEventListener('change', (e) => {
        state.config.onlyCompleted = e.target.checked;
        saveConfig();
        log(`Bộ lọc: ${e.target.checked ? 'Bật' : 'Tắt'} chế độ chỉ lấy COMPLETED`, 'info');
      });
    }

    const checkDeduplicate = document.getElementById('dvcqg-check-deduplicate');
    if (checkDeduplicate) {
      checkDeduplicate.addEventListener('change', (e) => {
        state.config.deduplicateStatus = e.target.checked;
        saveConfig();
        log(`Tránh lấy lặp trạng thái: ${e.target.checked ? 'Bật (mỗi trạng thái chỉ lấy 1 khối duy nhất)' : 'Tắt'}`, 'info');
      });
    }

    const checkSmartDate = document.getElementById('dvcqg-check-smart-date');
    if (checkSmartDate) {
      checkSmartDate.addEventListener('change', (e) => {
        state.config.smartDateSearch = e.target.checked;
        saveConfig();
        log(`Tìm kiếm ngày thông minh: ${e.target.checked ? 'Bật (quét qua tháng nếu thiếu TraKetQuaBN)' : 'Tắt (dùng khoảng ngày chỉ định)'}`, 'info');
      });
    }

    const selectSearchDepth = document.getElementById('dvcqg-select-search-depth');
    if (selectSearchDepth) {
      selectSearchDepth.addEventListener('change', (e) => {
        const val = parseInt(e.target.value, 10) || 3;
        state.config.searchDepthMonths = val;
        // NÂNG CẤP THÔNG MINH: Tự động nhận dạng mục "Đến ngày" với ngày hiện tại theo độ sâu mới
        syncToDateWithDepthAndToday(true);
        saveConfig();
        log(`⚙️ Đã thiết lập độ sâu rà soát: tối đa ${val} tháng sau đó. Tự động nhận dạng mục Đến ngày với ngày hiện tại.`, 'info');
      });
    }

    // Chế độ thông minh tương thích tốc độ tải
    const checkAdaptiveSpeed = document.getElementById('dvcqg-check-adaptive-speed');
    if (checkAdaptiveSpeed) {
      checkAdaptiveSpeed.addEventListener('change', (e) => {
        state.config.adaptiveSpeed = e.target.checked;
        saveConfig();
        log(`🧠 Tương thích tốc độ tải: ${e.target.checked ? 'Bật (Tự động theo dõi máy chủ nạp 100% dữ liệu)' : 'Tắt'}`, 'info');
      });
    }

    const selectSpeedMode = document.getElementById('dvcqg-select-speed-mode');
    if (selectSpeedMode) {
      selectSpeedMode.addEventListener('change', (e) => {
        state.config.speedMode = e.target.value;
        saveConfig();
        const modeLabels = {
          adaptive: '⚡ Tự thích ứng (Khuyên dùng)',
          safe: '🐢 Chờ an toàn (Mạng chậm/Lag)',
          fast: '🚀 Tốc độ cao'
        };
        log(`⚙️ Đã chuyển chế độ tốc độ: ${modeLabels[e.target.value] || e.target.value}`, 'info');
      });
    }

    const selectMaxPages = document.getElementById('dvcqg-select-max-pages');
    if (selectMaxPages) {
      selectMaxPages.addEventListener('change', (e) => {
        const val = parseInt(e.target.value, 10) || 3;
        state.config.maxPagesPerSearch = val;
        saveConfig();
        log(`⚙️ Đã thiết lập qua tối đa: ${val} trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp.`, 'info');
      });
    }

    const checkAutoTransfer = document.getElementById('dvcqg-check-autotransfer');
    checkAutoTransfer.addEventListener('change', (e) => {
      state.config.autoTransfer = e.target.checked;
      saveConfig();
    });

    // Khởi tạo bộ chọn trang Rà soát mục tiêu (Máy chủ chính, Dự phòng Gia Lai, Tùy chỉnh)
    function initRasoatUrlSelector() {
      const tabBtns = document.querySelectorAll('.dvcqg-rasoat-tab-btn');
      const badgeEl = document.getElementById('dvcqg-rasoat-badge');
      const customRow = document.getElementById('dvcqg-rasoat-custom-row');
      const customInput = document.getElementById('dvcqg-rasoat-custom-url');

      function updateRasoatUi(targetType, customUrl) {
        tabBtns.forEach(b => {
          b.classList.toggle('active', b.getAttribute('data-rasoat-type') === targetType);
        });
        if (targetType === 'primary') {
          state.config.rasoatUrl = RASOAT_URL_PRIMARY;
          if (customRow) customRow.style.display = 'none';
          if (badgeEl) {
            badgeEl.className = 'dvcqg-rasoat-badge primary';
            badgeEl.textContent = 'Chính';
          }
        } else if (targetType === 'gialai') {
          state.config.rasoatUrl = RASOAT_URL_GIALAI;
          if (customRow) customRow.style.display = 'none';
          if (badgeEl) {
            badgeEl.className = 'dvcqg-rasoat-badge backup';
            badgeEl.textContent = 'Dự phòng Gia Lai';
          }
        } else if (targetType === 'custom') {
          if (customRow) customRow.style.display = 'block';
          if (customInput) {
            if (customUrl) customInput.value = customUrl;
            customInput.focus();
            state.config.rasoatUrl = customInput.value.trim() || RASOAT_URL_PRIMARY;
          }
          if (badgeEl) {
            badgeEl.className = 'dvcqg-rasoat-badge custom';
            badgeEl.textContent = 'Tùy chỉnh';
          }
        }
        saveConfig();
      }

      tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          const type = btn.getAttribute('data-rasoat-type');
          updateRasoatUi(type);
          if (type === 'primary') {
            log('🌐 Đã chọn trang rà soát: Máy chủ chính (cdn.dnncloud.net)', 'info');
          } else if (type === 'gialai') {
            log('🛡️ Đã chọn trang rà soát: Máy chủ dự phòng Gia Lai (hcc.gialai.gov.vn)', 'info');
          } else if (type === 'custom') {
            log('⚙️ Đã chọn chế độ Tùy chỉnh URL trang rà soát', 'info');
          }
        });
      });

      if (customInput) {
        customInput.addEventListener('input', (e) => {
          const val = e.target.value.trim();
          if (val) {
            state.config.rasoatUrl = val;
            saveConfig();
          }
        });
      }
    }

    initRasoatUrlSelector();

    // Actions
    document.getElementById('dvcqg-btn-run').addEventListener('click', executeAutoFlow);
    document.getElementById('dvcqg-btn-direct').addEventListener('click', executeCurrentTableExtract);

    // Stop button
    document.getElementById('dvcqg-btn-stop').addEventListener('click', () => {
      state.isStopping = true;
      log('Đang yêu cầu dừng tiến trình sau hồ sơ hiện tại...', 'warn');
      const stopBtn = document.getElementById('dvcqg-btn-stop');
      if (stopBtn) {
        stopBtn.disabled = true;
        stopBtn.innerHTML = '<span>⏳ Đang dừng...</span>';
      }
    });

    document.getElementById('dvcqg-btn-send-manual').addEventListener('click', () => {
      if (!state.lastExtractedCombined) {
        alert('Chưa có dữ liệu XML nào! Vui lòng trích xuất trước.');
        return;
      }
      transferDataToRasoat(state.lastExtractedCombined, 'Nhiều hồ sơ', state.config.fromDate, state.config.toDate);
    });

    document.getElementById('dvcqg-btn-preview').addEventListener('click', showXmlPreviewModal);

    // Kích hoạt nhận diện tab active ban đầu theo khoảng ngày hiện có
    checkAndUpdateActivePresetTab();
  }

  function saveConfig() {
    chrome.storage.local.set({ dvcqg_config: state.config });
  }

  // XML Preview Modal
  function showXmlPreviewModal() {
    const existing = document.getElementById('dvcqg-preview-modal');
    if (existing) existing.remove();

    const xml = state.lastExtractedCombined || 'Chưa có khối XML nào được trích xuất.';

    const modal = document.createElement('div');
    modal.id = 'dvcqg-preview-modal';
    modal.className = 'dvcqg-modal-overlay';
    modal.innerHTML = `
      <div class="dvcqg-modal-card">
        <div class="dvcqg-modal-header">
          <span style="font-weight: bold;">Xem trước Request Body XML (${state.extractedXmlBlocks.length} khối)</span>
          <button id="dvcqg-modal-close" class="dvcqg-icon-btn">✕</button>
        </div>
        <div class="dvcqg-modal-body">
          <textarea readonly class="dvcqg-modal-textarea">${xml.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
        </div>
        <div class="dvcqg-modal-footer">
          <button id="dvcqg-modal-copy" class="dvcqg-btn-secondary" style="width: auto;">📋 Sao chép</button>
          <button id="dvcqg-modal-send" class="dvcqg-btn-primary" style="width: auto;">🚀 Gửi sang Rà soát</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#dvcqg-modal-close').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });

    modal.querySelector('#dvcqg-modal-copy').addEventListener('click', () => {
      navigator.clipboard.writeText(xml).then(() => {
        alert('Đã sao chép XML vào clipboard!');
      });
    });

    modal.querySelector('#dvcqg-modal-send').addEventListener('click', () => {
      modal.remove();
      transferDataToRasoat(xml, 'Nhiều hồ sơ', state.config.fromDate, state.config.toDate);
    });
  }

  // Auto-init UI when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildUi);
  } else {
    buildUi();
  }

})();

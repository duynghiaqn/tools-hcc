// dvcqg-injected.js - Injected into the page's main execution context to intercept XHR & Fetch requests
(function () {
  console.log('[DVCQG Auto] Injected script initialized to monitor sync data & network loading state.');

  let activeRequestsCount = 0;

  // Sync active request count to DOM dataset & window messages for adaptive loading speed
  function updateNetworkState() {
    activeRequestsCount = Math.max(0, activeRequestsCount);
    try {
      if (document.documentElement) {
        document.documentElement.dataset.dvcqgActiveRequests = String(activeRequestsCount);
        document.documentElement.dataset.dvcqgLastNetworkTime = String(Date.now());
      }
      window.postMessage({
        type: 'DVCQG_NETWORK_STATE',
        activeRequests: activeRequestsCount,
        timestamp: Date.now()
      }, '*');
    } catch (e) {}
  }

  // Helper to safely parse JSON
  function tryParseJson(text) {
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  // Helper to extract XML or sync info from response
  function processResponse(url, data) {
    if (!data) return;

    // Check if data is string containing DVCQG Envelope (either dichvucong.gov.vn/api/v1 or XMLSchema)
    if (
      typeof data === 'string' &&
      (data.includes('<Envelope') || data.includes('&lt;Envelope') || (/<\?xml/i.test(data) && data.includes('Envelope')) || (/&lt;\?xml/i.test(data) && data.includes('Envelope'))) &&
      (data.includes('http://dichvucong.gov.vn/api/v1') ||
       data.includes('https://dichvucong.gov.vn/api/v1') ||
       data.includes('http://www.w3.org/2001/XMLSchema') ||
       data.includes('https://www.w3.org/2001/XMLSchema'))
    ) {
      window.postMessage({
        type: 'DVCQG_CAPTURED_XML',
        url: url,
        xml: data
      }, '*');
      return;
    }

    // Check if data is object with sync records or details
    const json = typeof data === 'object' ? data : tryParseJson(data);
    if (!json) return;

    // Notify content script of captured network response
    window.postMessage({
      type: 'DVCQG_NETWORK_RESPONSE',
      url: url,
      data: json
    }, '*');
  }

  // 1. Hook XMLHttpRequest
  const originalXhrOpen = XMLHttpRequest.prototype.open;
  const originalXhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._dvcqg_url = url;
    this._dvcqg_method = method;
    return originalXhrOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    activeRequestsCount++;
    updateNetworkState();

    let finished = false;
    const onFinished = () => {
      if (finished) return;
      finished = true;
      activeRequestsCount--;
      updateNetworkState();
    };

    this.addEventListener('load', function () {
      try {
        if (this.responseType === '' || this.responseType === 'text') {
          processResponse(this._dvcqg_url, this.responseText);
        } else if (this.responseType === 'json') {
          processResponse(this._dvcqg_url, this.response);
        }
      } catch (err) {
        console.debug('[DVCQG Auto] XHR error:', err);
      } finally {
        onFinished();
      }
    });

    this.addEventListener('error', onFinished);
    this.addEventListener('abort', onFinished);
    this.addEventListener('timeout', onFinished);
    this.addEventListener('loadend', onFinished);

    return originalXhrSend.apply(this, arguments);
  };

  // 2. Hook window.fetch
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    activeRequestsCount++;
    updateNetworkState();

    const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';

    try {
      const response = await originalFetch.apply(this, args);
      try {
        const clone = response.clone();
        clone.text().then(text => {
          processResponse(url, text);
        }).catch(() => {});
      } catch (e) {}
      return response;
    } finally {
      activeRequestsCount--;
      updateNetworkState();
    }
  };

  // Initial network state sync
  updateNetworkState();
})();

// background.js - Service worker for DVCQG Auto Sync & Review
'use strict';

console.log('[DVCQG Auto SW] Background service worker initialized.');

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message.action === 'TRANSFER_TO_RASOAT') {
        const { xml, maHoSo, fromDate, toDate, targetUrl } = message.data || {};

        // Xác định URL trang rà soát mục tiêu
        let finalRasoatUrl = targetUrl;
        if (!finalRasoatUrl) {
          const { dvcqg_config } = await chrome.storage.local.get('dvcqg_config');
          finalRasoatUrl = dvcqg_config?.rasoatUrl || 'https://cdn.dnncloud.net/tthc/rasoat.html';
        }

        // Persist pending data and last extracted data in storage so rasoat-content.js can read on load
        const payload = {
          xml,
          maHoSo,
          fromDate,
          toDate,
          targetUrl: finalRasoatUrl,
          timestamp: Date.now()
        };
        await chrome.storage.local.set({
          pending_rasoat_data: payload,
          last_extracted_xml: payload
        });

        // Tìm kiếm các tab rà soát đang mở (cả máy chủ chính và dự phòng hoặc URL mục tiêu)
        const baseUrl = finalRasoatUrl.split('?')[0].split('#')[0];
        const exactTabs = await chrome.tabs.query({ url: `${baseUrl}*` });

        // Tìm thêm bất kỳ tab rà soát nào đang mở
        const anyRasoatTabs = exactTabs.length > 0 ? exactTabs : await chrome.tabs.query({
          url: [
            'https://cdn.dnncloud.net/tthc/rasoat.html*',
            'https://hcc.gialai.gov.vn/tools/rasoat.html*'
          ]
        });

        if (exactTabs.length > 0) {
          const targetTab = exactTabs[0];
          await chrome.tabs.update(targetTab.id, { active: true });
          if (targetTab.windowId) {
            await chrome.windows.update(targetTab.windowId, { focused: true });
          }

          // Directly notify tab content script to fill and run
          let notified = false;
          try {
            const resp = await chrome.tabs.sendMessage(targetTab.id, {
              action: 'FILL_AND_ANALYZE',
              data: { xml, maHoSo, fromDate, toDate }
            });
            if (resp && resp.received) {
              notified = true;
            }
          } catch (e) {
            console.log('[DVCQG Auto SW] Tab direct message failed, attempting dynamic injection...');
          }

          if (!notified) {
            // Tab có thể đã mở trước khi nạp extension hoặc content script bị mất kết nối
            try {
              if (chrome.scripting) {
                await chrome.scripting.insertCSS({
                  target: { tabId: targetTab.id },
                  files: ['content-scripts/rasoat-content.css']
                }).catch(() => {});
                await chrome.scripting.executeScript({
                  target: { tabId: targetTab.id },
                  files: ['content-scripts/rasoat-content.js']
                });
                // Chờ script khởi tạo và gửi lại
                await new Promise((r) => setTimeout(r, 250));
                await chrome.tabs.sendMessage(targetTab.id, {
                  action: 'FILL_AND_ANALYZE',
                  data: { xml, maHoSo, fromDate, toDate }
                }).catch(() => {});
              } else {
                chrome.tabs.reload(targetTab.id).catch(() => {});
              }
            } catch (injErr) {
              console.log('[DVCQG Auto SW] Không thể inject script, reload tab:', injErr.message);
              chrome.tabs.reload(targetTab.id).catch(() => {});
            }
          }

          sendResponse({ success: true, tabAction: 'updated', url: finalRasoatUrl });
        } else if (anyRasoatTabs.length > 0) {
          // Người dùng đã có sẵn tab rà soát khác -> Chuyển hướng tab đó sang URL mục tiêu đã chọn
          const existingTab = anyRasoatTabs[0];
          await chrome.tabs.update(existingTab.id, { url: finalRasoatUrl, active: true });
          if (existingTab.windowId) {
            await chrome.windows.update(existingTab.windowId, { focused: true });
          }
          sendResponse({ success: true, tabAction: 'redirected', url: finalRasoatUrl });
        } else {
          // Open new tab with selected rasoat URL
          const newTab = await chrome.tabs.create({
            url: finalRasoatUrl,
            active: true
          });

          // Hỗ trợ trường hợp URL tùy chỉnh ngoài các match tĩnh: tự động inject content script
          const isKnownDomain = finalRasoatUrl.includes('cdn.dnncloud.net') || finalRasoatUrl.includes('hcc.gialai.gov.vn');
          if (!isKnownDomain && newTab.id && chrome.scripting) {
            const listener = (tabId, changeInfo) => {
              if (tabId === newTab.id && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                chrome.scripting.insertCSS({
                  target: { tabId: newTab.id },
                  files: ['content-scripts/rasoat-content.css']
                }).catch(() => {});
                chrome.scripting.executeScript({
                  target: { tabId: newTab.id },
                  files: ['content-scripts/rasoat-content.js']
                }).catch(() => {});
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          }

          sendResponse({ success: true, tabAction: 'created', url: finalRasoatUrl });
        }
      } else if (message.action === 'GET_PENDING_DATA') {
        const { pending_rasoat_data } = await chrome.storage.local.get('pending_rasoat_data');
        sendResponse({ success: true, data: pending_rasoat_data || null });
      } else {
        sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (err) {
      console.error('[DVCQG Auto SW] Error in message handler:', err);
      sendResponse({ success: false, error: err.message });
    }
  })();

  return true; // Keep message channel open for async response
});

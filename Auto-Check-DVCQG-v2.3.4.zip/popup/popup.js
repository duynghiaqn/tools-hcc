// popup.js - Popup logic for DVCQG Auto Sync & Review
'use strict';

document.addEventListener('DOMContentLoaded', async () => {
  const RASOAT_URL_PRIMARY = 'https://cdn.dnncloud.net/tthc/rasoat.html';
  const RASOAT_URL_GIALAI = 'https://hcc.gialai.gov.vn/tools/rasoat.html';

  const btnDvcqg = document.getElementById('btn-open-dvcqg');
  const btnRasoat = document.getElementById('btn-open-rasoat');
  const prefAutoTransfer = document.getElementById('pref-autotransfer');
  const prefAdaptiveSpeed = document.getElementById('pref-adaptive-speed');

  const prefRasoatServer = document.getElementById('pref-rasoat-server');
  const prefRasoatCustomWrap = document.getElementById('pref-rasoat-custom-wrap');
  const prefRasoatCustomUrl = document.getElementById('pref-rasoat-custom-url');
  const rasoatBtnSub = document.getElementById('rasoat-btn-sub');
  const popupBadgeRasoatServer = document.getElementById('popup-badge-rasoat-server');
  const prefRasoatBadgeStatus = document.getElementById('pref-rasoat-badge-status');

  function updateRasoatServerUi(targetUrl) {
    const url = targetUrl || RASOAT_URL_PRIMARY;
    const isPrimary = url === RASOAT_URL_PRIMARY;
    const isGiaLai = url === RASOAT_URL_GIALAI;
    const isCustom = !isPrimary && !isGiaLai;

    if (prefRasoatServer) {
      if (isPrimary) {
        prefRasoatServer.value = RASOAT_URL_PRIMARY;
      } else if (isGiaLai) {
        prefRasoatServer.value = RASOAT_URL_GIALAI;
      } else {
        prefRasoatServer.value = 'custom';
      }
    }

    if (prefRasoatCustomWrap) {
      prefRasoatCustomWrap.style.display = isCustom ? 'block' : 'none';
    }
    if (prefRasoatCustomUrl && isCustom) {
      prefRasoatCustomUrl.value = url;
    }

    // Update badges
    const badgeText = isGiaLai ? 'Dự phòng Gia Lai' : (isPrimary ? 'Chính' : 'Tùy chỉnh');
    const badgeClass = isGiaLai ? 'badge-server backup' : (isPrimary ? 'badge-server' : 'badge-server custom');

    if (popupBadgeRasoatServer) {
      popupBadgeRasoatServer.className = badgeClass;
      popupBadgeRasoatServer.textContent = isGiaLai ? 'Gia Lai' : (isPrimary ? 'Chính' : 'Tùy chỉnh');
    }

    if (prefRasoatBadgeStatus) {
      prefRasoatBadgeStatus.className = badgeClass;
      prefRasoatBadgeStatus.textContent = badgeText;
    }

    // Update subtitle of rasoat link
    if (rasoatBtnSub) {
      try {
        const parsed = new URL(url);
        rasoatBtnSub.textContent = `${parsed.hostname}${parsed.pathname}`;
      } catch (e) {
        rasoatBtnSub.textContent = url;
      }
    }
  }

  // Dynamic version synchronization from manifest
  try {
    const manifest = chrome.runtime.getManifest?.();
    if (manifest && manifest.version) {
      const vBadge = document.getElementById('popup-version-badge') || document.querySelector('.version-badge');
      const vFooter = document.getElementById('popup-footer-version') || document.querySelector('.footer-status');
      const vName = manifest.version_name || `${manifest.version} (20/10/2026)`;
      if (vBadge) {
        vBadge.textContent = `v${manifest.version}`;
        vBadge.title = `Phiên bản ${manifest.version} - Ngày: ${vName} | Tác giả: Kyn Chou`;
      }
      if (vFooter) {
        vFooter.textContent = `🟢 v${vName}`;
        vFooter.title = `Ngày phiên bản: ${vName}`;
      }
    }
  } catch (e) {}

  // Load existing config
  const { dvcqg_config } = await chrome.storage.local.get('dvcqg_config');
  let currentRasoatUrl = RASOAT_URL_PRIMARY;

  if (dvcqg_config) {
    if (typeof dvcqg_config.autoTransfer === 'boolean' && prefAutoTransfer) {
      prefAutoTransfer.checked = dvcqg_config.autoTransfer;
    }
    if (typeof dvcqg_config.adaptiveSpeed === 'boolean' && prefAdaptiveSpeed) {
      prefAdaptiveSpeed.checked = dvcqg_config.adaptiveSpeed;
    }
    if (dvcqg_config.rasoatUrl) {
      currentRasoatUrl = dvcqg_config.rasoatUrl;
    }
  }

  updateRasoatServerUi(currentRasoatUrl);

  // Save config on change
  if (prefAutoTransfer) {
    prefAutoTransfer.addEventListener('change', async (e) => {
      const res = await chrome.storage.local.get('dvcqg_config');
      const config = res.dvcqg_config || {};
      config.autoTransfer = e.target.checked;
      await chrome.storage.local.set({ dvcqg_config: config });
    });
  }

  if (prefAdaptiveSpeed) {
    prefAdaptiveSpeed.addEventListener('change', async (e) => {
      const res = await chrome.storage.local.get('dvcqg_config');
      const config = res.dvcqg_config || {};
      config.adaptiveSpeed = e.target.checked;
      await chrome.storage.local.set({ dvcqg_config: config });
    });
  }

  if (prefRasoatServer) {
    prefRasoatServer.addEventListener('change', async (e) => {
      const val = e.target.value;
      const res = await chrome.storage.local.get('dvcqg_config');
      const config = res.dvcqg_config || {};

      if (val === 'custom') {
        if (prefRasoatCustomWrap) prefRasoatCustomWrap.style.display = 'block';
        if (prefRasoatCustomUrl) prefRasoatCustomUrl.focus();
        const customVal = prefRasoatCustomUrl ? prefRasoatCustomUrl.value.trim() : '';
        if (customVal) {
          config.rasoatUrl = customVal;
          await chrome.storage.local.set({ dvcqg_config: config });
          updateRasoatServerUi(customVal);
        } else {
          updateRasoatServerUi('https://');
        }
      } else {
        if (prefRasoatCustomWrap) prefRasoatCustomWrap.style.display = 'none';
        config.rasoatUrl = val;
        await chrome.storage.local.set({ dvcqg_config: config });
        updateRasoatServerUi(val);
      }
    });
  }

  if (prefRasoatCustomUrl) {
    prefRasoatCustomUrl.addEventListener('input', async (e) => {
      const val = e.target.value.trim();
      if (val) {
        const res = await chrome.storage.local.get('dvcqg_config');
        const config = res.dvcqg_config || {};
        config.rasoatUrl = val;
        await chrome.storage.local.set({ dvcqg_config: config });
        updateRasoatServerUi(val);
      }
    });
  }

  // Navigate to DVCQG
  btnDvcqg.addEventListener('click', async () => {
    const url = 'https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo';
    const tabs = await chrome.tabs.query({ url: `${url}*` });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    } else {
      await chrome.tabs.create({ url, active: true });
    }
    window.close();
  });

  // Navigate to Rasoat
  btnRasoat.addEventListener('click', async () => {
    const res = await chrome.storage.local.get('dvcqg_config');
    const url = res.dvcqg_config?.rasoatUrl || RASOAT_URL_PRIMARY;
    const baseUrl = url.split('?')[0].split('#')[0];
    const tabs = await chrome.tabs.query({ url: `${baseUrl}*` });
    if (tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    } else {
      await chrome.tabs.create({ url, active: true });
    }
    window.close();
  });
});


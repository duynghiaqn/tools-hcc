# Tiện ích Chrome: Auto Check DVCQG

> **Tác giả:** Kyn Chou  
> **Phiên bản:** v2.3.4  
> **Ngày phiên bản:** 23/10/2026  
> **Nền tảng:** Google Chrome Extension (Manifest V3)

Tiện ích mở rộng Google Chrome (Manifest V3) hỗ trợ cán bộ, chuyên viên tự động hóa toàn bộ quy trình tra cứu, trích xuất dữ liệu XML đồng bộ hồ sơ trên Cổng Dịch vụ công Quốc gia (DVCQG) và đối chiếu rà soát dữ liệu tại công cụ kiểm tra đồng bộ.

---

## 📌 Các tính năng chính

1. **Tra cứu thời gian thông minh theo Mã hồ sơ & Tự nhận dạng "Đến ngày" với ngày hiện tại**:
   - URL: `https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo`
   - **Tự động nhận diện thời gian từ cấu trúc mã & Tự kích hoạt "📅 Theo mã HS"**: Bóc tách chính xác ngày sinh của hồ sơ (ví dụ `H21.117-260812-0008` -> Năm 2026 - Tháng 08 - Ngày 12). Khi dán mã (bấm `📋 Dán`, phím tắt `Ctrl+V`/`Cmd+V` hoặc nhập mã), tiện ích **tự động kích hoạt ngay tab "📅 Theo mã HS"** sang trạng thái Active (màu gradient sáng) và phát sáng viền ô ngày, không bắt buộc người dùng bấm thủ công.
   - **Với KhoiTaoHoSo (BN/DVC): Ngày bắt đầu và kết thúc lấy theo ngày hồ sơ**:
     - `Từ ngày`: Đặt đúng ngày sinh của mã hồ sơ (`12/08/2026`).
     - `Đến ngày`: Đặt đúng ngày sinh của mã hồ sơ (`12/08/2026`), giúp tra cứu siêu nhanh và lấy chính xác ngay khối trạng thái `KhoiTaoHoSo` (hỗ trợ cả `KhoiTaoHoSoBN` và `KhoiTaoHoSoDVC`).
   - **Nâng cấp tự nhận dạng mục "Đến ngày" với ngày hiện tại theo độ sâu tháng**:
     - Khi rà soát theo độ sâu các tháng sau (tùy chỉnh 1 - 12 tháng sau), khi đợt quét tiến đến tháng hiện tại thì mục **Đến ngày** tự động nhận dạng chính xác là **Ngày hiện tại** (`now`), bảo đảm không vượt quá ngày hiện tại và loại bỏ hoàn toàn các đợt ở tháng tương lai.
     - Trên bảng điều khiển nổi: Khi thay đổi độ sâu rà soát tháng hoặc dán mã hồ sơ, mục "Đến ngày" tự động nhận diện và cập nhật đồng bộ với Ngày hiện tại (kèm huy hiệu trực quan `🎯 Đến ngày: Hôm nay`).
     - Bổ sung nút tiện ích nhanh `📅 Đến hôm nay` giúp đặt Đến ngày = Ngày hiện tại tức thì chỉ với 1 click.
   - **Tiếp tục rà quét thông minh thời gian tiếp theo đến khi tìm thấy TraKetQua (BN/DVC)**:
     - Đợt 2: Quét phần còn lại của tháng nộp (`13/08/2026` ➜ `31/08/2026`, hoặc ngày hiện tại nếu nộp cùng tháng).
     - Các đợt tiếp theo: Chuyển qua tháng khác với Từ ngày = 01 (ngày đầu tháng), Đến ngày = ngày cuối tháng (hoặc ngày hiện tại). Tuyệt đối không giữ ngày bắt đầu hồ sơ để đảm bảo Cổng DVCQG luôn tìm thấy dữ liệu!
     - **Cơ chế bước đệm thông minh (Safe Bridge Transition)**: Loại bỏ triệt để lỗi lặp ngày cuối tháng của mã hồ sơ khi chuyển tiếp sang tháng kế tiếp. Tự động áp dụng cơ chế bước đệm chuyển giao (thu hẹp Từ ngày = Đến ngày cũ -> Mở đường Đến ngày = 01 tháng mới -> Đặt Từ ngày = 01 tháng mới -> Mở rộng Đến ngày = cuối tháng mới). Tuyệt đối không để xảy ra xung đột ràng buộc `Từ ngày > Đến ngày` hay `Khoảng cách > 30 ngày` khiến trang web hoàn tác/kẹt ngày cũ.
     - **Bảo đảm quét đủ các tháng tiếp theo**: Không bị ngắt sớm giữa chừng, quét trọn vẹn đủ số tháng theo đúng cấu hình độ sâu đã chọn.
   - **Giới hạn thời gian an toàn**: Mỗi đợt tra cứu luôn bảo đảm Đến ngày tối đa trong tháng đó, tuân thủ nghiêm quy định giới hạn 1 tháng của Cổng DVCQG.
     - Tự động nhảy qua các tháng một cách tuần tự và an toàn.
     - Dừng ngay lập tức khi tìm thấy trạng thái kết thúc `TraKetQua (BN/DVC)` và hoàn tất hồ sơ.
     - Độ sâu rà soát tùy chỉnh: Cho phép điều chỉnh độ sâu linh hoạt từ 1 đến 12 tháng sau (mặc định 3 tháng sau đó) ngay trên giao diện điều khiển.
   - **Chế độ quét toàn bộ hồ sơ theo khoảng thời gian (Hôm nay, Tháng này, 30 ngày...) khi không có mã hồ sơ**:
     - Khi danh sách mã hồ sơ để trống (hoặc sau khi bấm `🗑️ Xóa`), hệ thống tự động nhận diện chế độ **Quét toàn bộ theo ngày**.
     - Hỗ trợ các nút chọn nhanh: **Hôm nay**, **Tháng này**, **30 ngày**, **📅 Đến hôm nay** hoặc tự nhập khoảng ngày tùy ý.
     - Tự động xóa trắng ô Mã hồ sơ trên trang web DVCQG, điền khoảng ngày, nhấn Tìm kiếm và duyệt toàn bộ các trang kết quả (tối đa 20 trang).
     - Tự động bóc tách mã hồ sơ từ từng dòng bảng, deduplicate theo từng mã và trạng thái, gom toàn bộ các khối XML của tất cả các hồ sơ tìm được và tự động chuyển sang trang Rà soát!
   - **Nút "🗑️ Xóa" tiện ích**: Xóa trắng toàn bộ danh sách mã hồ sơ đã nhập, đồng thời tự động xóa sạch luôn dữ liệu tại ô "Mã hồ sơ" trên trang web DVCQG chỉ với 1 click, đưa hệ thống vào trạng thái sẵn sàng cho chế độ `(Quét toàn bộ theo ngày)`.
   - Hỗ trợ nhập danh sách nhiều mã hồ sơ chạy liên tục (Batch mode) với thanh tiến trình và nút Dừng an toàn.

2. **Chế độ thông minh tương thích tốc độ tải (Smart Adaptive Loading Engine)**:
   - **Khắc phục triệt để lỗi dữ liệu chưa tải kịp tốc độ lấy dữ liệu**: DVCQG là hệ thống dùng chung có độ trễ mạng biến thiên lớn (lúc phản hồi nhanh dưới 1s, lúc lag 3-5s). Cơ chế mới thay thế việc chờ cố định bằng bộ động cơ tự thích ứng theo thời gian thực:
     - **Theo dõi yêu cầu mạng In-Flight**: Interceptor theo dõi trực tiếp số lượng request XHR & Fetch đang xử lý (`activeRequestsCount`).
     - **Nhận diện trạng thái Spinner & Overlay**: Tự động phát hiện các spinner quay của Ant Design (`.ant-spin-spinning`, `.ant-spin-nested-loading`), Bootstrap loading, nút tìm kiếm đang bận và placeholder "Đang tải dữ liệu...".
     - **Chụp Snapshot và so sánh dữ liệu**: Chụp fingerprint của bảng dữ liệu trước khi bấm tìm kiếm hoặc chuyển trang. Đảm bảo bảng dữ liệu đã nạp xong bản ghi mới và giữ trạng thái ổn định DOM trước khi bóc tách (chống đọc nhầm bảng cũ của hồ sơ trước).
     - **Co giãn độ trễ đệm thông minh (Adaptive Buffer)**: Khi phát hiện máy chủ DVCQG phản hồi chậm, hệ thống tự động co giãn độ trễ đệm (tự động đợi thêm cho đến khi nạp 100% dữ liệu) và ghi nhật ký cảnh báo trực quan; khi mạng nhanh thì tự động tối ưu để chạy mượt mà.
     - **Áp dụng toàn diện cho cả Chi tiết Modal & Phân trang**: Chờ gói tin Request Body nạp xong 100% vào modal trước khi đọc, tuyệt đối không bị bỏ sót khối XML do modal chưa kịp nạp dữ liệu.
     - **3 cấu hình tốc độ linh hoạt**: Hỗ trợ lựa chọn giữa `⚡ Tự thích ứng (Khuyên dùng)`, `🐢 Chờ an toàn (Mạng chậm/Lag)` và `🚀 Tốc độ cao`.

3. **Nâng cấp toàn bộ các bước lấy vừa trạng thái BN hoặc DVC & Phân trang thông minh**:
   - **Hỗ trợ đồng thời cả 2 kênh Bộ/Ngành (BN) và Cổng DVCQG (DVC) cho toàn bộ 9 bước nghiệp vụ**:
     - `1. KhoiTaoHoSo (BN/DVC)`: Bắt buộc đầu tiên, tự động nhận diện cả `KhoiTaoHoSoBN` và `KhoiTaoHoSoDVC`.
     - `2. TiepNhanHoSo (BN/DVC)`: Tự động nhận diện cả `TiepNhanHoSoBN` và `TiepNhanHoSoDVC`.
     - `2b. BoSungHoSo (BN/DVC)`: Bổ sung hồ sơ / Yêu cầu bổ sung, nhận diện cả `BoSungHoSoDVC`, `BoSungHoSoBN`, `YeuCauBoSungHoSoBN`, `YeuCauBoSungHoSoDVC`.
     - `3. CapNhatTienTrinh (BN/DVC)`: Nhận diện cả `CapNhatTienTrinhXuLyHoSoBN` và `CapNhatTienTrinhXuLyHoSoDVC`.
     - `4. GiaHanXuLy (BN/DVC)`: Nhận diện cả `GiaHanXuLyHoSoBN` và `GiaHanXuLyHoSoDVC`.
     - `5. TaoYeuCauTaiChinh (BN/DVC)`: Nhận diện cả `TaoYeuCauThucHienNghiaVuTaiChinhBN` và `TaoYeuCauThucHienNghiaVuTaiChinhDVC`.
     - `6. HuyYeuCauTaiChinh (BN/DVC)`: Nhận diện cả `HuyYeuCauThucHienNghiaVuTaiChinhBN` và `HuyYeuCauThucHienNghiaVuTaiChinhDVC`.
     - `7. ThanhToan (BN/DVC)`: Đồng bộ thanh toán, thu thập trọn vẹn cả `DongBoThongTinThanhToanBN`, `DongBoThongTinThanhToanDVC` và `DongBoThongTinThanhToan`.
     - `8. TraKetQua (BN/DVC)`: Nhận diện cả `TraKetQuaBN` và `TraKetQuaDVC`.
   - **Hiển thị thông minh chi tiết nguồn trạng thái trên Step Tracker**:
     - Khi hồ sơ có cả bản ghi BN và DVC: hiển thị `(BN + DVC: N)`.
     - Khi hồ sơ chỉ có bản ghi DVC: hiển thị `(DVC: N)`.
     - Khi hồ sơ chỉ có bản ghi BN: hiển thị `(BN: N)`.
   - **Cơ chế khử trùng lặp theo nhóm bước (Group Deduplication)**: Tự động gom cụm các biến thể BN và DVC về cùng một nhóm bước nghiệp vụ. Khi bật "Tránh lấy lặp lại khối trạng thái giống nhau", tiện ích tự động đảm bảo mỗi nhóm bước nghiệp vụ chỉ lấy 1 khối XML chuẩn duy nhất (ngoại trừ thanh toán cho phép nhiều đợt nộp phí khác nhau).
   - **Cơ chế quét hàng từ dưới lên (Bottom-up)**: Bảng tra cứu trên Cổng DVCQG hiển thị trạng thái mới nhất ở trên cùng và cũ nhất ở dưới cùng. Tiện ích tự động quét các hàng từ dưới lên (`hàng N ➜ hàng 1`), giúp tìm thấy và thu thập ngay khối bắt buộc `KhoiTaoHoSo` đầu tiên, sau đó tuần tự thu thập các bước tiếp theo theo đúng tiến trình xử lý tự nhiên.
   - **Tất cả các hồ sơ kiểm tra BẮT BUỘC phải có giá trị Khởi tạo (`KhoiTaoHoSoBN` hoặc `KhoiTaoHoSoDVC`) đầu tiên**: Hệ thống đặt bước Khởi tạo làm điều kiện tiên quyết và luôn sắp xếp đứng đầu tiên trong khối XML đồng bộ. Chỉ công nhận hoàn tất chu kỳ khi đã có bước khởi đầu bắt buộc kết hợp với `TraKetQua (BN/DVC)` (hoặc đủ các bước). Tuyệt đối không dừng sớm khi chưa có khối khởi tạo!
   - **Cho phép qua tối đa 3 trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp (bảo vệ trọn vẹn khối Khởi tạo)**: Tự động nhận diện chính xác nút **Trang sau** (`<button class="ant-btn ..."><span class="hidden lg:inline">Trang sau</span></button>`) của Ant Design v5 / DVCQG. Khi trang hiện tại chưa thu thập đủ trạng thái cần thiết (đặc biệt là `KhoiTaoHoSo (BN/DVC)` hoặc `TraKetQua (BN/DVC)`), hệ thống tự động click chuyển sang trang sau (duyệt tối đa 3 trang), đợi tải bảng trang mới an toàn rồi quét tiếp, giúp không bao giờ bị sót khối Khởi tạo nằm ở các trang sau! Nếu sau tối đa 3 trang vẫn chưa đủ, hệ thống sẽ kết thúc đợt và chuyển sang trạng thái/đợt thời gian tiếp theo một cách an toàn.
   - Tự động lọc các bản ghi có trạng thái **COMPLETED** hoặc **SUCCESS** (đặc biệt hỗ trợ thu thập khối `DongBoThongTinThanhToanDVC` với trạng thái **SUCCESS**, bỏ qua FAILED, ERROR, PENDING,...).
   - **Tự động kiểm tra và ưu tiên thu thập `DongBoThongTinThanhToan` khi hồ sơ có Yêu cầu tài chính**:
     - Khi hồ sơ xuất hiện trạng thái Yêu cầu thực hiện nghĩa vụ tài chính (`TaoYeuCauThucHienNghiaVuTaiChinh`) và chưa bị hủy (`HuyYeuCauThucHienNghiaVuTaiChinh`), hệ thống tự động xác định bước Thanh toán là BẮT BUỘC.
     - Tự động tiếp tục rà quét phân trang hoặc các đợt/tháng tiếp theo để lấy bằng được khối `DongBoThongTinThanhToan` trước khi công nhận hoàn tất chu kỳ, tuyệt đối không kết thúc sớm.
     - Tự động đối chiếu và cảnh báo trực quan trước khi chuyển gói tin sang trang Rà soát.
   - **Hiển thị số step đã thực hiện (Step Tracker)**:
     - Widget theo dõi tiến trình trực quan hiển thị ngay trên bảng điều khiển nổi.
     - Đèn trạng thái chuyển xanh `✓` cho từng bước đã lấy thành công.
     - Badge thông báo tiến độ trực quan: `Đã thực hiện: X/8 steps`.
   - **Chống lấy lặp trạng thái (Deduplication)**: Mỗi nhóm trạng thái chỉ lấy duy nhất 1 khối XML chuẩn cho mỗi mã hồ sơ. Tự động bỏ qua các dòng trùng lặp (không tốn thời gian mở modal) và loại bỏ các khối XML trùng nội dung.
   - **Bộ lọc và thu thập Khối thông tin dữ liệu XML nghiêm ngặt (Tối ưu nhận cả 2 định dạng `UTF-8` và `utf-8`)**: Tự động nhận diện và trích xuất đúng khối `<?xml version="1.0" encoding="UTF-8"?>` hoặc `<?xml version="1.0" encoding="utf-8"?>` kết hợp `<Envelope xmlns="http://dichvucong.gov.vn/api/v1">...</Envelope>` hoặc `<Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">...</Envelope>` tại tab **Khối thông tin dữ liệu** / **Thông tin dữ liệu** / **Request Body** của từng trạng thái (loại bỏ hoàn toàn vỏ bọc SOAP ngoài cùng, HTML/JSON wrapper và các thẻ không liên quan):
     - Cơ chế 1: **Network Interceptor** - Tự động bắt gói tin trực tiếp từ API mạng (tốc độ cao, linh hoạt nhận diện cả `UTF-8` lẫn `utf-8`).
     - Cơ chế 2: **DOM Scanner & Modal Trigger** - Tự động click xem chi tiết từng dòng từ dưới lên, tự động chuyển sang tab **Khối thông tin dữ liệu**, đọc nội dung XML chuẩn hóa bảo toàn khai báo `<?xml version="1.0" encoding="UTF-8"?>` hoặc `<?xml version="1.0" encoding="utf-8"?>` và đóng modal tuần tự.
   - **Bảo toàn 100% thực thể XML `&amp;` theo chuẩn W3C (Đầy đủ dữ liệu gốc ban đầu)**: Khắc phục triệt để lỗi khi lấy khối dữ liệu XML có chứa `&amp;` bị giải mã nhầm thành `&` trần. Cơ chế bóc tách an toàn `safeDecodeXmlTags` và `restoreXmlAmpersands` bảo toàn nguyên vẹn 100% các ký tự `&amp;` của dữ liệu gốc ban đầu (tên cơ quan, thủ tục, họ tên, địa chỉ,...), đồng thời tự động chuẩn hóa bất kỳ ký tự `&` trần nào thành `&amp;` hợp lệ, triệt tiêu hoàn toàn lỗi cú pháp XML `not well-formed` khi phân tích.
   - Tự động sắp xếp các khối XML theo đúng tiến trình xử lý chuẩn (Khởi tạo -> Tiếp nhận -> Tiến trình -> Gia hạn -> Y/c tài chính -> Thanh toán -> Trả kết quả) và ghép thành chuỗi XML liên tiếp.

4. **Tự động Paste dữ liệu vào Form & Kích hoạt Rà soát (Hỗ trợ URL Dự phòng & Tùy chọn trang rà soát)**:
   - **Tùy chọn trang Rà soát mục tiêu linh hoạt**:
     - **Máy chủ chính**: `https://cdn.dnncloud.net/tthc/rasoat.html`
     - **Máy chủ dự phòng (Gia Lai)**: `https://hcc.gialai.gov.vn/tools/rasoat.html`
     - **Tùy chỉnh URL**: Cho phép người dùng tự nhập bất kỳ URL công cụ rà soát nào theo nhu cầu.
     - **Chuyển đổi 1-click**: Dễ dàng lựa chọn giữa máy chủ chính và dự phòng trực tiếp trên **Bảng điều khiển nổi** hoặc trong **Popup tiện ích**. Cài đặt được lưu tự động và đồng bộ xuyên suốt.
   - **Tự động xóa dữ liệu cũ trước khi phân tích**: Dọn sạch hoàn toàn văn bản XML cũ trong `#src`, ngày báo cáo cũ và ẩn kết quả phân tích cũ trước khi dán dữ liệu mới, đảm bảo kết quả phân tích độc lập và chính xác 100%.
   - **Tự động Paste vào form `#src`**: Sử dụng setter nguyên bản cùng hệ thống sự kiện `input`, `change`, `paste` và `ClipboardEvent` đảm bảo dữ liệu XML luôn được nạp đầy đủ vào form 100%.
   - **Tự động đồng bộ Clipboard**: Tự động sao chép XML vào Clipboard máy tính để bạn có thể dán ở bất cứ đâu.
   - **Nút tiện ích "📋 Tự động dán XML gần nhất"**: Nằm ở góc trái màn hình trang rà soát, cho phép tự động dán lại gói tin XML gần nhất bất kỳ lúc nào chỉ với 1 click (hoạt động đồng thời trên cả máy chủ chính và máy chủ dự phòng Gia Lai).
   - **Tự động điền kỳ báo cáo**: Nạp chính xác Từ ngày `#pf` và Đến ngày `#pt`.
   - **Tự động phân tích**: Kích hoạt nút **Phân tích** (`#go`), có cơ chế tự động kiểm tra và retry nếu trang web tải chậm.

5. **Bảng điều khiển nổi thông minh (Floating Widget) & Hiển thị Live Tiến trình theo thời gian thực**:
   - Hiển thị trực tiếp ở góc dưới bên phải trang Quản trị DVCQG.
   - **Cập nhật Live Tiến trình tức thì (Real-time Live Progress)**: Không đợi thu thập toàn bộ xong mới hiển thị!
     - Các chip trạng thái nghiệp vụ (`1. Khởi tạo`, `2. Tiếp nhận`...) tự động chuyển màu xanh `✓ HOÀN THÀNH` ngay khi trích xuất thành công từng khối XML trên từng dòng bảng.
     - Thanh tiến trình (Progress bar) và phần trăm `%` hoàn thành cập nhật mượt mà theo từng dòng và từng bước nghiệp vụ đang duyệt.
     - Bộ đếm số khối XML (`dvcqg-extracted-count`) nhảy số live thời gian thực.
     - Cập nhật bộ nhớ đệm liên tục: Có thể nhấn "📋 Xem XML" hoặc "⏹ Dừng" bất kỳ lúc nào để xem/dùng ngay các khối đã trích xuất được mà không bị thất lạc dữ liệu.
   - Bảng theo dõi Step tracker trực quan thời gian thực.
   - Có thể thu nhỏ thành nút nổi tròn hoặc mở rộng.
   - Cửa sổ nhật ký (Live Log) thông báo tiến trình từng bước theo thời gian thực.
   - Cung cấp nút xem trước toàn bộ XML và sao chép vào Clipboard.

---

## 🚀 Hướng dẫn cài đặt vào Google Chrome

### Cách 1: Cài đặt từ thư mục dự án (Developer Mode)
1. Mở trình duyệt **Google Chrome**.
2. Truy cập vào trang quản lý tiện ích:
   ```text
   chrome://extensions/
   ```
3. Bật công tắc **Chế độ dành cho nhà phát triển (Developer mode)** ở góc trên bên phải màn hình.
4. Nhấn vào nút **Tải tiện ích đã giải nén (Load unpacked)** ở góc trên bên trái.
5. Chọn thư mục dự án:
   ```text
   /Volumes/DỮ LIỆU QUAN TRỌNG/WorkSpace/Check HS auto
   ```
6. Tiện ích **DVCQG Auto Sync & Review** sẽ xuất hiện trên danh sách tiện ích của Chrome kèm icon đầy đủ. Bạn nên ghim (Pin) icon tiện ích lên thanh công cụ của Chrome để tiện theo dõi.

### Cách 2: Cài đặt từ gói ZIP đóng gói sẵn (Dành cho máy khác/triển khai nhanh)
1. Sử dụng gói tệp tin đã đóng gói sẵn:
   ```text
   Auto-Check-DVCQG-v2.3.3.zip
   ```
2. Giải nén file `.zip` vào một thư mục trên máy tính.
3. Truy cập `chrome://extensions/` ➜ Bật **Developer mode** ➜ Bấm **Load unpacked** và chọn thư mục vừa giải nén.
4. Có thể chạy lại lệnh `node generate-assets.js` bất kỳ lúc nào để tự động cập nhật icon và tạo gói ZIP mới nhất.

---

## 📖 Hướng dẫn sử dụng

### Cách 1: Chạy tự động hàng loạt (Batch Auto Flow)

1. Đăng nhập vào trang:
   `https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo`
2. Ở góc phải màn hình, bảng điều khiển **Auto Check DVCQG** sẽ tự động hiển thị:
   - **Danh sách mã hồ sơ**: Dán danh sách các mã hồ sơ cần kiểm tra (mỗi dòng 1 mã, hoặc ngăn cách bằng dấu phẩy). Hỗ trợ dán trực tiếp từ bảng Excel/Web – hệ thống tự động bóc tách mã hồ sơ hợp lệ, loại bỏ các cột rác (STT, ngày tháng, trạng thái). Đồng thời ô **Từ ngày** tự động chọn ngày sinh của mã hồ sơ!
   - **Thời gian tra cứu**: Bấm nút **📅 Theo mã HS** để tự động đặt lại Từ ngày theo mã và Đến ngày tối đa trong tháng. Giữ bật tùy chọn **🧠 Tra cứu thông minh** để hệ thống tự động tìm kiếm từng tháng và tự động chuyển sang tháng tiếp theo nếu còn thiếu trạng thái kết thúc `TraKetQuaBN`.
   - **Theo dõi tiến trình**: Bảng **TIẾN TRÌNH (KHỞI TẠO ➜ TRẢ KẾT QUẢ)** hiển thị trực quan trạng thái **✓ HOÀN THÀNH** cho từng bước nghiệp vụ (`1. Khởi tạo` ➜ `8. Trả kết quả`), số lượng bản ghi tương ứng, thanh mini progress bar và huy hiệu `8/8 steps (HOÀN THÀNH 100%)`.
3. Nhấn nút **⚡ CHẠY TỰ ĐỘNG**.
4. Tiện ích sẽ tự động thực hiện:
   - Điền mã hồ sơ (hoặc quét toàn bộ các hồ sơ nếu để trống mã), điền Từ ngày - Đến ngày vào form tra cứu của DVCQG (hỗ trợ đầy đủ Ant Design / NG-ZORRO / Angular DatePicker).
   - Thanh tiến trình hiển thị: `Hồ sơ X/N (YY%) • X/8 steps [HOÀN THÀNH ✓]`.
   - Sau khi hoàn tất kiểm tra, tiện ích tổng hợp tất cả các khối XML đã trích xuất, chuyển tab sang `rasoat.html` -> Tự động paste an toàn vào ô `#src` -> Tự động kích hoạt Phân tích!

### Cách 2: Trích xuất nhanh từ bảng kết quả đang mở (Manual Search)

1. Nếu bạn đã tự tìm kiếm thủ công trên trang DVCQG và danh sách kết quả đang hiển thị:
2. Nhấn nút **⚡ Trích xuất bảng hiện tại** trên bảng điều khiển nổi.
3. Tiện ích sẽ quét ngay bảng hiện tại, cập nhật bảng step tracker và chuyển sang trang Rà soát.

### Cách 3: Xem trước & Sao chép dữ liệu XML

- Nhấn nút **📋 Xem XML** để mở cửa sổ xem trước toàn bộ các khối XML đã ghép.
- Nhấn **Sao chép** để copy vào bộ nhớ đệm hoặc nhấn **Gửi sang Rà soát** khi cần.

---

## 🛠 Cấu trúc thư mục tiện ích

```text
Auto Click/
├── manifest.json                  # Cấu hình Manifest V3 của Extension
├── background/
│   └── background.js              # Service Worker điều phối tab và dữ liệu rà soát
├── content-scripts/
│   ├── dvcqg-injected.js          # Script can thiệp mạng XHR/Fetch bắt gói tin XML
│   ├── dvcqg-content.js           # Content Script trang DVCQG (Bảng điều khiển & quét DOM)
│   ├── dvcqg-content.css          # Giao diện Bảng điều khiển nổi & Step Tracker
│   ├── rasoat-content.js          # Content Script trang Rà soát (Nhận XML & bấm Phân tích)
│   └── rasoat-content.css         # Thông báo Toast trên trang Rà soát
├── popup/
│   ├── popup.html                 # Giao diện khi bấm vào icon Extension trên thanh công cụ
│   ├── popup.css                  # Style giao diện Popup
│   └── popup.js                   # Xử lý sự kiện Popup
└── README.md                      # Tài liệu hướng dẫn sử dụng
```

---

## 💡 Lưu ý quan trọng
- Tiện ích tuân thủ đầy đủ tiêu chuẩn **Manifest V3** bảo mật cao nhất của Google Chrome.
- Nếu trang DVCQG có thời gian tải lâu do mạng, script đã tích hợp cơ chế chờ linh hoạt và console nhật ký chi tiết để bạn dễ dàng theo dõi trạng thái.

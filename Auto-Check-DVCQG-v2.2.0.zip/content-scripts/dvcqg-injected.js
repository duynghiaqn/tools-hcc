// dvcqg-injected.js - Injected into the page's main execution context to intercept XHR & Fetch requests
(function () {
  console.log('[DVCQG Auto] Injected script initialized to monitor sync data.');

  const syncCache = {
    records: [],
    details: {}
  };

  // Helper to safely parse JSON
  function tryParseJson(text) {
    try {
      return JSON.parse(text);
    } catch (e) {
      return null;
    }
  }

  // Helper to extract XML or sync info from response
  function processResponse(url, data) {
    if (!data) return;

    // Check if data is string containing DVCQG Envelope (either dichvucong.gov.vn/api/v1 or XMLSchema)
    if (
      typeof data === 'string' &&
      data.includes('<Envelope') &&
      (data.includes('http://dichvucong.gov.vn/api/v1') ||
       data.includes('http://www.w3.org/2001/XMLSchema') ||
       data.includes('https://www.w3.org/2001/XMLSchema'))
    ) {
      window.postMessage({
        type: 'DVCQG_CAPTURED_XML',
        url: url,
        xml: data
      }, '*');
      return;
    }

    // Check if data is object with sync records or details
    const json = typeof data === 'object' ? data : tryParseJson(data);
    if (!json) return;

    // Notify content script of captured network response
    window.postMessage({
      type: 'DVCQG_NETWORK_RESPONSE',
      url: url,
      data: json
    }, '*');
  }

  // 1. Hook XMLHttpRequest
  const originalXhrOpen = XMLHttpRequest.prototype.open;
  const originalXhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._dvcqg_url = url;
    this._dvcqg_method = method;
    return originalXhrOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function (body) {
    this.addEventListener('load', function () {
      try {
        if (this.responseType === '' || this.responseType === 'text') {
          processResponse(this._dvcqg_url, this.responseText);
        } else if (this.responseType === 'json') {
          processResponse(this._dvcqg_url, this.response);
        }
      } catch (err) {
        console.debug('[DVCQG Auto] XHR error:', err);
      }
    });
    return originalXhrSend.apply(this, arguments);
  };

  // 2. Hook window.fetch
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const response = await originalFetch.apply(this, args);
    const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';

    try {
      const clone = response.clone();
      clone.text().then(text => {
        processResponse(url, text);
      }).catch(() => {});
    } catch (e) {}

    return response;
  };
})();

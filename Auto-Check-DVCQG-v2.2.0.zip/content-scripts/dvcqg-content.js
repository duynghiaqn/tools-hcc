// dvcqg-content.js - Content script for https://quantricong.dichvucong.gov.vn/*
(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__DVCQG_AUTO_INITIALIZED__) return;
  window.__DVCQG_AUTO_INITIALIZED__ = true;

  console.log('[DVCQG Auto] Content script loaded on', window.location.href);

  // In-memory state
  const state = {
    isRunning: false,
    isStopping: false,
    extractedXmlBlocks: [], // Array of { status, xml, timestamp, maHoSo }
    capturedNetworkXml: [], // Captured via injected script
    lastExtractedCombined: '',
    config: {
      maHoSoListText: '', // Multi-line list of application codes
      fromDate: '',
      toDate: '',
      autoTransfer: true,
      onlyCompleted: true, // Only extract records with status COMPLETED
      smartDateSearch: true, // Automatically parse filing date from code and expand months until TraKetQuaBN
      searchDepthMonths: 3, // Độ sâu rà soát tối đa các tháng sau đó (mặc định 3 tháng)
      deduplicateStatus: true, // Tránh lấy lặp lại nhiều khối trạng thái giống nhau (mỗi trạng thái chỉ lấy 1 khối duy nhất)
      maxPagesPerSearch: 3, // Cho phép qua tối đa 3 trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp
      selectedStatuses: {
        KhoiTaoHoSoBN: true, // BẮT BUỘC ĐẦU TIÊN CHO TẤT CẢ HỒ SƠ
        TiepNhanHoSoBN: true,
        CapNhatTienTrinhXuLyHoSoBN: true,
        TaoYeuCauThucHienNghiaVuTaiChinhBN: true,
        DongBoThongTinThanhToanBN: true,
        TraKetQuaBN: true
      }
    }
  };

  // Helper to parse multiple application codes from text, handling table pastes (Excel/Web) cleanly
  function parseMaHoSoList(rawText) {
    if (!rawText || typeof rawText !== 'string') return [];
    const lines = rawText.split(/[\r\n]+/);
    const resultCodes = [];

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      // Handle table columns separated by tab, comma, semicolon or multiple spaces
      const tokens = line.split(/[\t,;]+/).map(t => t.trim()).filter(Boolean);

      let found = false;
      for (const token of tokens) {
        // Strip common prefix/suffix like #, bullets, quotes, leading number bullet like "1. "
        const clean = token.replace(/^[#*\-•\d.]+\s*/, '').replace(/["']/g, '').trim();

        // Skip non-codes: pure small numbers (STT), date strings, statuses, XML tags
        if (/^\d{1,4}$/.test(clean)) continue;
        if (/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(clean)) continue;
        if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) continue;
        if (/^(COMPLETED|PENDING|FAILED|ERROR|SUCCESS|HOAN_THANH|DANG_XU_LY)$/i.test(clean)) continue;
        if (/^(KhoiTaoHoSoBN|TiepNhanHoSoBN|CapNhatTienTrinhXuLyHoSoBN|TaoYeuCauThucHienNghiaVuTaiChinhBN|DongBoThongTinThanhToanBN|TraKetQuaBN)$/i.test(clean)) continue;

        // An application code in DVCQG is alphanumeric with hyphens/dots and at least 6 characters
        if (clean.length >= 6 && (clean.includes('-') || clean.includes('.') || /\d{6}/.test(clean))) {
          resultCodes.push(clean);
          found = true;
          break; // Take the primary application code from this table row
        }
      }

      // Fallback if line wasn't split by table delimiters but has a valid code
      if (!found && tokens.length === 1) {
        const cleanSingle = line.replace(/^[#*\-•]+\s*/, '').trim();
        if (cleanSingle.length >= 5) {
          resultCodes.push(cleanSingle);
        }
      }
    }

    // Deduplicate while preserving original order
    return Array.from(new Set(resultCodes));
  }

  // Parse filing date from application code: e.g. H21.117-260812-0008 -> 12/08/2026 (YYMMDD: 26=2026, 08=tháng 8, 12=ngày 12)
  function parseDateFromMaHoSo(maHoSo) {
    if (!maHoSo || typeof maHoSo !== 'string') return null;
    const clean = maHoSo.trim();

    // Pattern 1: Delimited segment with 6 digits (YYMMDD) or 8 digits (YYYYMMDD)
    // Delimiters can be hyphen, dot, slash, underscore, or whitespace
    // Examples: -260812-, -20260812-, .260812., /260812/, - 260812 -
    const delimitedRegex = /(?:^|[-_./\s])(\d{2}|\d{4})(\d{2})(\d{2})(?=[-_./\s]|$)/g;
    let match;
    const candidates = [];

    while ((match = delimitedRegex.exec(clean)) !== null) {
      const rawYear = parseInt(match[1], 10);
      const mm = parseInt(match[2], 10);
      const dd = parseInt(match[3], 10);

      // Validate month (1-12) and day (1-31)
      if (mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31) {
        let year = rawYear;
        if (rawYear < 100) {
          // 2-digit year: 20xx for 00..49, 19xx for 50..99
          year = rawYear >= 50 ? 1900 + rawYear : 2000 + rawYear;
        }
        // Score: high priority for modern DVCQG filing years (2018 - 2035)
        const isLikelyYear = year >= 2018 && year <= 2035;
        candidates.push({
          date: new Date(year, mm - 1, dd),
          year, mm, dd,
          score: isLikelyYear ? 100 : 40,
          index: match.index
        });
      }
    }

    if (candidates.length > 0) {
      // Sort by score descending; if equal, choose the one with higher index (towards end of code)
      candidates.sort((a, b) => (b.score - a.score) || (b.index - a.index));
      return candidates[0].date;
    }

    // Pattern 2: Any 6 consecutive digits with valid MM (1-12) and DD (1-31)
    const sixDigitRegex = /(?:^|[^\d])(\d{2})(\d{2})(\d{2})(?=[^\d]|$)/g;
    while ((match = sixDigitRegex.exec(clean)) !== null) {
      const rawYear = parseInt(match[1], 10);
      const mm = parseInt(match[2], 10);
      const dd = parseInt(match[3], 10);
      if (mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31) {
        const year = rawYear >= 50 ? 1900 + rawYear : 2000 + rawYear;
        if (year >= 2018 && year <= 2035) {
          return new Date(year, mm - 1, dd);
        }
      }
    }

    return null;
  }

  // Step definitions: Các bước nghiệp vụ từ Khởi tạo đến Trả kết quả (KhoiTaoHoSoBN là bắt buộc đầu tiên)
  const STEP_DEFINITIONS = [
    { key: 'KhoiTaoHoSoBN', label: '1. Khởi tạo (Bắt buộc)' },
    { key: 'TiepNhanHoSoBN', label: '2. Tiếp nhận' },
    { key: 'CapNhatTienTrinhXuLyHoSoBN', label: '3. Tiến trình' },
    { key: 'TaoYeuCauThucHienNghiaVuTaiChinhBN', label: '4. Tài chính' },
    { key: 'DongBoThongTinThanhToanBN', label: '5. Thanh toán' },
    { key: 'TraKetQuaBN', label: '6. Trả kết quả' }
  ];

  // Cập nhật giao diện theo dõi số bước (step) đã thực hiện & hiển thị trạng thái hoàn thành chi tiết
  function updateStepTracker(records = []) {
    const statusCounts = {};
    (records || []).forEach(r => {
      if (r && r.status) {
        statusCounts[r.status] = (statusCounts[r.status] || 0) + 1;
      }
    });

    let completedCount = 0;

    STEP_DEFINITIONS.forEach(step => {
      const count = statusCounts[step.key] || 0;
      const isDone = count > 0;
      if (isDone) completedCount++;

      // 1. Cập nhật chip hiển thị trên bảng tiến trình step
      const chip = document.getElementById(`chip-${step.key}`);
      if (chip) {
        if (isDone) {
          chip.classList.add('completed');
          chip.classList.remove('pending');
          chip.innerHTML = `
            <span class="step-chip-name">${step.label}</span>
            <span class="step-chip-status done">✓ HOÀN THÀNH${count > 1 ? ` (${count})` : ''}</span>
          `;
          chip.title = `${step.label}: ĐÃ HOÀN THÀNH (Trích xuất thành công ${count} khối XML)`;
        } else {
          chip.classList.remove('completed');
          chip.classList.add('pending');
          chip.innerHTML = `
            <span class="step-chip-name">${step.label}</span>
            <span class="step-chip-status wait">Chờ quét</span>
          `;
          chip.title = `${step.label}: Chưa có khối COMPLETED nào`;
        }
      }

      // 2. Cập nhật thẻ trạng thái bên cạnh danh mục checkbox
      const listBadge = document.getElementById(`badge-st-${step.key}`);
      if (listBadge) {
        if (isDone) {
          listBadge.className = 'dvcqg-step-state-tag done';
          listBadge.textContent = `✓ Đã lấy${count > 1 ? ` (${count})` : ''}`;
        } else {
          listBadge.className = 'dvcqg-step-state-tag wait';
          listBadge.textContent = 'Chờ quét';
        }
      }
    });

    // 3. Cập nhật thanh tiến trình mini & huy hiệu tổng thể
    const badge = document.getElementById('dvcqg-step-counter-badge');
    const miniFill = document.getElementById('dvcqg-step-mini-fill');
    const pct = Math.round((completedCount / STEP_DEFINITIONS.length) * 100);

    if (miniFill) {
      miniFill.style.width = `${pct}%`;
    }

    if (badge) {
      if (completedCount === STEP_DEFINITIONS.length) {
        badge.className = 'dvcqg-step-counter-badge all-completed';
        badge.innerHTML = `✓ ${completedCount}/${STEP_DEFINITIONS.length} steps (HOÀN THÀNH 100%)`;
      } else if (statusCounts['TraKetQuaBN'] > 0) {
        badge.className = 'dvcqg-step-counter-badge has-traketqua';
        badge.innerHTML = `✓ ${completedCount}/${STEP_DEFINITIONS.length} steps (ĐÃ TRẢ KẾT QUẢ)`;
      } else if (completedCount > 0) {
        badge.className = 'dvcqg-step-counter-badge in-progress';
        badge.textContent = `${completedCount}/${STEP_DEFINITIONS.length} steps (${pct}%)`;
      } else {
        badge.className = 'dvcqg-step-counter-badge';
        badge.textContent = `0/${STEP_DEFINITIONS.length} steps`;
      }
    }

    return completedCount;
  }

  // Tạo danh sách các khoảng thời gian tra cứu thông minh:
  // - Đợt 1: KhoiTaoHoSoBN - ngày bắt đầu và kết thúc lấy theo ngày hồ sơ
  // - Đợt 2: Quét thời gian tiếp theo trong tháng nộp hồ sơ (nếu chưa phải ngày cuối tháng)
  // - Các đợt tiếp theo: Chuyển qua các tháng khác (độ sâu tối đa do người dùng cài đặt, mặc định 3 tháng sau đó)
  function generateSmartDateRanges(filingDate, maxDepth = null) {
    const ranges = [];
    if (!filingDate || isNaN(filingDate.getTime())) return ranges;

    const depthLimit = Math.max(1, parseInt(maxDepth ?? state.config.searchDepthMonths ?? 3, 10));
    const now = new Date();
    const filingYmd = formatDateYMD(filingDate);
    const filingDmy = formatDateDMY(filingDate);

    // 1. Đợt 1: Với KhoiTaoHoSoBN, ngày bắt đầu và kết thúc lấy theo ngày hồ sơ
    ranges.push({
      from: filingYmd,
      to: filingYmd,
      stage: 'KhoiTaoHoSoBN',
      monthStr: `${pad(filingDate.getMonth() + 1)}/${filingDate.getFullYear()}`,
      label: `Đợt 1 (KhoiTaoHoSoBN): ${filingDmy} ➜ ${filingDmy} [Ngày hồ sơ]`
    });

    const filingYear = filingDate.getFullYear();
    const filingMonth = filingDate.getMonth(); // 0-indexed
    const filingDay = filingDate.getDate();
    const endOfFilingMonth = new Date(filingYear, filingMonth + 1, 0);

    // 2. Đợt 2: Quét thời gian tiếp theo trong tháng nộp hồ sơ (nếu chưa phải ngày cuối tháng)
    if (filingDay < endOfFilingMonth.getDate()) {
      const nextDay = new Date(filingYear, filingMonth, filingDay + 1);
      let toEndOfMonth = endOfFilingMonth;
      if (now.getFullYear() === filingYear && now.getMonth() === filingMonth && now < endOfFilingMonth) {
        toEndOfMonth = now;
      }
      ranges.push({
        from: formatDateYMD(nextDay),
        to: formatDateYMD(toEndOfMonth),
        monthStr: `${pad(filingMonth + 1)}/${filingYear}`,
        label: `Thời gian tiếp theo tháng ${pad(filingMonth + 1)}/${filingYear} (${formatDateDMY(nextDay)} ➜ ${formatDateDMY(toEndOfMonth)})`
      });
    }

    // 3. Các đợt tiếp theo: Chuyển qua các tháng khác (độ sâu tối đa do người dùng cài đặt, mặc định 3 tháng sau đó)
    // QUY TẮC BẮT BUỘC: Khi chuyển sang tháng khác, Từ ngày = 01 của tháng đó (ngày đầu tháng),
    // Đến ngày = ngày cuối tháng (hoặc ngày hiện tại nếu là tháng này).
    // TUYỆT ĐỐI KHÔNG GIỮ LẠI ngày bắt đầu hồ sơ vì khoảng thời gian sẽ vượt quá 1 tháng / lệch tháng và DVCQG không tìm thấy dữ liệu!
    // BẢO ĐẢM rà soát đủ số tháng theo cấu hình (depthLimit), không ngắt sớm để không bị kẹt lặp lại ngày cuối tháng nộp hồ sơ!
    const MAX_DEPTH_MONTHS = depthLimit;
    let curYear = filingYear;
    let curMonth = filingMonth + 1;
    if (curMonth > 11) {
      curMonth = 0;
      curYear++;
    }

    let monthDepth = 0;
    while (monthDepth < MAX_DEPTH_MONTHS) {
      monthDepth++;
      const monthStart = new Date(curYear, curMonth, 1); // BẮT BUỘC NGÀY ĐẦU THÁNG (01/MM/YYYY)
      const monthEnd = new Date(curYear, curMonth + 1, 0); // NGÀY CUỐI THÁNG

      let toD = monthEnd;
      const isCurrentMonth = (now.getFullYear() === curYear && now.getMonth() === curMonth);
      if (isCurrentMonth && now < monthEnd) {
        toD = now; // Hoặc ngày hiện tại nếu là tháng này và chưa hết tháng
      }

      ranges.push({
        from: formatDateYMD(monthStart), // BẮT BUỘC NGÀY ĐẦU THÁNG (01)
        to: formatDateYMD(toD),           // Ngày cuối tháng hoặc ngày hiện tại
        monthStr: `${pad(curMonth + 1)}/${curYear}`,
        monthDepth,
        label: `Tháng ${pad(curMonth + 1)}/${curYear} [Sau đó +${monthDepth}/${MAX_DEPTH_MONTHS}]: Từ ${formatDateDMY(monthStart)} (đầu tháng) ➜ ${formatDateDMY(toD)} (${isCurrentMonth && now < monthEnd ? 'hiện tại' : 'cuối tháng'})`
      });

      curMonth++;
      if (curMonth > 11) {
        curMonth = 0;
        curYear++;
      }
    }

    return ranges;
  }

  // 1. Inject Network Interceptor
  function injectNetworkScript() {
    try {
      const script = document.createElement('script');
      script.src = chrome.runtime.getURL('content-scripts/dvcqg-injected.js');
      script.onload = () => script.remove();
      (document.head || document.documentElement).appendChild(script);
      console.log('[DVCQG Auto] Injected network interceptor.');
    } catch (err) {
      console.warn('[DVCQG Auto] Could not inject network script:', err);
    }
  }
  injectNetworkScript();

  // Listen to messages from injected script
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;
    const { type, xml, data, url } = event.data;

    if (type === 'DVCQG_CAPTURED_XML' && xml) {
      if (typeof xml === 'string' && xml.includes('http://dichvucong.gov.vn/api/v1')) {
        const envs = extractDvcqgEnvelopes(xml);
        envs.forEach(envXml => {
          state.capturedNetworkXml.push({ url, xml: envXml, time: Date.now() });
        });
        if (envs.length > 0) {
          log(`Bắt được ${envs.length} khối Envelope từ mạng (${url || 'API'})`, 'info');
        }
      }
    }

    if (type === 'DVCQG_NETWORK_RESPONSE' && data) {
      scanNetworkDataForXml(data, url);
    }
  });

  // Recursive search for XML strings inside JSON API response
  function scanNetworkDataForXml(obj, url) {
    if (!obj || typeof obj !== 'object') return;
    for (const key of Object.keys(obj)) {
      const val = obj[key];
      if (typeof val === 'string' && val.includes('<Envelope') && val.includes('http://dichvucong.gov.vn/api/v1')) {
        const envs = extractDvcqgEnvelopes(val);
        envs.forEach(envXml => {
          state.capturedNetworkXml.push({ url, key, xml: envXml, time: Date.now() });
        });
      } else if (typeof val === 'object') {
        scanNetworkDataForXml(val, url);
      }
    }
  }

  // 2. UI Elements & Helper functions
  let rootEl = null;
  let logBoxEl = null;

  function pad(n) { return n < 10 ? '0' + n : String(n); }
  function formatDateYMD(d) {
    if (!d) return '';
    if (typeof d === 'string') {
      const clean = d.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(clean)) {
        const parts = clean.split('/');
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
      }
      d = new Date(clean);
    }
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  }

  function formatDateDMY(d) {
    if (!d) return '';
    if (typeof d === 'string') {
      const clean = d.trim();
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(clean)) return clean;
      if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
        const parts = clean.split('-');
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      d = new Date(clean);
    }
    if (!(d instanceof Date) || isNaN(d.getTime())) return '';
    return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
  }

  function log(msg, type = 'info') {
    console.log(`[DVCQG Auto] [${type}] ${msg}`);
    if (!logBoxEl) return;
    const now = new Date();
    const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    const div = document.createElement('div');
    div.className = `dvcqg-log-entry ${type}`;
    div.textContent = `[${timeStr}] ${msg}`;
    logBoxEl.appendChild(div);
    logBoxEl.scrollTop = logBoxEl.scrollHeight;
  }

  // Set input value cleanly triggering React/Angular/Vue change detection
  function setNativeValue(element, value) {
    if (!element) return;
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value')?.set;
    const prototype = Object.getPrototypeOf(element);
    const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

    if (prototypeValueSetter && valueSetter !== prototypeValueSetter) {
      prototypeValueSetter.call(element, value);
    } else if (valueSetter) {
      valueSetter.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Sleep utility
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // 3. Smart Element Locators on DVCQG Page
  function findMaHoSoInput() {
    const selectors = [
      'input[placeholder*="mã hồ sơ" i]',
      'input[placeholder*="hồ sơ" i]',
      'input[id*="mahoso" i]',
      'input[id*="ma_ho_so" i]',
      'input[name*="mahoso" i]',
      'input[name*="ma_ho_so" i]',
      'input[formcontrolname*="mahoso" i]',
      'input[formcontrolname*="maHoSo" i]',
      'input[ng-reflect-name*="mahoso" i]',
      'input[ng-reflect-name*="maHoSo" i]'
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.offsetParent !== null) return el;
    }

    // Try finding by label text
    const labels = Array.from(document.querySelectorAll('label, .ant-form-item-label, .control-label'));
    for (const lbl of labels) {
      if (lbl.textContent.toLowerCase().includes('mã hồ sơ')) {
        const id = lbl.getAttribute('for');
        if (id) {
          const el = document.getElementById(id);
          if (el) return el;
        }
        const input = lbl.parentElement?.querySelector('input') || lbl.nextElementSibling?.querySelector('input');
        if (input) return input;
      }
    }

    // Fallback: search-like input
    const generalInputs = document.querySelectorAll('input[type="text"]:not([readonly])');
    for (const inp of generalInputs) {
      if (inp.offsetParent !== null && !inp.closest('#dvcqg-auto-root')) return inp;
    }
    return null;
  }

  function findDateInputs() {
    let fromInput = null;
    let toInput = null;

    // 1. Check Ant Design / NG-ZORRO Range Picker
    const rangePicker = document.querySelector('.ant-picker-range, nz-range-picker, .daterangepicker');
    if (rangePicker && !rangePicker.closest('#dvcqg-auto-root')) {
      const rInputs = Array.from(rangePicker.querySelectorAll('input')).filter(el => !el.closest('#dvcqg-auto-root'));
      if (rInputs.length >= 2) {
        return { fromInput: rInputs[0], toInput: rInputs[1] };
      }
    }

    // 2. By specific attribute selectors (placeholder, formcontrolname, id, name)
    const fromSelectors = [
      'input[placeholder*="từ ngày" i]',
      'input[placeholder*="từ" i]',
      'input[formcontrolname*="tuNgay" i]',
      'input[formcontrolname*="from" i]',
      'input[formcontrolname*="startDate" i]',
      'input[formcontrolname*="ngayBatDau" i]',
      'input[ng-reflect-name*="tuNgay" i]',
      'input[ng-reflect-name*="from" i]',
      'input[id*="tungay" i]',
      'input[id*="tu_ngay" i]',
      'input[id*="from" i]',
      'input[name*="tungay" i]',
      'input[name*="tu_ngay" i]',
      'input[name*="from" i]'
    ];
    for (const sel of fromSelectors) {
      const el = document.querySelector(sel);
      if (el && !el.closest('#dvcqg-auto-root') && el.offsetParent !== null) {
        fromInput = el;
        break;
      }
    }

    const toSelectors = [
      'input[placeholder*="đến ngày" i]',
      'input[placeholder*="đến" i]',
      'input[formcontrolname*="denNgay" i]',
      'input[formcontrolname*="to" i]',
      'input[formcontrolname*="endDate" i]',
      'input[formcontrolname*="ngayKetThuc" i]',
      'input[ng-reflect-name*="denNgay" i]',
      'input[ng-reflect-name*="to" i]',
      'input[id*="denngay" i]',
      'input[id*="den_ngay" i]',
      'input[id*="to" i]',
      'input[name*="denngay" i]',
      'input[name*="den_ngay" i]',
      'input[name*="to" i]'
    ];
    for (const sel of toSelectors) {
      const el = document.querySelector(sel);
      if (el && !el.closest('#dvcqg-auto-root') && el.offsetParent !== null) {
        toInput = el;
        break;
      }
    }

    // 3. Try finding by surrounding form label text
    if (!fromInput || !toInput) {
      const labels = Array.from(document.querySelectorAll('label, .control-label, .ant-form-item-label'));
      for (const lbl of labels) {
        const txt = lbl.textContent.toLowerCase();
        if (txt.includes('từ ngày') && !fromInput) {
          const container = lbl.closest('.ant-form-item, nz-form-item, .form-group, .form-item, .row, .col, tr, div');
          const inp = container ? container.querySelector('input:not([type="hidden"])') : null;
          if (inp && !inp.closest('#dvcqg-auto-root')) fromInput = inp;
        }
        if (txt.includes('đến ngày') && !toInput) {
          const container = lbl.closest('.ant-form-item, nz-form-item, .form-group, .form-item, .row, .col, tr, div');
          const inp = container ? container.querySelector('input:not([type="hidden"])') : null;
          if (inp && !inp.closest('#dvcqg-auto-root')) toInput = inp;
        }
      }
    }

    // 4. Fallback: by date picker classes or dd/mm/yyyy placeholders
    if (!fromInput || !toInput) {
      const dateInputs = Array.from(document.querySelectorAll(
        '.ant-picker-input input, nz-date-picker input, .ant-picker input, .ant-calendar-picker-input, input[type="date"], input[placeholder*="dd/mm/yyyy" i], input[placeholder*="DD/MM/YYYY" i], input[placeholder*="dd/MM/yyyy" i]'
      )).filter(el => !el.closest('#dvcqg-auto-root') && el.offsetParent !== null);

      if (dateInputs.length >= 2) {
        if (!fromInput) fromInput = dateInputs[0];
        if (!toInput) toInput = dateInputs[1];
      } else if (dateInputs.length === 1 && !fromInput) {
        fromInput = dateInputs[0];
      }
    }

    return { fromInput, toInput };
  }

  // Xóa sạch giá trị ô ngày trên trang (Đặc biệt dùng xóa "Đến ngày" trước để "Từ ngày" chọn được tháng mới)
  async function clearPageDateInput(inputEl) {
    if (!inputEl) return false;
    try {
      const wasReadOnly = inputEl.readOnly;
      if (wasReadOnly) inputEl.readOnly = false;

      // 1. Nếu DatePicker có nút clear dạng icon (Ant Design / NG-ZORRO)
      const pickerContainer = inputEl.closest('.ant-picker, nz-date-picker, .ant-calendar-picker, .date-picker, .ant-picker-input');
      if (pickerContainer) {
        pickerContainer.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
        const clearBtns = pickerContainer.querySelectorAll('.ant-picker-clear, .ant-calendar-picker-clear, .anticon-close-circle, .bi-x-circle, [data-icon="close-circle"], nz-picker-clear, i.anticon-close');
        for (const btn of clearBtns) {
          try {
            btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            btn.click();
            btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          } catch (e) {}
        }
        await sleep(50);
      }

      // 2. Xóa native input (không dispatch blur khi rỗng vì blur sẽ kích hoạt ng-zorro hoàn tác ngày cũ)
      inputEl.focus();
      inputEl.select?.();

      const valueSetter = Object.getOwnPropertyDescriptor(inputEl, 'value')?.set;
      const prototypeValueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(inputEl), 'value')?.set;
      if (prototypeValueSetter && valueSetter !== prototypeValueSetter) {
        prototypeValueSetter.call(inputEl, '');
      } else if (valueSetter) {
        valueSetter.call(inputEl, '');
      } else {
        inputEl.value = '';
      }

      // Gửi phím Backspace / Delete
      const keyBack = { key: 'Backspace', code: 'Backspace', keyCode: 8, which: 8, bubbles: true, cancelable: true };
      inputEl.dispatchEvent(new KeyboardEvent('keydown', keyBack));
      inputEl.dispatchEvent(new KeyboardEvent('keyup', keyBack));

      await sleep(20);
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));

      if (wasReadOnly) inputEl.readOnly = true;
      return true;
    } catch (err) {
      console.warn('[DVCQG Auto] Error clearing date input:', err);
      return false;
    }
  }

  // Set date value into webpage input, properly committing Ant Design / NG-ZORRO / Angular models
  async function setPageDateValue(inputEl, dateVal) {
    if (!inputEl) return false;
    if (!dateVal) {
      return await clearPageDateInput(inputEl);
    }

    const ymd = formatDateYMD(dateVal);
    const dmy = formatDateDMY(dateVal);

    // Target format: standard on Vietnamese portals is DD/MM/YYYY unless type="date"
    let targetVal = dmy;
    if (inputEl.type === 'date') {
      targetVal = ymd;
    } else {
      const ph = (inputEl.getAttribute('placeholder') || '').toLowerCase();
      if (ph.includes('yyyy-mm-dd') || ph.includes('yyyy/mm/dd')) {
        targetVal = ymd;
      }
    }

    try {
      const wasReadOnly = inputEl.readOnly;
      if (wasReadOnly) inputEl.readOnly = false;

      inputEl.focus();
      inputEl.select?.();
      await sleep(20);

      // Set native value cleanly
      setNativeValue(inputEl, targetVal);

      // Dispatch Enter key events so Ant Design / NG-ZORRO DatePicker commits value into its reactive model
      const keyOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
      inputEl.dispatchEvent(new KeyboardEvent('keydown', keyOpts));
      inputEl.dispatchEvent(new KeyboardEvent('keypress', keyOpts));
      inputEl.dispatchEvent(new KeyboardEvent('keyup', keyOpts));

      await sleep(40);
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.dispatchEvent(new Event('blur', { bubbles: true }));

      if (wasReadOnly) inputEl.readOnly = true;
      return true;
    } catch (err) {
      console.warn('[DVCQG Auto] Error setting date input:', err);
      return false;
    }
  }

  // Điền bộ đôi Từ ngày & Đến ngày vào trang web một cách an toàn và thông minh
  // Tuyệt đối không để xảy ra xung đột "Từ ngày > Đến ngày" hoặc "Khoảng cách > 30 ngày"
  // làm trang web khóa/lặp ngày cuối tháng cũ!
  async function applyDateRangeToWebPage(fromYmd, toYmd) {
    const { fromInput, toInput } = findDateInputs();
    if (!fromInput && !toInput) {
      log('⚠️ Không tìm thấy ô nhập ngày trên trang web!', 'warn');
      return false;
    }

    const targetFromDmy = formatDateDMY(fromYmd);
    const targetToDmy = formatDateDMY(toYmd);

    const parseValDate = (val) => {
      if (!val) return null;
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(val)) {
        const [d, m, y] = val.split('/').map(Number);
        return new Date(y, m - 1, d);
      }
      if (/^\d{4}-\d{2}-\d{2}$/.test(val)) {
        const [y, m, d] = val.split('-').map(Number);
        return new Date(y, m - 1, d);
      }
      const dt = new Date(val);
      return isNaN(dt.getTime()) ? null : dt;
    };

    const targetFromDate = parseValDate(targetFromDmy);
    const targetToDate = parseValDate(targetToDmy);

    const curFromDate = fromInput ? parseValDate(fromInput.value) : null;
    const curToDate = toInput ? parseValDate(toInput.value) : null;

    // Kiểm tra xem có đang chuyển sang tháng mới trong tương lai hay không
    // (targetFromDate > curToDate: nếu điền Từ ngày trước sẽ bị lỗi Từ ngày > Đến ngày cũ dẫn đến kẹt ngày cuối tháng)
    const isMovingForward = targetFromDate && curToDate && targetFromDate.getTime() > curToDate.getTime();

    if (isMovingForward && toInput && fromInput) {
      log(`🔄 Chuyển tháng mới (${targetFromDmy} ➜ ${targetToDmy}): Áp dụng cơ chế bước đệm an toàn`, 'info');
      // BƯỚC ĐỆM 1: Thu hẹp khoảng cách cũ bằng cách chỉnh Từ ngày = Đến ngày hiện tại (ví dụ 31/08)
      await setPageDateValue(fromInput, curToDate);
      await sleep(100);

      // BƯỚC ĐỆM 2: Mở đường tháng mới: Đặt Đến ngày = targetFrom (ví dụ 01/09).
      // Khoảng cách giữa 01/09 và 31/08 chỉ là 1 ngày (Đến >= Từ, <= 30 ngày), hợp lệ 100%!
      await setPageDateValue(toInput, targetFromDate);
      await sleep(100);

      // BƯỚC ĐỆM 3: Đặt Từ ngày = targetFrom (ví dụ 01/09).
      // Cả hai cùng là 01/09, hợp lệ 100%!
      await setPageDateValue(fromInput, targetFromDate);
      await sleep(100);

      // BƯỚC ĐỆM 4: Mở rộng Đến ngày = targetTo (ví dụ 30/09).
      // Cùng trong tháng mới (<= 30 ngày), hợp lệ 100%!
      await setPageDateValue(toInput, targetToDate);
      await sleep(150);
    } else {
      // Trường hợp cùng tháng hoặc khởi tạo lần đầu:
      // Xóa Đến ngày trước nếu cần -> Điền Từ ngày -> Điền Đến ngày
      if (toInput) {
        await clearPageDateInput(toInput);
        await sleep(80);
      }
      if (fromInput && fromYmd) {
        await setPageDateValue(fromInput, fromYmd);
        await sleep(120);
      }
      if (toInput && toYmd) {
        await setPageDateValue(toInput, toYmd);
        await sleep(150);
      }
    }

    // Kiểm tra giá trị thực tế sau khi điền
    const actualFrom = (fromInput?.value || '').trim();
    const actualTo = (toInput?.value || '').trim();
    log(`✓ Ngày thực tế trên trang: Từ "${actualFrom}" đến "${actualTo}"`, 'info');

    // Chốt chặn sửa lỗi: Nếu vẫn bị kẹt ngày cũ (do framework không cập nhật), ép gán trực tiếp
    if (fromInput && targetFromDmy && actualFrom !== targetFromDmy && actualFrom !== fromYmd) {
      await setPageDateValue(fromInput, fromYmd);
    }
    if (toInput && targetToDmy && actualTo !== targetToDmy && actualTo !== toYmd) {
      await setPageDateValue(toInput, toYmd);
    }

    return true;
  }

  function findSearchButton() {
    const buttons = Array.from(document.querySelectorAll('button, input[type="submit"], a.btn, .btn'));
    for (const btn of buttons) {
      if (btn.closest('#dvcqg-auto-root')) continue;
      const text = (btn.textContent || btn.value || '').trim().toLowerCase();
      if (text.includes('tìm kiếm') || text.includes('tra cứu')) {
        return btn;
      }
    }
    // Icon-based search buttons
    const iconBtn = document.querySelector('button .bi-search, button .fa-search, button .anticon-search, button svg[data-icon="search"]')?.closest('button');
    if (iconBtn && !iconBtn.closest('#dvcqg-auto-root')) return iconBtn;
    return null;
  }

  // Chuẩn hóa chuỗi XML để so sánh nội dung (loại bỏ khoảng trắng thừa)
  function normalizeXml(xml) {
    if (!xml || typeof xml !== 'string') return '';
    return xml.replace(/\s+/g, ' ').trim();
  }

  // Tìm nút chuyển sang trang tiếp theo (Next Page) trong phân trang Ant Design / DVCQG
  function findNextPageElement() {
    // 1. Quét tất cả button / thẻ a trên trang có chứa chữ "Trang sau"
    // Hỗ trợ chính xác Ant Design v5 trên DVCQG:
    // <button type="button" class="ant-btn css-14al3d1 ant-btn-default ant-btn-color-default ant-btn-variant-outlined flex items-center gap-1"><span class="hidden lg:inline">Trang sau</span></button>
    const allButtons = Array.from(document.querySelectorAll('button, a[role="button"], a, [role="button"]'))
      .filter(el => !el.closest('#dvcqg-auto-root'));

    for (const el of allButtons) {
      const text = (el.innerText || el.textContent || '').trim().toLowerCase();
      if (text.includes('trang sau') || text === 'sau' || text.includes('kế tiếp') || text === 'next') {
        const isDisabled = el.disabled === true ||
                           el.hasAttribute('disabled') ||
                           el.getAttribute('aria-disabled') === 'true' ||
                           el.classList.contains('ant-btn-disabled') ||
                           el.classList.contains('disabled');
        if (!isDisabled && el.offsetParent !== null) {
          return el;
        }
        if (isDisabled) {
          return null; // Đã là trang cuối cùng
        }
      }
    }

    // 1b. Quét qua các thẻ span có chữ "Trang sau" và lấy button cha
    const spans = Array.from(document.querySelectorAll('span')).filter(el => !el.closest('#dvcqg-auto-root'));
    for (const span of spans) {
      const text = (span.textContent || '').trim().toLowerCase();
      if (text === 'trang sau') {
        const parentBtn = span.closest('button, a[role="button"], a');
        if (parentBtn && !parentBtn.closest('#dvcqg-auto-root')) {
          const isDisabled = parentBtn.disabled === true ||
                             parentBtn.hasAttribute('disabled') ||
                             parentBtn.getAttribute('aria-disabled') === 'true' ||
                             parentBtn.classList.contains('ant-btn-disabled') ||
                             parentBtn.classList.contains('disabled');
          if (!isDisabled && parentBtn.offsetParent !== null) {
            return parentBtn;
          }
          if (isDisabled) return null;
        }
      }
    }

    // 2. Ant Design / NG-ZORRO li.ant-pagination-next
    const antNextLi = document.querySelector('li.ant-pagination-next, nz-pagination li.ant-pagination-next, .ant-pagination .ant-pagination-next');
    if (antNextLi && !antNextLi.closest('#dvcqg-auto-root')) {
      const isDisabled = antNextLi.classList.contains('ant-pagination-disabled') ||
                         antNextLi.getAttribute('aria-disabled') === 'true' ||
                         antNextLi.querySelector('button[disabled]');
      if (!isDisabled) {
        const btn = antNextLi.querySelector('button, a, .ant-pagination-item-link') || antNextLi;
        return btn;
      }
      return null; // Đã là trang cuối
    }

    // 3. Thẻ số trang kế tiếp sau trang active
    const activeLi = document.querySelector('li.ant-pagination-item-active, .ant-pagination-item.ant-pagination-item-active');
    if (activeLi && !activeLi.closest('#dvcqg-auto-root')) {
      const nextLi = activeLi.nextElementSibling;
      if (nextLi && nextLi.classList.contains('ant-pagination-item') && !nextLi.classList.contains('ant-pagination-disabled')) {
        const btn = nextLi.querySelector('a, button') || nextLi;
        return btn;
      }
    }

    // 4. Phân trang Bootstrap / HTML table
    const bsNext = document.querySelector('.pagination li.next:not(.disabled) a, .pagination .page-item:not(.disabled) a[aria-label*="Next" i], .pagination [rel="next"]:not([disabled])');
    if (bsNext && !bsNext.closest('#dvcqg-auto-root') && bsNext.offsetParent !== null) {
      return bsNext;
    }

    // 5. Nút generic với aria-label hoặc title
    const genericNext = document.querySelector('button[aria-label*="next" i]:not([disabled]), a[aria-label*="next" i], button[title*="trang sau" i]:not([disabled]), button[title*="kế tiếp" i]:not([disabled])');
    if (genericNext && !genericNext.closest('#dvcqg-auto-root') && genericNext.offsetParent !== null) {
      return genericNext;
    }

    return null;
  }

  // Tự động kiểm tra và chọn 50 bản ghi/trang: <span class="ant-select-selection-item" title="50">50</span>
  async function ensurePageSize50() {
    try {
      // 1. Kiểm tra nếu trên trang đã chọn sẵn 50 bản ghi (<span class="ant-select-selection-item" title="50">50</span>)
      const current50 = Array.from(document.querySelectorAll('.ant-select-selection-item[title="50"], .ant-select-selection-item'))
        .find(el => !el.closest('#dvcqg-auto-root') && (el.getAttribute('title') === '50' || el.textContent.trim() === '50'));
      
      if (current50 && (current50.getAttribute('title') === '50' || current50.textContent.trim() === '50')) {
        return false; // Đã là 50 bản ghi/trang, không cần thao tác lại
      }

      // 2. Tìm thẻ span hiển thị số bản ghi hiện tại của Ant Design (.ant-select-selection-item)
      const selectSpans = Array.from(document.querySelectorAll('.ant-select-selection-item'))
        .filter(el => !el.closest('#dvcqg-auto-root') && el.offsetParent !== null);

      let targetSpan = null;
      for (const span of selectSpans) {
        const title = (span.getAttribute('title') || '').trim();
        const text = (span.textContent || '').trim();
        if (title === '50' || text === '50') {
          return false; // Đã là 50
        }
        // Thường có title hoặc text là các số phân trang (10, 20, 10 / trang, ...)
        if (/^\d{1,3}(\s*\/.*)?$/.test(title) || /^\d{1,3}(\s*\/.*)?$/.test(text)) {
          targetSpan = span;
          break;
        }
      }

      // Fallback: Tìm thẻ select nằm trong .ant-pagination / .ant-pagination-options
      if (!targetSpan) {
        const paginSpan = document.querySelector('.ant-pagination .ant-select-selection-item, nz-pagination .ant-select-selection-item, .ant-pagination-options .ant-select-selection-item');
        if (paginSpan && !paginSpan.closest('#dvcqg-auto-root')) {
          targetSpan = paginSpan;
        }
      }

      if (!targetSpan) {
        return false;
      }

      log('⚡ Đang tự động chuyển sang "50 bản ghi/trang" để tránh sót trạng thái KhoiTaoHoSoBN...', 'info');

      // Click vào trigger của Ant Design Select
      const trigger = targetSpan.closest('.ant-select-selector') || targetSpan.closest('.ant-select') || targetSpan;
      trigger.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      await sleep(150);

      trigger.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true }));
      trigger.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      trigger.click();
      trigger.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));

      // Đợi dropdown popup của Ant Design xuất hiện
      await sleep(350);

      // Tìm option 50: .ant-select-dropdown .ant-select-item-option[title="50"] hoặc [title="50"]
      let opt50 = document.querySelector('.ant-select-dropdown .ant-select-item-option[title="50"], .ant-select-dropdown [title="50"], .ant-select-item-option[title="50"]');
      if (!opt50) {
        const allOpts = Array.from(document.querySelectorAll('.ant-select-dropdown .ant-select-item-option, .ant-select-dropdown .ant-select-item, .cdk-overlay-container .ant-select-item-option'));
        for (const o of allOpts) {
          const t = (o.getAttribute('title') || o.textContent || '').trim();
          if (t === '50' || t.startsWith('50')) {
            opt50 = o;
            break;
          }
        }
      }

      if (opt50) {
        opt50.scrollIntoView({ behavior: 'auto', block: 'nearest' });
        opt50.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true }));
        opt50.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        opt50.click();
        opt50.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        log('✓ Đã chọn "50 bản ghi/trang" thành công! Đang chờ bảng tải dữ liệu mới...', 'success');
        await sleep(1500); // Đợi tải lại bảng 50 dòng
        return true;
      } else {
        document.body.click(); // Đóng popup nếu không tìm thấy
        await sleep(150);
      }
    } catch (err) {
      console.warn('[DVCQG Auto] Không thể tự động chọn số bản ghi 50:', err);
    }
    return false;
  }

  // 4. Extraction Logic: Scanning Tables & Detail Modals với Phân trang thông minh (Cho phép qua tối đa 3 trang nếu chưa tìm thấy)
  async function extractXmlFromTable(targetMa = '', existingRecords = []) {
    log('Bắt đầu phân tích bảng dữ liệu kết quả...', 'info');

    const targetStatuses = Object.keys(state.config.selectedStatuses).filter(k => state.config.selectedStatuses[k]);
    const results = [];

    // Tập hợp các trạng thái đã thu thập để tránh lấy lặp lại nhiều lần
    const collectedStatuses = new Set();
    if (state.config.deduplicateStatus) {
      (existingRecords || []).forEach(r => {
        if (r && r.status) collectedStatuses.add(r.status);
      });
    }

    // CHO PHÉP QUA TỐI ĐA 3 TRANG NẾU CHƯA TÌM THẤY TRƯỚC KHI CHUYỂN TRẠNG THÁI TIẾP
    const MAX_PAGES = Math.max(1, parseInt(state.config.maxPagesPerSearch || 3, 10));
    let currentPage = 1;

    while (currentPage <= MAX_PAGES) {
      if (state.isStopping) break;

      // Đảm bảo mở rộng 50 bản ghi/trang ở trang 1 nếu chưa chọn
      if (currentPage === 1) {
        const changed = await ensurePageSize50();
        if (changed) {
          await sleep(600);
        }
      }

      // Find table
      const tables = Array.from(document.querySelectorAll('table')).filter(t => !t.closest('#dvcqg-auto-root'));
      if (!tables.length) {
        if (currentPage === 1) log('Chưa tìm thấy bảng dữ liệu trên trang!', 'error');
        break;
      }

      // Pick the most likely table (with rows)
      let targetTable = null;
      let tableRows = [];
      for (const tbl of tables) {
        const rows = tbl.querySelectorAll('tbody tr');
        if (rows.length > 0) {
          targetTable = tbl;
          tableRows = Array.from(rows);
          break;
        }
      }

      if (!tableRows.length) {
        if (currentPage === 1) log('Bảng không có hàng dữ liệu nào (kết quả rỗng hoặc chưa load)!', 'warn');
        break;
      }

      const pageLabel = currentPage > 1 ? `[Trang ${currentPage}] ` : '';
      log(`${pageLabel}Tìm thấy ${tableRows.length} hàng dữ liệu trong bảng. Đang rà soát trạng thái...`, 'info');

      for (let i = 0; i < tableRows.length; i++) {
        if (state.isStopping) break;

        const row = tableRows[i];
        const rowText = row.innerText || '';

        // Check which status matches this row
        const matchedStatus = targetStatuses.find(st => rowText.includes(st));
        if (!matchedStatus) {
          continue;
        }

        // TRÁNH LẤY LẶP: Nếu trạng thái này đã được lấy cho hồ sơ này, bỏ qua ngay (không cần mở modal)
        if (state.config.deduplicateStatus && collectedStatuses.has(matchedStatus)) {
          log(`--> ⏭ ${pageLabel}Bỏ qua dòng [${matchedStatus}] (hàng ${i + 1}) vì đã có khối trạng thái này (tránh lấy lặp)`, 'info');
          continue;
        }

        // Check COMPLETED status if option is enabled
        if (state.config.onlyCompleted) {
          const isCompleted = rowText.toUpperCase().includes('COMPLETED');
          if (!isCompleted) {
            log(`--> ${pageLabel}Bỏ qua dòng [${matchedStatus}] (hàng ${i + 1}) vì không ở trạng thái COMPLETED`, 'warn');
            continue;
          }
        }

        log(`--> ${pageLabel}Phát hiện dòng trạng thái [${matchedStatus}] (hàng ${i + 1}) - COMPLETED ✓`, 'info');

        // 1. Check if XML is already embedded in row DOM or dataset
        let xml = findXmlInElement(row);

        // 2. Check if we already captured it via network
        if (!xml && state.capturedNetworkXml.length) {
          const netMatch = state.capturedNetworkXml.find(item => {
            if (!item.xml || !item.xml.includes(matchedStatus) || !isDvcqgEnvelope(item.xml)) return false;
            if (targetMa && !item.xml.includes(targetMa)) return false;
            if (item.used) return false;
            return true;
          });
          if (netMatch) {
            xml = netMatch.xml;
            netMatch.used = true; // Đánh dấu đã sử dụng để không lấy lặp
            log(`${pageLabel}Lấy được Envelope [${matchedStatus}] từ cache mạng.`, 'success');
          }
        }

        // 3. Fallback: Click "Xem" / "Chi tiết" / eye icon to open modal
        if (!xml) {
          xml = await openRowDetailAndExtractXml(row, matchedStatus);
        }

        if (xml) {
          const cleanXml = sanitizeXmlString(xml);
          if (cleanXml && isDvcqgEnvelope(cleanXml)) {
            // Kiểm tra trùng lặp nội dung XML với các khối đã có
            const norm = normalizeXml(cleanXml);
            const isXmlDuplicatedInExisting = (existingRecords || []).some(r => normalizeXml(r.xml) === norm);
            const isXmlDuplicatedInResults = results.some(r => normalizeXml(r.xml) === norm);

            if (isXmlDuplicatedInExisting || isXmlDuplicatedInResults) {
              log(`--> ⏭ ${pageLabel}Bỏ qua dòng [${matchedStatus}] vì nội dung XML bị trùng lặp hoàn toàn với khối đã có`, 'warn');
            } else {
              results.push({
                status: matchedStatus,
                xml: cleanXml,
                maHoSo: targetMa || '',
                index: results.length
              });
              if (state.config.deduplicateStatus) {
                collectedStatuses.add(matchedStatus);
              }
              log(`✓ ${pageLabel}Đã trích xuất thành công Envelope Request Body của [${matchedStatus}]`, 'success');
            }
          } else {
            log(`⚠️ ${pageLabel}Bỏ qua dòng [${matchedStatus}]: Nội dung không phải khối Envelope hợp lệ (<Envelope xmlns="http://dichvucong.gov.vn/api/v1">)`, 'warn');
          }
        } else {
          log(`⚠️ ${pageLabel}Không tìm thấy khối Envelope Request Body cho dòng [${matchedStatus}]`, 'warn');
        }

        await sleep(250);
      }

      // KIỂM TRA PHÂN TRANG THÔNG MINH (CHO PHÉP QUA TỐI ĐA 3 TRANG):
      // Kiểm tra xem đã lấy đủ tất cả các trạng thái yêu cầu chưa (bắt buộc có KhoiTaoHoSoBN đến TraKetQuaBN)
      const allSelectedDone = targetStatuses.every(st => collectedStatuses.has(st));
      if (allSelectedDone) {
        log(`🎯 Đã tìm thấy đầy đủ tất cả ${collectedStatuses.size} trạng thái yêu cầu! Hoàn tất quét bảng.`, 'success');
        break;
      }

      // Nếu vẫn còn thiếu trạng thái (ví dụ thiếu KhoiTaoHoSoBN hoặc TraKetQuaBN):
      const missingList = targetStatuses.filter(st => !collectedStatuses.has(st));
      const nextPageBtn = findNextPageElement();

      if (nextPageBtn && currentPage < MAX_PAGES) {
        log(`📄 [Trang ${currentPage}/${MAX_PAGES}]: Chưa đủ trạng thái (đang thiếu: [${missingList.join(', ')}]). Nhấn "Trang sau" để sang trang ${currentPage + 1}...`, 'info');

        // Ghi lại nội dung hàng đầu tiên hiện tại để nhận biết khi nào trang mới đã tải xong
        const prevFirstRowText = targetTable?.querySelector('tbody tr')?.innerText || '';

        // Kích hoạt click "Trang sau" an toàn cho Ant Design / React
        try {
          nextPageBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          await sleep(150);
          nextPageBtn.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
          nextPageBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
          nextPageBtn.focus?.();
          nextPageBtn.click();
          nextPageBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        } catch (e) {
          nextPageBtn.click();
        }

        // Đợi dữ liệu bảng trang tiếp theo nạp xong
        let loadedNewPage = false;
        const maxWaitMs = 3500;
        const intervalMs = 250;
        let waited = 0;

        while (waited < maxWaitMs) {
          await sleep(intervalMs);
          waited += intervalMs;
          const currentTableNow = document.querySelector('table:not(#dvcqg-auto-root table)');
          const newFirstRow = currentTableNow?.querySelector('tbody tr')?.innerText || '';
          if (newFirstRow && newFirstRow !== prevFirstRowText) {
            loadedNewPage = true;
            break;
          }
        }

        await sleep(500); // Ổn định DOM

        if (loadedNewPage) {
          log(`✓ Đã chuyển sang trang ${currentPage + 1} thành công. Bắt đầu quét tiếp dữ liệu...`, 'info');
        } else {
          log(`ℹ️ Đã gửi lệnh chuyển sang trang ${currentPage + 1}. Bắt đầu quét tiếp dữ liệu...`, 'info');
        }

        currentPage++;
      } else {
        if (currentPage >= MAX_PAGES && missingList.length > 0) {
          log(`ℹ️ [Đợt này]: Đã qua tối đa ${MAX_PAGES} trang nhưng chưa tìm thấy [${missingList.join(', ')}]. Chuyển trạng thái/đợt tiếp theo...`, 'warn');
        } else if (!nextPageBtn && currentPage > 1) {
          log(`ℹ️ [Trang ${currentPage}]: Đã duyệt đến trang cuối cùng của bảng kết quả.`, 'info');
        }
        break;
      }
    }

    return results;
  }

  // Open modal for a specific row and extract Request Body
  async function openRowDetailAndExtractXml(row, statusName) {
    const viewBtn = row.querySelector(
      'button, a, i.bi-eye, i.fa-eye, .anticon-eye, svg[data-icon="eye"], [title*="chi tiết" i], [title*="xem" i]'
    ) || row.querySelector('td:last-child button, td:last-child a');

    if (!viewBtn) {
      log(`Không tìm thấy nút xem chi tiết ở dòng [${statusName}]`, 'warn');
      return null;
    }

    log(`Đang mở chi tiết dòng [${statusName}]...`, 'info');
    viewBtn.click();
    await sleep(800); // Wait for modal animation

    // Find open modal
    const modal = document.querySelector(
      '.modal.show, .modal[style*="display: block"], .ant-modal:not([style*="display: none"]), .ant-modal-content, [role="dialog"], .el-dialog'
    );

    if (!modal) {
      log('Không tìm thấy modal mở ra sau khi click chi tiết!', 'warn');
      return null;
    }

    // If modal has tabs (like "Request", "Gói tin", "Request Body"), try to click it
    const tabs = Array.from(modal.querySelectorAll('.nav-link, .ant-tabs-tab, button, [role="tab"]'));
    for (const tab of tabs) {
      const txt = tab.textContent.toLowerCase();
      if (txt.includes('request') || txt.includes('gói tin') || txt.includes('dữ liệu gửi')) {
        tab.click();
        await sleep(400);
        break;
      }
    }

    // Search for XML inside modal
    let xml = findXmlInElement(modal);

    // Close modal
    const closeBtn = modal.querySelector(
      'button.close, .ant-modal-close, button[aria-label="Close"], button:has(.bi-x), button:has(.fa-times), button[title*="Đóng" i]'
    ) || Array.from(modal.querySelectorAll('button')).find(b => b.textContent.trim().toLowerCase() === 'đóng');

    if (closeBtn) {
      closeBtn.click();
    } else {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    }
    await sleep(400);

    return xml;
  }

  // Helper to decode HTML entities
  function decodeHtmlEntities(str) {
    if (!str || typeof str !== 'string') return '';
    if (!str.includes('&lt;') && !str.includes('&gt;') && !str.includes('&quot;') && !str.includes('&#') && !str.includes('&amp;')) {
      return str;
    }
    try {
      const txt = document.createElement('textarea');
      txt.innerHTML = str;
      return txt.value;
    } catch (e) {
      return str
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&apos;/g, "'")
        .replace(/&amp;/g, '&');
    }
  }

  // Strict regex matching only <Envelope xmlns="http://dichvucong.gov.vn/api/v1">...</Envelope>
  const DVCQG_ENVELOPE_REGEX = /<Envelope\b(?=[^>]*\bxmlns\s*=\s*["']http:\/\/dichvucong\.gov\.vn\/api\/v1\/?["'])[^>]*>[\s\S]*?<\/Envelope>/gi;

  // Extract all <Envelope xmlns="http://dichvucong.gov.vn/api/v1">...</Envelope> blocks from a raw string
  function extractDvcqgEnvelopes(rawStr) {
    if (!rawStr || typeof rawStr !== 'string') return [];

    let str = decodeHtmlEntities(rawStr);

    // Unescape JSON slashes if present (e.g. \/ -> /)
    if (str.includes('\\/')) {
      str = str.replace(/\\\//g, '/');
    }
    if (str.includes('\\"')) {
      str = str.replace(/\\"/g, '"');
    }

    if (!str.includes('http://dichvucong.gov.vn/api/v1') || !str.includes('<Envelope')) {
      return [];
    }

    const matches = str.match(DVCQG_ENVELOPE_REGEX);
    if (!matches) return [];

    return matches.map(m => m.trim()).filter(m => isDvcqgEnvelope(m));
  }

  // Check if a string is strictly a valid DVCQG Envelope
  function isDvcqgEnvelope(str) {
    if (!str || typeof str !== 'string') return false;
    const trimmed = str.trim();
    if (!trimmed.startsWith('<Envelope') || !trimmed.endsWith('</Envelope>')) {
      return false;
    }
    return /<Envelope\b[^>]*\bxmlns\s*=\s*["']http:\/\/dichvucong\.gov\.vn\/api\/v1\/?["']/i.test(trimmed);
  }

  // Regex and helper to extract clean DVCQG Envelope XML from element
  function findXmlInElement(el) {
    if (!el) return null;

    // Check pre, code, textarea, code view containers
    const codeHolders = el.querySelectorAll('pre, code, textarea, div.json-view, div.xml-view, [class*="code"], [class*="xml"]');
    for (const holder of codeHolders) {
      const content = holder.value || holder.textContent || holder.innerText || '';
      const list = extractDvcqgEnvelopes(content);
      if (list.length > 0) return list[0];
    }

    // Check innerText or textContent of the whole container
    const rawText = el.innerText || el.textContent || '';
    const listFromText = extractDvcqgEnvelopes(rawText);
    if (listFromText.length > 0) return listFromText[0];

    // Check innerHTML in case it was encoded
    const rawHtml = el.innerHTML || '';
    const listFromHtml = extractDvcqgEnvelopes(rawHtml);
    if (listFromHtml.length > 0) return listFromHtml[0];

    return null;
  }

  function sanitizeXmlString(xml) {
    if (!xml) return '';
    const envelopes = extractDvcqgEnvelopes(xml);
    if (envelopes.length > 0) {
      return envelopes[0];
    }
    return '';
  }

  // Combine multiple XML blocks in standard order, deduplicating identical status or content
  function combineXmlBlocks(records) {
    const priority = {
      KhoiTaoHoSoBN: 1,
      TiepNhanHoSoBN: 2,
      CapNhatTienTrinhXuLyHoSoBN: 3,
      TaoYeuCauThucHienNghiaVuTaiChinhBN: 4,
      DongBoThongTinThanhToanBN: 5,
      TraKetQuaBN: 6
    };

    // Filter to ensure strictly valid <Envelope xmlns="http://dichvucong.gov.vn/api/v1">...</Envelope>
    const validRecords = records.filter(r => r && r.xml && isDvcqgEnvelope(r.xml));

    // Deduplicate: tránh lấy lặp nhiều khối trạng thái giống nhau hoặc khối XML giống hệt nhau
    const deduplicated = [];
    const seenStatusPerMa = new Set();
    const seenXmlSet = new Set();

    for (const r of validRecords) {
      const norm = normalizeXml(r.xml);
      if (seenXmlSet.has(norm)) continue; // Loại bỏ khối XML trùng lặp 100%

      const maKey = (r.maHoSo || 'default') + '_' + r.status;
      if (state.config.deduplicateStatus) {
        if (seenStatusPerMa.has(maKey)) continue; // Mỗi mã hồ sơ chỉ lấy duy nhất 1 khối cho mỗi trạng thái
        seenStatusPerMa.add(maKey);
      }

      seenXmlSet.add(norm);
      deduplicated.push(r);
    }

    // Sort by MaHoSo and by business process (KhoiTaoHoSoBN luôn đứng vị trí 1 đầu tiên)
    deduplicated.sort((a, b) => {
      if (a.maHoSo && b.maHoSo && a.maHoSo !== b.maHoSo) {
        return a.maHoSo.localeCompare(b.maHoSo);
      }
      const pA = priority[a.status] || 99;
      const pB = priority[b.status] || 99;
      if (pA !== pB) return pA - pB;
      return (a.index || 0) - (b.index || 0);
    });

    // Cảnh báo nếu hồ sơ nào bị thiếu khối bắt buộc KhoiTaoHoSoBN đầu tiên
    const uniqueMaList = Array.from(new Set(validRecords.map(r => r.maHoSo).filter(Boolean)));
    uniqueMaList.forEach(ma => {
      const hasKhoiTao = deduplicated.some(r => r.maHoSo === ma && r.status === 'KhoiTaoHoSoBN');
      if (!hasKhoiTao) {
        log(`⚠️ Chú ý: Hồ sơ [${ma}] chưa có giá trị [KhoiTaoHoSoBN] đầu tiên!`, 'warn');
      }
    });

    return deduplicated.map(r => r.xml.trim()).join('\n\n');
  }

  // 5. Main Auto Flow Execution (Supports batch processing of multiple codes)
  async function executeAutoFlow() {
    if (state.isRunning) return;
    state.isRunning = true;
    state.isStopping = false;
    updateUiRunningState(true);

    try {
      const rawText = state.config.maHoSoListText || '';
      let targetCodes = parseMaHoSoList(rawText);
      const fromDate = state.config.fromDate;
      const toDate = state.config.toDate;

      log('🚀 Bắt đầu quy trình tự động hóa DVCQG...', 'info');

      // Check if user has codes in textarea, or fallback to page input
      if (!targetCodes.length) {
        const pageInput = findMaHoSoInput();
        const pageVal = (pageInput?.value || '').trim();
        if (pageVal) {
          targetCodes = [pageVal];
          log(`Lấy mã đang có trên form: "${pageVal}"`, 'info');
        } else {
          log('❌ Chưa nhập Mã hồ sơ nào trong danh sách!', 'error');
          alert('Vui lòng nhập danh sách mã hồ sơ cần kiểm tra (mỗi dòng 1 mã)!');
          return;
        }
      }

      const total = targetCodes.length;
      log(`📋 Tổng cộng cần kiểm tra ${total} hồ sơ (Bắt buộc có KhoiTaoHoSoBN đầu tiên).`, 'info');

      // Tự động kiểm tra và chọn 50 bản ghi/trang nếu có
      await ensurePageSize50();

      const allExtractedRecords = [];

      // Batch execution loop
      for (let i = 0; i < total; i++) {
        if (state.isStopping) {
          log('⏹ Người dùng đã nhấn Dừng tiến trình!', 'warn');
          break;
        }

        const currentMa = targetCodes[i];
        updateBatchProgress(i, total, currentMa);
        log(`\n========================================`, 'info');
        log(`▶ [${i + 1}/${total}] Đang xử lý hồ sơ: ${currentMa}`, 'info');
        updateStepTracker([]); // Reset tracker for current application code
        state.capturedNetworkXml = []; // Xóa cache mạng để tránh nhận nhầm gói tin XML giữa các hồ sơ khác nhau

        // 1. Điền Mã hồ sơ
        const inputMaHoSo = findMaHoSoInput();
        if (inputMaHoSo) {
          setNativeValue(inputMaHoSo, currentMa);
          log(`✓ Đã điền Mã hồ sơ: "${currentMa}"`, 'success');
        } else {
          log('⚠️ Không tìm thấy ô nhập Mã hồ sơ trên trang web!', 'warn');
        }

        await sleep(300);

        // 2. Xác định các khoảng ngày tìm kiếm (Smart Dates chia theo từng tháng)
        let dateWindows = [];
        const filingDate = parseDateFromMaHoSo(currentMa);

        const depth = state.config.searchDepthMonths || 3;
        if (filingDate && (state.config.smartDateSearch || !fromDate)) {
          dateWindows = generateSmartDateRanges(filingDate, depth);
          log(`🧠 Nhận diện ngày sinh từ mã [${currentMa}]: ${formatDateDMY(filingDate)} -> Đợt 1 [KhoiTaoHoSoBN: ${formatDateDMY(filingDate)} ➜ ${formatDateDMY(filingDate)}]; rà soát các tháng sau (độ sâu ${depth} tháng sau đó, ${dateWindows.length} đợt)`, 'info');
        } else if (filingDate) {
          // Khi có ngày sinh mã: ưu tiên chia theo từng tháng để không vi phạm giới hạn 1 tháng của DVCQG
          dateWindows = generateSmartDateRanges(filingDate, depth);
          log(`🧠 Chia đợt tra cứu thông minh cho mã [${currentMa}]: ${dateWindows.length} đợt (độ sâu ${depth} tháng sau đó)`, 'info');
        } else {
          // Fallback khoảng ngày thủ công do người dùng chọn
          dateWindows = [{
            from: fromDate || '',
            to: toDate || '',
            label: 'Khoảng ngày chỉ định'
          }];
        }

        const currentMaRecords = [];

        // Tra cứu chu kỳ theo từng tháng (lấy đầy đủ từ Khởi tạo đến Trả kết quả)
        for (let w = 0; w < dateWindows.length; w++) {
          if (state.isStopping) break;

          const win = dateWindows[w];
          log(`📅 Tra cứu đợt ${w + 1}/${dateWindows.length} [${win.label}]: Từ ${formatDateDMY(win.from) || 'mặc định'} đến ${formatDateDMY(win.to) || 'mặc định'}`, 'info');

          // Cập nhật ô Từ ngày & Đến ngày trên floating panel để người dùng theo dõi trực quan
          const panelFrom = document.getElementById('dvcqg-input-from');
          const panelTo = document.getElementById('dvcqg-input-to');
          if (panelFrom && win.from) panelFrom.value = win.from;
          if (panelTo && win.to) panelTo.value = win.to;

          // Điền ngày vào form trang web: Áp dụng cơ chế bước đệm thông minh applyDateRangeToWebPage
          // để tuyệt đối không bị kẹt ngày cuối tháng cũ hay xung đột ràng buộc Từ ngày > Đến ngày
          await applyDateRangeToWebPage(win.from, win.to);

          await sleep(350);

          // Click Tìm kiếm
          const searchBtn = findSearchButton();
          if (searchBtn) {
            searchBtn.click();
            log('✓ Đã nhấn Tìm kiếm. Đang đợi máy chủ tải dữ liệu...', 'info');
            await sleep(2500); // Wait for API response & render
          }

          if (state.isStopping) break;

          // Trích xuất XML từ bảng kết quả (truyền currentMa và currentMaRecords để tránh lấy lặp trạng thái đã có)
          const records = await extractXmlFromTable(currentMa, currentMaRecords);
          if (records.length > 0) {
            records.forEach(r => r.maHoSo = currentMa);
            for (const r of records) {
              const rNorm = normalizeXml(r.xml);
              const isDuplicate = currentMaRecords.some(x => {
                if (state.config.deduplicateStatus && x.status === r.status) return true;
                return normalizeXml(x.xml) === rNorm;
              });

              if (!isDuplicate) {
                currentMaRecords.push(r);
              } else {
                log(`⏭ Bỏ qua khối trùng lặp [${r.status}] cho mã ${currentMa}`, 'info');
              }
            }
            log(`✓ [${currentMa}] [${win.label}]: Thu thập được ${records.length} khối XML Envelope!`, 'success');
          } else {
            log(`[${currentMa}] [${win.label}]: Không có bản ghi mới nào trong đợt này`, 'info');
          }

          // Cập nhật số step đã thực hiện
          const completedStepsCount = updateStepTracker(currentMaRecords);
          const completedNames = STEP_DEFINITIONS.filter(s => currentMaRecords.some(r => r.status === s.key)).map(s => s.label);
          updateBatchProgress(i, total, currentMa, `${completedStepsCount}/6 steps`);
          log(`📊 [${currentMa}]: Đã thực hiện ${completedStepsCount}/6 steps [${completedNames.join(', ')}]`, 'info');

          // Kiểm tra xem đã có từ KhoiTaoHoSoBN (BẮT BUỘC ĐẦU TIÊN) đến TraKetQuaBN chưa
          const hasKhoiTao = currentMaRecords.some(r => r.status === 'KhoiTaoHoSoBN');
          const hasTiepNhan = currentMaRecords.some(r => r.status === 'TiepNhanHoSoBN');
          const hasTraKetQua = currentMaRecords.some(r => r.status === 'TraKetQuaBN');
          const isAllStepsCompleted = completedStepsCount === STEP_DEFINITIONS.length;

          // BẮT BUỘC: Tất cả các hồ sơ kiểm tra phải có giá trị "KhoiTaoHoSoBN" đầu tiên!
          // Chu trình chỉ hoàn chỉnh khi BẮT BUỘC có KhoiTaoHoSoBN và TraKetQuaBN (hoặc đủ 6/6 steps)
          const isCompleteCycle = hasKhoiTao && hasTraKetQua;

          if (isAllStepsCompleted || isCompleteCycle) {
            log(`🎯 ĐÃ TÌM THẤY BƯỚC BẮT BUỘC ĐẦU TIÊN [KhoiTaoHoSoBN] VÀ TRẠNG THÁI CUỐI CÙNG [TraKetQuaBN] (${completedStepsCount}/6 steps) cho mã ${currentMa}! Hoàn tất chu kỳ xử lý hồ sơ.`, 'success');
            break; // Hoàn tất chu kỳ xử lý hồ sơ này
          } else if (hasTraKetQua && !hasKhoiTao) {
            log(`⚠️ [${currentMa}]: Đã có [TraKetQuaBN] nhưng BẮT BUỘC PHẢI CÓ giá trị [KhoiTaoHoSoBN] đầu tiên (mới đạt ${completedStepsCount}/6 steps). Tiếp tục tìm kiếm để lấy bằng được KhoiTaoHoSoBN...`, 'warn');
          } else if (w < dateWindows.length - 1) {
            const nextWin = dateWindows[w + 1];
            if (hasKhoiTao) {
              log(`✓ [${currentMa}]: Đã có giá trị đầu tiên [KhoiTaoHoSoBN]. Chưa thấy trạng thái cuối cùng [TraKetQuaBN] (đạt ${completedStepsCount}/6 steps). Tiếp tục rà quét thời gian tiếp theo: [${nextWin.label}] đến khi tìm thấy TraKetQuaBN...`, 'info');
            } else {
              log(`⚠️ [${currentMa}]: Chưa tìm thấy giá trị bắt buộc đầu tiên [KhoiTaoHoSoBN] trong ${win.label} (mới đạt ${completedStepsCount}/6 steps). Tiếp tục rà quét thời gian tiếp theo: [${nextWin.label}]...`, 'warn');
            }
            await sleep(1500);
          } else {
            if (!hasKhoiTao) {
              log(`❌ [${currentMa}]: CẢNH BÁO - Đã rà soát tối đa ${dateWindows.length} đợt nhưng KHÔNG TÌM THẤY giá trị [KhoiTaoHoSoBN] bắt buộc đầu tiên! (Thu được ${completedStepsCount}/6 steps).`, 'error');
            } else {
              log(`ℹ️ [${currentMa}]: Đã hoàn tất rà soát tối đa ${dateWindows.length} đợt (độ sâu tối đa ${depth} tháng sau tháng nộp). Thu được ${completedStepsCount}/6 steps.`, 'info');
            }
          }
        }

        allExtractedRecords.push(...currentMaRecords);

        // Cập nhật số khối XML tổng
        const countEl = document.getElementById('dvcqg-extracted-count');
        if (countEl) countEl.textContent = `${allExtractedRecords.length} khối`;

        // Wait before next record to avoid rate-limiting
        if (i < total - 1 && !state.isStopping) {
          log('Đang chờ 1.5s trước khi xử lý hồ sơ tiếp theo...', 'info');
          await sleep(1500);
        }
      }

      updateBatchProgress(total, total, 'Hoàn tất');

      state.extractedXmlBlocks = allExtractedRecords;

      if (!allExtractedRecords.length) {
        log('❌ Không trích xuất được khối XML nào từ các hồ sơ đã kiểm tra!', 'error');
        alert('Không tìm thấy khối XML nào từ các hồ sơ đã kiểm tra. Vui lòng kiểm tra lại bảng kết quả hoặc khoảng ngày!');
        return;
      }

      log(`\n🎉 HOÀN TẤT KIỂM TRA ${targetCodes.length} HỒ SƠ! Tổng cộng ${allExtractedRecords.length} khối XML.`, 'success');

      // 5. Ghép các khối XML
      const combined = combineXmlBlocks(allExtractedRecords);
      state.lastExtractedCombined = combined;

      // 6. Tự động chuyển sang rà soát nếu được bật
      if (state.config.autoTransfer) {
        log('🚀 Đang chuyển dữ liệu XML sang https://cdn.dnncloud.net/tthc/rasoat.html...', 'info');
        const representativeMa = targetCodes.length === 1 ? targetCodes[0] : `${targetCodes.length} hồ sơ (${targetCodes[0]}...)`;
        transferDataToRasoat(combined, representativeMa, fromDate, toDate);
      } else {
        log('Đã trích xuất xong! Bấm "Chuyển sang Rà soát" hoặc "Xem XML" để tiếp tục.', 'success');
      }

    } catch (err) {
      log(`Lỗi trong quá trình tự động: ${err.message}`, 'error');
      console.error(err);
    } finally {
      state.isRunning = false;
      state.isStopping = false;
      updateUiRunningState(false);
    }
  }

  // Update batch progress UI
  function updateBatchProgress(current, total, currentMa, stepsInfo = '') {
    const container = document.getElementById('dvcqg-batch-progress');
    const textEl = document.getElementById('dvcqg-progress-text');
    const pctEl = document.getElementById('dvcqg-progress-pct');
    const fillEl = document.getElementById('dvcqg-progress-fill');
    if (!container) return;

    if (total <= 1 && !stepsInfo) {
      container.style.display = 'none';
      return;
    }

    container.style.display = 'flex';
    const pct = Math.min(100, Math.round((current / total) * 100));
    const stepSuffix = stepsInfo ? ` • ${stepsInfo}` : '';
    if (textEl) textEl.textContent = `Hồ sơ ${Math.min(current + 1, total)}/${total}: ${currentMa || ''}${stepSuffix}`;
    if (pctEl) pctEl.textContent = `${pct}%`;
    if (fillEl) fillEl.style.width = `${pct}%`;
  }

  // Quick extract from already displayed table
  async function executeCurrentTableExtract() {
    if (state.isRunning) return;
    state.isRunning = true;
    updateUiRunningState(true);

    try {
      log('⚡ Bắt đầu trích xuất trực tiếp từ bảng hiện tại...', 'info');
      await ensurePageSize50();
      const pageInp = findMaHoSoInput();
      const pageMa = (pageInp?.value || '').trim();
      const records = await extractXmlFromTable(pageMa, []);
      state.extractedXmlBlocks = records;

      if (!records.length) {
        log('❌ Không tìm thấy khối XML nào từ bảng hiện tại.', 'error');
        alert('Không tìm thấy khối XML nào từ bảng hiện tại.');
        return;
      }

      const stepsCount = updateStepTracker(records);
      const combined = combineXmlBlocks(records);
      state.lastExtractedCombined = combined;

      const countEl = document.getElementById('dvcqg-extracted-count');
      if (countEl) countEl.textContent = `${records.length} khối (${stepsCount}/6 steps)`;

      log(`✓ Đã trích xuất xong ${records.length} khối XML Envelope (${stepsCount}/6 steps đã thực hiện).`, 'success');

      if (state.config.autoTransfer) {
        transferDataToRasoat(combined, 'Bảng hiện tại', state.config.fromDate, state.config.toDate);
      }
    } finally {
      state.isRunning = false;
      updateUiRunningState(false);
    }
  }

  // Send data to background to open/fill rasoat.html
  function transferDataToRasoat(xml, maHoSo, fromDate, toDate) {
    if (!xml) {
      alert('Chưa có dữ liệu XML nào được trích xuất!');
      return;
    }

    // Auto-copy XML to clipboard as an extra guarantee
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(xml).catch(() => {});
    }

    log('Đang gửi tín hiệu mở trang Rà soát DVCQG...', 'info');

    chrome.runtime.sendMessage({
      action: 'TRANSFER_TO_RASOAT',
      data: {
        xml,
        maHoSo: maHoSo || '',
        fromDate: fromDate || '',
        toDate: toDate || ''
      }
    }, (response) => {
      if (chrome.runtime.lastError) {
        log(`Lỗi liên lạc Extension: ${chrome.runtime.lastError.message}`, 'error');
      } else if (response && response.success) {
        log('✓ Đã điều hướng sang trang Rà soát và tự động dán dữ liệu vào form thành công!', 'success');
      }
    });
  }

  function updateUiRunningState(running) {
    const runBtn = document.getElementById('dvcqg-btn-run');
    const directBtn = document.getElementById('dvcqg-btn-direct');
    const stopBtn = document.getElementById('dvcqg-btn-stop');
    const progressBox = document.getElementById('dvcqg-batch-progress');

    if (runBtn) {
      runBtn.disabled = running;
      runBtn.innerHTML = running ? '⏳ Đang tự động xử lý...' : '▶ Bắt đầu Tự Động';
    }
    if (directBtn) {
      directBtn.disabled = running;
    }
    if (stopBtn) {
      stopBtn.style.display = running ? 'flex' : 'none';
      stopBtn.disabled = false;
      stopBtn.innerHTML = '<span>⏹ Dừng tiến trình</span>';
    }
    if (!running && progressBox) {
      progressBox.style.display = 'none';
    }
  }

  // 6. Build & Mount Floating Control Panel
  function buildUi() {
    if (rootEl) return;

    // Load saved settings from chrome.storage
    chrome.storage.local.get(['dvcqg_config'], (res) => {
      if (res.dvcqg_config) {
        // Compatibility: support old maHoSo field if maHoSoListText is not set
        if (!res.dvcqg_config.maHoSoListText && res.dvcqg_config.maHoSo) {
          res.dvcqg_config.maHoSoListText = res.dvcqg_config.maHoSo;
        }
        if (res.dvcqg_config.selectedStatuses) {
          state.config.selectedStatuses = Object.assign(
            {},
            state.config.selectedStatuses,
            res.dvcqg_config.selectedStatuses
          );
          delete res.dvcqg_config.selectedStatuses;
        }
        Object.assign(state.config, res.dvcqg_config);
      }
      initDatesIfEmpty();
      renderUi();
      // Ensure date inputs reflect filing date if codes are present
      autoSelectInitialDateFromMaHoSo(false);
    });
  }

  // Tự động nhận diện và chọn thời gian ban đầu (Từ ngày) theo ngày sinh của mã hồ sơ
  function autoSelectInitialDateFromMaHoSo(force = false) {
    const textareaMa = document.getElementById('dvcqg-textarea-ma');
    const inputFrom = document.getElementById('dvcqg-input-from');
    const inputTo = document.getElementById('dvcqg-input-to');

    let rawList = textareaMa ? textareaMa.value : (state.config.maHoSoListText || '');
    let list = parseMaHoSoList(rawList);

    // Nếu chưa có trong danh sách, thử lấy mã đang nhập trên form web
    if (!list.length) {
      const pageInp = findMaHoSoInput();
      const pVal = (pageInp?.value || '').trim();
      if (pVal) list = [pVal];
    }

    if (!list.length) return false;

    // Tìm ngày nộp sớm nhất trong danh sách mã (hoặc mã đầu tiên)
    let earliestDate = null;
    let matchingMa = '';

    for (const ma of list) {
      const d = parseDateFromMaHoSo(ma);
      if (d) {
        if (!earliestDate || d < earliestDate) {
          earliestDate = d;
          matchingMa = ma;
        }
      }
    }

    if (earliestDate) {
      const ymd = formatDateYMD(earliestDate);
      const dmy = formatDateDMY(earliestDate);

      // VỚI KhoiTaoHoSoBN: NGÀY BẮT ĐẦU VÀ KẾT THÚC LẤY THEO NGÀY HỒ SƠ
      const ymdTo = ymd;
      const dmyTo = dmy;

      if (force || !state.config.fromDate || state.config.fromDate !== ymd || state.config.toDate !== ymdTo) {
        state.config.fromDate = ymd;
        state.config.toDate = ymdTo;
        if (inputFrom) inputFrom.value = ymd;
        if (inputTo) inputTo.value = ymdTo;

        saveConfig();
        log(`🧠 Đã tự động chọn Thời gian tra cứu theo mã [${matchingMa}]: ${dmy} ➜ ${dmyTo} (KhoiTaoHoSoBN: ngày bắt đầu và kết thúc lấy theo ngày hồ sơ)`, 'success');
        return true;
      }
    }

    return false;
  }

  function initDatesIfEmpty() {
    // Ưu tiên trích xuất ngày sinh từ danh sách mã hồ sơ trước (Đến ngày tối đa trong tháng)
    const autoSet = autoSelectInitialDateFromMaHoSo(false);
    if (!autoSet) {
      const today = new Date();
      if (!state.config.toDate) {
        state.config.toDate = formatDateYMD(today);
      }
      if (!state.config.fromDate) {
        // Mặc định ngày 01 của tháng hiện tại để cùng nằm trong 1 tháng
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        state.config.fromDate = formatDateYMD(startOfMonth);
      }
    }
  }

  function renderUi() {
    rootEl = document.createElement('div');
    rootEl.id = 'dvcqg-auto-root';

    const initialCodes = parseMaHoSoList(state.config.maHoSoListText);

    rootEl.innerHTML = `
      <!-- Launcher Button (when minimized) -->
      <button id="dvcqg-launcher" class="dvcqg-launcher-btn" style="display: none;" title="Mở bảng điều khiển Tự động DVCQG">
        <span class="pulse-dot"></span>
        <span>Auto Check DVCQG</span>
      </button>

      <!-- Main Control Panel -->
      <div id="dvcqg-panel" class="dvcqg-panel">
        <div class="dvcqg-panel-header">
          <div class="dvcqg-panel-title">
            <span>⚡ Auto Check DVCQG</span>
            <span class="dvcqg-panel-badge" title="Tác giả: Kyn Chou | Ngày phiên bản: 10/10/2026">v2.2.0</span>
          </div>
          <div class="dvcqg-header-actions">
            <button id="dvcqg-btn-minimize" class="dvcqg-icon-btn" title="Thu nhỏ">_</button>
            <button id="dvcqg-btn-close" class="dvcqg-icon-btn" title="Đóng">✕</button>
          </div>
        </div>

        <div class="dvcqg-panel-body">
          <!-- Danh sách Mã hồ sơ input (Hỗ trợ nhiều mã) -->
          <div class="dvcqg-form-group">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <label class="dvcqg-label">
                Danh sách mã hồ sơ 
                <span id="dvcqg-ma-count" style="color: #0b6e6e; font-weight: normal; text-transform: none;">(${initialCodes.length} mã)</span>
              </label>
              <div style="display: flex; gap: 4px;">
                <button id="dvcqg-btn-paste-ma" type="button" class="dvcqg-preset-btn" style="width: auto; padding: 2px 6px;" title="Tự động dán từ Clipboard">📋 Dán</button>
                <button id="dvcqg-btn-clear-ma" type="button" class="dvcqg-preset-btn btn-danger-soft" style="width: auto; padding: 2px 6px;" title="Xóa toàn bộ danh sách mã hồ sơ">🗑️ Xóa</button>
              </div>
            </div>
            <textarea id="dvcqg-textarea-ma" class="dvcqg-textarea-ma" rows="3" placeholder="Nhập danh sách mã hồ sơ (mỗi dòng 1 mã, hoặc ngăn cách bằng dấu phẩy)&#10;VD:&#10;H56.01-240101-0001&#10;H56.01-240101-0002">${state.config.maHoSoListText || ''}</textarea>
          </div>

          <!-- Từ ngày - Đến ngày -->
          <div class="dvcqg-form-group">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <label class="dvcqg-label">Thời gian tra cứu</label>
              <span style="font-size: 11px; color: #0d9488; font-weight: 600;">Tối đa trong tháng</span>
            </div>
            <div class="dvcqg-date-grid">
              <div>
                <input id="dvcqg-input-from" type="date" class="dvcqg-input-date" value="${state.config.fromDate || ''}" title="Từ ngày">
              </div>
              <div>
                <input id="dvcqg-input-to" type="date" class="dvcqg-input-date" value="${state.config.toDate || ''}" title="Đến ngày (chỉ chọn tối đa trong tháng)">
              </div>
            </div>
            <div class="dvcqg-date-presets">
              <button type="button" class="dvcqg-preset-btn highlight" data-preset="by-ma" title="Từ ngày và Đến ngày lấy theo ngày hồ sơ để tìm KhoiTaoHoSoBN">📅 Theo mã HS</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="this-month" title="Đầu tháng đến cuối tháng này">Tháng này</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="today">Hôm nay</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="7d">7 ngày</button>
              <button type="button" class="dvcqg-preset-btn" data-preset="30d">30 ngày</button>
            </div>
            <!-- Smart Date Search Option -->
            <label class="dvcqg-checkbox-item" style="margin-top: 6px; font-size: 11px; color: #0b6e6e; font-weight: 600;">
              <input type="checkbox" id="dvcqg-check-smart-date" ${state.config.smartDateSearch ? 'checked' : ''}>
              <span>🧠 Tra cứu thông minh: Bắt đầu từ KhoiTaoHoSoBN (ngày hồ sơ), rà soát các tháng sau</span>
            </label>
            <!-- Tùy chỉnh độ sâu rà soát -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; padding: 4px 8px; background: #f0fdfa; border: 1px solid #ccfbf1; border-radius: 6px; font-size: 11px;">
              <span style="color: #0f766e; font-weight: 600;">🔍 Độ sâu rà soát tháng sau:</span>
              <select id="dvcqg-select-search-depth" style="padding: 2px 6px; border: 1px solid #0d9488; border-radius: 4px; font-size: 11px; font-weight: bold; color: #0f766e; background: #fff; cursor: pointer;">
                <option value="1" ${(state.config.searchDepthMonths ?? 3) === 1 ? 'selected' : ''}>1 tháng sau</option>
                <option value="2" ${(state.config.searchDepthMonths ?? 3) === 2 ? 'selected' : ''}>2 tháng sau</option>
                <option value="3" ${(state.config.searchDepthMonths ?? 3) === 3 ? 'selected' : ''}>3 tháng sau (Mặc định)</option>
                <option value="4" ${(state.config.searchDepthMonths ?? 3) === 4 ? 'selected' : ''}>4 tháng sau</option>
                <option value="5" ${(state.config.searchDepthMonths ?? 3) === 5 ? 'selected' : ''}>5 tháng sau</option>
                <option value="6" ${(state.config.searchDepthMonths ?? 3) === 6 ? 'selected' : ''}>6 tháng sau</option>
                <option value="12" ${(state.config.searchDepthMonths ?? 3) === 12 ? 'selected' : ''}>12 tháng sau</option>
              </select>
            </div>
            <!-- Cho phép qua tối đa 3 trang nếu chưa tìm thấy -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 5px; padding: 4px 8px; background: #f0fdfa; border: 1px solid #ccfbf1; border-radius: 6px; font-size: 11px;">
              <span style="color: #0f766e; font-weight: 600;" title="Cho phép qua tối đa bao nhiêu trang nếu chưa tìm thấy đủ trạng thái trước khi chuyển sang đợt tiếp theo">📄 Qua tối đa trang/đợt:</span>
              <select id="dvcqg-select-max-pages" style="padding: 2px 6px; border: 1px solid #0d9488; border-radius: 4px; font-size: 11px; font-weight: bold; color: #0f766e; background: #fff; cursor: pointer;">
                <option value="1" ${(state.config.maxPagesPerSearch ?? 3) === 1 ? 'selected' : ''}>1 trang</option>
                <option value="2" ${(state.config.maxPagesPerSearch ?? 3) === 2 ? 'selected' : ''}>2 trang</option>
                <option value="3" ${(state.config.maxPagesPerSearch ?? 3) === 3 ? 'selected' : ''}>3 trang (Mặc định)</option>
                <option value="5" ${(state.config.maxPagesPerSearch ?? 3) === 5 ? 'selected' : ''}>5 trang</option>
              </select>
            </div>
          </div>

          <!-- Lọc trạng thái đồng bộ -->
          <div class="dvcqg-status-box">
            <div class="dvcqg-status-title">
              <span>TRẠNG THÁI CẦN TRÍCH XUẤT</span>
              <span id="dvcqg-extracted-count" style="color: #0b6e6e; font-weight: bold;">0 khối</span>
            </div>
            <div class="dvcqg-status-list">
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-KhoiTaoHoSoBN" checked disabled title="KhoiTaoHoSoBN là giá trị bắt buộc đầu tiên cho tất cả hồ sơ">
                <span class="code-badge" style="background:#e0f2fe; color:#0369a1; border-color:#bae6fd;">KhoiTaoHoSoBN ★ Đầu tiên</span>
                <span class="item-desc">Khởi tạo</span>
                <span id="badge-st-KhoiTaoHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TiepNhanHoSoBN" ${state.config.selectedStatuses.TiepNhanHoSoBN ? 'checked' : ''}>
                <span class="code-badge">TiepNhanHoSoBN</span>
                <span class="item-desc">Tiếp nhận</span>
                <span id="badge-st-TiepNhanHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-CapNhatTienTrinhXuLyHoSoBN" ${state.config.selectedStatuses.CapNhatTienTrinhXuLyHoSoBN ? 'checked' : ''}>
                <span class="code-badge">CapNhatTienTrinhXuLyHoSoBN</span>
                <span class="item-desc">Tiến trình</span>
                <span id="badge-st-CapNhatTienTrinhXuLyHoSoBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TaoYeuCauThucHienNghiaVuTaiChinhBN" ${state.config.selectedStatuses.TaoYeuCauThucHienNghiaVuTaiChinhBN ? 'checked' : ''}>
                <span class="code-badge">TaoYeuCauThucHienNghiaVuTaiChinhBN</span>
                <span class="item-desc">Y/c tài chính</span>
                <span id="badge-st-TaoYeuCauThucHienNghiaVuTaiChinhBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-DongBoThongTinThanhToanBN" ${state.config.selectedStatuses.DongBoThongTinThanhToanBN ? 'checked' : ''}>
                <span class="code-badge">DongBoThongTinThanhToanBN</span>
                <span class="item-desc">Thanh toán</span>
                <span id="badge-st-DongBoThongTinThanhToanBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item">
                <input type="checkbox" id="st-TraKetQuaBN" ${state.config.selectedStatuses.TraKetQuaBN ? 'checked' : ''}>
                <span class="code-badge">TraKetQuaBN</span>
                <span class="item-desc">Trả kết quả</span>
                <span id="badge-st-TraKetQuaBN" class="dvcqg-step-state-tag wait">Chờ quét</span>
              </label>
              <label class="dvcqg-checkbox-item" style="margin-top: 4px; padding-top: 4px; border-top: 1px dashed #cbd5e1; font-weight: 600; color: #047857;">
                <input type="checkbox" id="dvcqg-check-only-completed" ${state.config.onlyCompleted ? 'checked' : ''}>
                <span>Chỉ lấy trạng thái <b>COMPLETED</b></span>
              </label>
              <label class="dvcqg-checkbox-item" style="margin-top: 3px; font-weight: 600; color: #0b6e6e;">
                <input type="checkbox" id="dvcqg-check-deduplicate" ${state.config.deduplicateStatus !== false ? 'checked' : ''}>
                <span title="Mỗi trạng thái (Khởi tạo, Tiếp nhận,...) chỉ lấy 1 khối duy nhất, loại bỏ hoàn toàn các khối trùng lặp">Tránh lấy lặp lại khối trạng thái giống nhau</span>
              </label>
            </div>
          </div>

          <!-- Step tracker: Hiển thị số step đã thực hiện từ Khởi tạo đến Trả kết quả -->
          <div class="dvcqg-step-tracker-box">
            <div class="dvcqg-step-tracker-header">
              <span class="dvcqg-step-tracker-title">TIẾN TRÌNH STEP (KHỞI TẠO ➜ TRẢ KẾT QUẢ)</span>
              <span id="dvcqg-step-counter-badge" class="dvcqg-step-counter-badge">0/6 steps</span>
            </div>
            <!-- Mini progress bar -->
            <div class="dvcqg-step-mini-bar">
              <div id="dvcqg-step-mini-fill" class="dvcqg-step-mini-fill" style="width: 0%;"></div>
            </div>
            <div id="dvcqg-step-chips" class="dvcqg-step-chips">
              <span class="dvcqg-step-chip pending" id="chip-KhoiTaoHoSoBN" title="1. Khởi tạo hồ sơ">
                <span class="step-chip-name">1. Khởi tạo</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TiepNhanHoSoBN" title="2. Tiếp nhận hồ sơ">
                <span class="step-chip-name">2. Tiếp nhận</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-CapNhatTienTrinhXuLyHoSoBN" title="3. Cập nhật tiến trình">
                <span class="step-chip-name">3. Tiến trình</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TaoYeuCauThucHienNghiaVuTaiChinhBN" title="4. Tạo yêu cầu tài chính">
                <span class="step-chip-name">4. Tài chính</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-DongBoThongTinThanhToanBN" title="5. Đồng bộ thanh toán">
                <span class="step-chip-name">5. Thanh toán</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
              <span class="dvcqg-step-chip pending" id="chip-TraKetQuaBN" title="6. Trả kết quả">
                <span class="step-chip-name">6. Trả kết quả</span>
                <span class="step-chip-status wait">Chờ quét</span>
              </span>
            </div>
          </div>

          <!-- Auto transfer option -->
          <label class="dvcqg-option-checkbox">
            <input type="checkbox" id="dvcqg-check-autotransfer" ${state.config.autoTransfer ? 'checked' : ''}>
            <span>Tự động mở và nạp vào trang Rà soát</span>
          </label>

          <!-- Batch progress bar -->
          <div id="dvcqg-batch-progress" class="dvcqg-progress-container" style="display: none;">
            <div class="dvcqg-progress-header">
              <span id="dvcqg-progress-text">Đang xử lý: 0/0 hồ sơ</span>
              <span id="dvcqg-progress-pct">0%</span>
            </div>
            <div class="dvcqg-progress-bar">
              <div id="dvcqg-progress-fill" class="dvcqg-progress-fill"></div>
            </div>
          </div>

          <!-- Action Buttons -->
          <div class="dvcqg-action-grid">
            <button id="dvcqg-btn-run" class="dvcqg-btn-primary">
              <span>▶ Bắt đầu Tự Động</span>
            </button>
            <button id="dvcqg-btn-stop" class="dvcqg-btn-danger" style="display: none;">
              <span>⏹ Dừng tiến trình</span>
            </button>
            <button id="dvcqg-btn-direct" class="dvcqg-btn-secondary" title="Trích xuất từ bảng kết quả đang hiển thị trên màn hình">
              <span>⚡ Trích xuất bảng hiện tại</span>
            </button>
            <div class="dvcqg-sub-actions">
              <button id="dvcqg-btn-preview" class="dvcqg-btn-ghost">📋 Xem XML</button>
              <button id="dvcqg-btn-send-manual" class="dvcqg-btn-ghost">🚀 Sang Rà soát</button>
            </div>
          </div>

          <!-- Live Log Console -->
          <div id="dvcqg-log-box" class="dvcqg-log-box"></div>
        </div>

        <!-- Footer Credit -->
        <div class="dvcqg-panel-footer" style="padding: 6px 14px; font-size: 11px; color: #64748b; background: #f8fafc; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; border-radius: 0 0 12px 12px;">
          <span>Tác giả: <strong style="color: #0b6e6e;">Kyn Chou</strong></span>
          <span style="font-weight: 500;">v2.2.0 (10/10/2026)</span>
        </div>
      </div>
    `;

    document.body.appendChild(rootEl);
    logBoxEl = document.getElementById('dvcqg-log-box');

    log('Extension sẵn sàng! Nhập danh sách mã hồ sơ và nhấn "Bắt đầu Tự Động".', 'info');

    bindUiEvents();
  }

  function bindUiEvents() {
    const launcher = document.getElementById('dvcqg-launcher');
    const panel = document.getElementById('dvcqg-panel');
    const btnMin = document.getElementById('dvcqg-btn-minimize');
    const btnClose = document.getElementById('dvcqg-btn-close');

    launcher.addEventListener('click', () => {
      launcher.style.display = 'none';
      panel.style.display = 'flex';
    });

    btnMin.addEventListener('click', () => {
      panel.style.display = 'none';
      launcher.style.display = 'flex';
    });

    btnClose.addEventListener('click', () => {
      panel.style.display = 'none';
      launcher.style.display = 'flex';
    });

    // Multi-line MaHoSo textarea sync
    const textareaMa = document.getElementById('dvcqg-textarea-ma');
    const maCountEl = document.getElementById('dvcqg-ma-count');

    function updateMaCount() {
      const list = parseMaHoSoList(textareaMa.value);
      if (maCountEl) {
        maCountEl.textContent = `(${list.length} mã)`;
      }
    }

    textareaMa.addEventListener('input', (e) => {
      state.config.maHoSoListText = e.target.value;
      updateMaCount();
      autoSelectInitialDateFromMaHoSo(true);
      saveConfig();
    });

    // Paste from Clipboard into MaHoSo textarea (Xử lý lỗi dán dữ liệu thông minh)
    const btnPasteMa = document.getElementById('dvcqg-btn-paste-ma');
    if (btnPasteMa) {
      btnPasteMa.addEventListener('click', async () => {
        let text = '';
        try {
          text = await navigator.clipboard.readText();
        } catch (err) {
          // Fallback khi trình duyệt chặn clipboard: focus và thử paste hoặc prompt
          textareaMa.focus();
          try {
            document.execCommand('paste');
            text = textareaMa.value;
          } catch (e2) {}
          if (!text) {
            text = prompt('Vui lòng dán danh sách mã hồ sơ vào ô dưới đây (Ctrl+V hoặc Cmd+V):') || '';
          }
        }

        if (text && text.trim()) {
          // Trích xuất mã hồ sơ sạch từ văn bản dán vào (tự động loại bỏ các cột ngày tháng, STT, trạng thái rác)
          const extractedCodes = parseMaHoSoList(text);
          if (extractedCodes.length > 0) {
            const currentList = parseMaHoSoList(textareaMa.value);
            const combined = Array.from(new Set([...currentList, ...extractedCodes]));
            const updated = combined.join('\n');
            textareaMa.value = updated;
            state.config.maHoSoListText = updated;
            updateMaCount();
            autoSelectInitialDateFromMaHoSo(true);
            saveConfig();
            log(`✓ Đã dán thành công ${extractedCodes.length} mã hồ sơ hợp lệ vào danh sách!`, 'success');
          } else {
            const current = textareaMa.value.trim();
            const updated = current ? `${current}\n${text.trim()}` : text.trim();
            textareaMa.value = updated;
            state.config.maHoSoListText = updated;
            updateMaCount();
            autoSelectInitialDateFromMaHoSo(true);
            saveConfig();
            log('✓ Đã dán nội dung vào danh sách mã hồ sơ!', 'success');
          }
        } else {
          log('Clipboard hiện đang trống hoặc chưa được cấp quyền đọc!', 'warn');
        }
      });
    }


    // Clear MaHoSo list
    document.getElementById('dvcqg-btn-clear-ma')?.addEventListener('click', () => {
      textareaMa.value = '';
      state.config.maHoSoListText = '';
      updateMaCount();
      saveConfig();
      log('🗑️ Đã xóa toàn bộ danh sách mã hồ sơ.', 'info');
    });

    // Dates
    const inputFrom = document.getElementById('dvcqg-input-from');
    const inputTo = document.getElementById('dvcqg-input-to');

    inputFrom.addEventListener('change', (e) => {
      state.config.fromDate = e.target.value;
      if (e.target.value) {
        const fromD = new Date(e.target.value);
        if (!isNaN(fromD.getTime())) {
          const endOfMonth = new Date(fromD.getFullYear(), fromD.getMonth() + 1, 0);
          const currentTo = state.config.toDate ? new Date(state.config.toDate) : null;
          // Nếu Đến ngày chưa có hoặc đang vượt sang tháng khác, tự động điều chỉnh tối đa trong tháng
          if (!currentTo || currentTo.getFullYear() !== fromD.getFullYear() || currentTo.getMonth() !== fromD.getMonth()) {
            const now = new Date();
            let newTo = endOfMonth;
            if (now.getFullYear() === fromD.getFullYear() && now.getMonth() === fromD.getMonth() && now < endOfMonth) {
              newTo = now;
            }
            const newToYmd = formatDateYMD(newTo);
            state.config.toDate = newToYmd;
            if (inputTo) inputTo.value = newToYmd;
            log(`📅 Tự động điều chỉnh Đến ngày theo tháng: ${formatDateDMY(newTo)} (tối đa trong tháng)`, 'info');
          }
        }
      }
      saveConfig();
    });

    inputTo.addEventListener('change', (e) => {
      state.config.toDate = e.target.value;
      saveConfig();
    });

    // Preset date buttons
    document.querySelectorAll('.dvcqg-preset-btn[data-preset]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const preset = btn.dataset.preset;
        const now = new Date();
        let toStr = formatDateYMD(now);
        let fromStr = toStr;

        if (preset === 'by-ma') {
          const success = autoSelectInitialDateFromMaHoSo(true);
          if (!success) {
            log('⚠️ Chưa có mã hồ sơ hoặc không tìm thấy định dạng ngày trong mã!', 'warn');
          }
          return;
        } else if (preset === 'this-month') {
          const startM = new Date(now.getFullYear(), now.getMonth(), 1);
          const endM = new Date(now.getFullYear(), now.getMonth() + 1, 0);
          fromStr = formatDateYMD(startM);
          toStr = formatDateYMD(endM);
        } else if (preset === 'today') {
          fromStr = toStr;
        } else if (preset === '7d') {
          const d = new Date();
          d.setDate(d.getDate() - 7);
          fromStr = formatDateYMD(d);
        } else if (preset === '30d') {
          const d = new Date();
          d.setDate(d.getDate() - 30);
          fromStr = formatDateYMD(d);
        } else if (preset === 'ytd') {
          fromStr = `${now.getFullYear()}-01-01`;
        }

        inputFrom.value = fromStr;
        inputTo.value = toStr;
        state.config.fromDate = fromStr;
        state.config.toDate = toStr;
        saveConfig();
        log(`Đặt khoảng ngày: ${formatDateDMY(fromStr)} -> ${formatDateDMY(toStr)}`, 'info');
      });
    });

    // Checkboxes
    ['KhoiTaoHoSoBN', 'TiepNhanHoSoBN', 'CapNhatTienTrinhXuLyHoSoBN', 'TaoYeuCauThucHienNghiaVuTaiChinhBN', 'DongBoThongTinThanhToanBN', 'TraKetQuaBN'].forEach(k => {
      const cb = document.getElementById(`st-${k}`);
      if (cb) {
        cb.addEventListener('change', (e) => {
          if (k === 'KhoiTaoHoSoBN') {
            state.config.selectedStatuses.KhoiTaoHoSoBN = true;
            cb.checked = true;
          } else {
            state.config.selectedStatuses[k] = e.target.checked;
          }
          saveConfig();
        });
      }
    });

    const checkOnlyCompleted = document.getElementById('dvcqg-check-only-completed');
    if (checkOnlyCompleted) {
      checkOnlyCompleted.addEventListener('change', (e) => {
        state.config.onlyCompleted = e.target.checked;
        saveConfig();
        log(`Bộ lọc: ${e.target.checked ? 'Bật' : 'Tắt'} chế độ chỉ lấy COMPLETED`, 'info');
      });
    }

    const checkDeduplicate = document.getElementById('dvcqg-check-deduplicate');
    if (checkDeduplicate) {
      checkDeduplicate.addEventListener('change', (e) => {
        state.config.deduplicateStatus = e.target.checked;
        saveConfig();
        log(`Tránh lấy lặp trạng thái: ${e.target.checked ? 'Bật (mỗi trạng thái chỉ lấy 1 khối duy nhất)' : 'Tắt'}`, 'info');
      });
    }

    const checkSmartDate = document.getElementById('dvcqg-check-smart-date');
    if (checkSmartDate) {
      checkSmartDate.addEventListener('change', (e) => {
        state.config.smartDateSearch = e.target.checked;
        saveConfig();
        log(`Tìm kiếm ngày thông minh: ${e.target.checked ? 'Bật (quét qua tháng nếu thiếu TraKetQuaBN)' : 'Tắt (dùng khoảng ngày chỉ định)'}`, 'info');
      });
    }

    const selectSearchDepth = document.getElementById('dvcqg-select-search-depth');
    if (selectSearchDepth) {
      selectSearchDepth.addEventListener('change', (e) => {
        const val = parseInt(e.target.value, 10) || 3;
        state.config.searchDepthMonths = val;
        saveConfig();
        log(`⚙️ Đã thiết lập độ sâu rà soát: tối đa ${val} tháng sau đó.`, 'info');
      });
    }

    const selectMaxPages = document.getElementById('dvcqg-select-max-pages');
    if (selectMaxPages) {
      selectMaxPages.addEventListener('change', (e) => {
        const val = parseInt(e.target.value, 10) || 3;
        state.config.maxPagesPerSearch = val;
        saveConfig();
        log(`⚙️ Đã thiết lập qua tối đa: ${val} trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp.`, 'info');
      });
    }

    const checkAutoTransfer = document.getElementById('dvcqg-check-autotransfer');
    checkAutoTransfer.addEventListener('change', (e) => {
      state.config.autoTransfer = e.target.checked;
      saveConfig();
    });

    // Actions
    document.getElementById('dvcqg-btn-run').addEventListener('click', executeAutoFlow);
    document.getElementById('dvcqg-btn-direct').addEventListener('click', executeCurrentTableExtract);

    // Stop button
    document.getElementById('dvcqg-btn-stop').addEventListener('click', () => {
      state.isStopping = true;
      log('Đang yêu cầu dừng tiến trình sau hồ sơ hiện tại...', 'warn');
      const stopBtn = document.getElementById('dvcqg-btn-stop');
      if (stopBtn) {
        stopBtn.disabled = true;
        stopBtn.innerHTML = '<span>⏳ Đang dừng...</span>';
      }
    });

    document.getElementById('dvcqg-btn-send-manual').addEventListener('click', () => {
      if (!state.lastExtractedCombined) {
        alert('Chưa có dữ liệu XML nào! Vui lòng trích xuất trước.');
        return;
      }
      transferDataToRasoat(state.lastExtractedCombined, 'Nhiều hồ sơ', state.config.fromDate, state.config.toDate);
    });

    document.getElementById('dvcqg-btn-preview').addEventListener('click', showXmlPreviewModal);
  }

  function saveConfig() {
    chrome.storage.local.set({ dvcqg_config: state.config });
  }

  // XML Preview Modal
  function showXmlPreviewModal() {
    const existing = document.getElementById('dvcqg-preview-modal');
    if (existing) existing.remove();

    const xml = state.lastExtractedCombined || 'Chưa có khối XML nào được trích xuất.';

    const modal = document.createElement('div');
    modal.id = 'dvcqg-preview-modal';
    modal.className = 'dvcqg-modal-overlay';
    modal.innerHTML = `
      <div class="dvcqg-modal-card">
        <div class="dvcqg-modal-header">
          <span style="font-weight: bold;">Xem trước Request Body XML (${state.extractedXmlBlocks.length} khối)</span>
          <button id="dvcqg-modal-close" class="dvcqg-icon-btn">✕</button>
        </div>
        <div class="dvcqg-modal-body">
          <textarea readonly class="dvcqg-modal-textarea">${xml.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</textarea>
        </div>
        <div class="dvcqg-modal-footer">
          <button id="dvcqg-modal-copy" class="dvcqg-btn-secondary" style="width: auto;">📋 Sao chép</button>
          <button id="dvcqg-modal-send" class="dvcqg-btn-primary" style="width: auto;">🚀 Gửi sang Rà soát</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    modal.querySelector('#dvcqg-modal-close').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });

    modal.querySelector('#dvcqg-modal-copy').addEventListener('click', () => {
      navigator.clipboard.writeText(xml).then(() => {
        alert('Đã sao chép XML vào clipboard!');
      });
    });

    modal.querySelector('#dvcqg-modal-send').addEventListener('click', () => {
      modal.remove();
      transferDataToRasoat(xml, 'Nhiều hồ sơ', state.config.fromDate, state.config.toDate);
    });
  }

  // Auto-init UI when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildUi);
  } else {
    buildUi();
  }

})();

# Tiện ích Chrome: Auto Check DVCQG

> **Tác giả:** Kyn Chou  
> **Phiên bản:** v2.2.0  
> **Ngày phiên bản:** 10/10/2026  
> **Nền tảng:** Google Chrome Extension (Manifest V3)

Tiện ích mở rộng Google Chrome (Manifest V3) hỗ trợ cán bộ, chuyên viên tự động hóa toàn bộ quy trình tra cứu, trích xuất dữ liệu XML đồng bộ hồ sơ trên Cổng Dịch vụ công Quốc gia (DVCQG) và đối chiếu rà soát dữ liệu tại công cụ kiểm tra đồng bộ.

---

## 📌 Các tính năng chính

1. **Tra cứu thời gian thông minh theo Mã hồ sơ (Bắt đầu từ KhoiTaoHoSoBN, rà quét tiếp đến TraKetQuaBN)**:
   - URL: `https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo`
   - **Tự động nhận diện thời gian từ cấu trúc mã**: Bóc tách chính xác ngày sinh của hồ sơ (ví dụ `H21.117-260812-0008` -> Năm 2026 - Tháng 08 - Ngày 12).
   - **Với KhoiTaoHoSoBN: Ngày bắt đầu và kết thúc lấy theo ngày hồ sơ**:
     - `Từ ngày`: Đặt đúng ngày sinh của mã hồ sơ (`12/08/2026`).
     - `Đến ngày`: Đặt đúng ngày sinh của mã hồ sơ (`12/08/2026`), giúp tra cứu siêu nhanh và lấy chính xác ngay khối trạng thái `KhoiTaoHoSoBN`.
   - **Tiếp tục rà quét thông minh thời gian tiếp theo đến khi tìm thấy TraKetQuaBN**:
     - Đợt 2: Quét phần còn lại của tháng nộp (`13/08/2026` ➜ `31/08/2026`, tối đa trong tháng).
     - Các đợt tiếp theo: Chuyển qua tháng khác với Từ ngày = 01 (ngày đầu tháng), Đến ngày = ngày cuối tháng (hoặc ngày hiện tại). Tuyệt đối không giữ ngày bắt đầu hồ sơ để đảm bảo Cổng DVCQG luôn tìm thấy dữ liệu!
     - **Cơ chế bước đệm thông minh (Safe Bridge Transition)**: Loại bỏ triệt để lỗi lặp ngày cuối tháng của mã hồ sơ khi chuyển tiếp sang tháng kế tiếp. Tự động áp dụng cơ chế bước đệm chuyển giao (thu hẹp Từ ngày = Đến ngày cũ -> Mở đường Đến ngày = 01 tháng mới -> Đặt Từ ngày = 01 tháng mới -> Mở rộng Đến ngày = cuối tháng mới). Tuyệt đối không để xảy ra xung đột ràng buộc `Từ ngày > Đến ngày` hay `Khoảng cách > 30 ngày` khiến trang web hoàn tác/kẹt ngày cũ.
     - **Bảo đảm quét đủ các tháng tiếp theo**: Không bị ngắt sớm giữa chừng, quét trọn vẹn đủ số tháng theo đúng cấu hình độ sâu đã chọn.
   - **Giới hạn thời gian an toàn**: Mỗi đợt tra cứu luôn bảo đảm Đến ngày tối đa trong tháng đó, tuân thủ nghiêm quy định giới hạn 1 tháng của Cổng DVCQG.
     - Tự động nhảy qua các tháng một cách tuần tự và an toàn.
     - Dừng ngay lập tức khi tìm thấy trạng thái kết thúc `TraKetQuaBN` và hoàn tất hồ sơ.
     - Độ sâu rà soát tùy chỉnh: Cho phép điều chỉnh độ sâu linh hoạt từ 1 đến 12 tháng sau (mặc định 3 tháng sau đó) ngay trên giao diện điều khiển.
   - **Nút "🗑️ Xóa" tiện ích**: Xóa trắng toàn bộ danh sách mã hồ sơ nhanh chóng chỉ với 1 click và reset bộ đếm `(0 mã)`.
   - Hỗ trợ nhập danh sách nhiều mã hồ sơ chạy liên tục (Batch mode) với thanh tiến trình và nút Dừng an toàn.

2. **Lấy đầy đủ các bước từ Khởi tạo đến Trả kết quả & Phân trang thông minh**:
   - **Tất cả các hồ sơ kiểm tra BẮT BUỘC phải có giá trị `KhoiTaoHoSoBN` đầu tiên**: Hệ thống đặt `KhoiTaoHoSoBN` làm điều kiện tiên quyết và luôn sắp xếp đứng đầu tiên trong khối XML đồng bộ. Chỉ công nhận hoàn tất chu kỳ khi đã có bước khởi đầu bắt buộc `KhoiTaoHoSoBN` kết hợp với `TraKetQuaBN` (hoặc đủ các bước). Tuyệt đối không dừng sớm khi chưa có `KhoiTaoHoSoBN`!
   - **Cho phép qua tối đa 3 trang nếu chưa tìm thấy trước khi chuyển trạng thái tiếp (bảo vệ trọn vẹn `KhoiTaoHoSoBN`)**: Tự động nhận diện chính xác nút **Trang sau** (`<button class="ant-btn ..."><span class="hidden lg:inline">Trang sau</span></button>`) của Ant Design v5 / DVCQG. Khi trang hiện tại chưa thu thập đủ trạng thái cần thiết (đặc biệt là `KhoiTaoHoSoBN` hoặc `TraKetQuaBN`), hệ thống tự động click chuyển sang trang sau (duyệt tối đa 3 trang), đợi tải bảng trang mới an toàn rồi quét tiếp, giúp không bao giờ bị sót khối `KhoiTaoHoSoBN` nằm ở các trang sau! Nếu sau tối đa 3 trang vẫn chưa đủ, hệ thống sẽ kết thúc đợt và chuyển sang trạng thái/đợt thời gian tiếp theo một cách an toàn.
   - Tự động lọc các bản ghi có trạng thái **COMPLETED** (bỏ qua FAILED, ERROR, PENDING,...).
   - Đảm bảo trích xuất đầy đủ 7 bước nghiệp vụ chuẩn:
     - `1. KhoiTaoHoSoBN` (Khởi tạo hồ sơ - **Bắt buộc đầu tiên**)
     - `2. TiepNhanHoSoBN` (Tiếp nhận hồ sơ)
     - `3. CapNhatTienTrinhXuLyHoSoBN` (Cập nhật tiến trình xử lý hồ sơ)
     - `4. GiaHanXuLyHoSoBN` (Gia hạn xử lý hồ sơ)
     - `5. TaoYeuCauThucHienNghiaVuTaiChinhBN` (Tạo yêu cầu thực hiện nghĩa vụ tài chính)
     - `6. DongBoThongTinThanhToanBN` (Đồng bộ thông tin thanh toán)
     - `7. TraKetQuaBN` (Trả kết quả xử lý hồ sơ)
   - **Hiển thị số step đã thực hiện (Step Tracker)**:
     - Widget theo dõi 7 bước trực quan hiển thị ngay trên bảng điều khiển nổi.
     - Đèn trạng thái chuyển xanh `✓` cho từng bước đã lấy thành công.
     - Badge thông báo tiến độ trực quan: `Đã thực hiện: X/7 steps`.
   - **Chống lấy lặp trạng thái (Deduplication)**: Mỗi trạng thái chỉ lấy duy nhất 1 khối XML chuẩn cho mỗi mã hồ sơ. Tự động bỏ qua các dòng trùng lặp (không tốn thời gian mở modal) và loại bỏ các khối XML trùng nội dung.
   - **Bộ lọc XML nghiêm ngặt**: Chỉ trích xuất đúng khối `<Envelope xmlns="http://dichvucong.gov.vn/api/v1">...</Envelope>` hoặc `<Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">...</Envelope>` (hỗ trợ đầy đủ cả tiền tố khai báo `<?xml version="1.0" encoding="UTF-8"?>`) tại **Request Body** của từng trạng thái (loại bỏ hoàn toàn vỏ bọc SOAP ngoài cùng, HTML/JSON wrapper và các thẻ không liên quan):
     - Cơ chế 1: **Network Interceptor** - Tự động bắt gói tin trực tiếp từ API mạng (tốc độ cao).
     - Cơ chế 2: **DOM Scanner & Modal Trigger** - Tự động click xem chi tiết từng dòng, đọc nội dung Request Body trong modal và đóng modal tuần tự.
   - Tự động sắp xếp các khối XML theo đúng tiến trình xử lý chuẩn (Khởi tạo -> Tiếp nhận -> Tiến trình -> Gia hạn -> Y/c tài chính -> Thanh toán -> Trả kết quả) và ghép thành chuỗi XML liên tiếp.

3. **Tự động Paste dữ liệu vào Form & Kích hoạt Rà soát**:
   - URL: `https://cdn.dnncloud.net/tthc/rasoat.html`
   - **Tự động xóa dữ liệu cũ trước khi phân tích**: Dọn sạch hoàn toàn văn bản XML cũ trong `#src`, ngày báo cáo cũ và ẩn kết quả phân tích cũ trước khi dán dữ liệu mới, đảm bảo kết quả phân tích độc lập và chính xác 100%.
   - **Tự động Paste vào form `#src`**: Sử dụng setter nguyên bản cùng hệ thống sự kiện `input`, `change`, `paste` và `ClipboardEvent` đảm bảo dữ liệu XML luôn được nạp đầy đủ vào form 100%.
   - **Tự động đồng bộ Clipboard**: Tự động sao chép XML vào Clipboard máy tính để bạn có thể dán ở bất cứ đâu.
   - **Nút tiện ích "📋 Tự động dán XML gần nhất"**: Nằm ở góc trái màn hình `rasoat.html`, cho phép tự động dán lại gói tin XML gần nhất bất kỳ lúc nào chỉ với 1 click.
   - **Tự động điền kỳ báo cáo**: Nạp chính xác Từ ngày `#pf` và Đến ngày `#pt`.
   - **Tự động phân tích**: Kích hoạt nút **Phân tích** (`#go`), có cơ chế tự động kiểm tra và retry nếu trang web tải chậm.

4. **Bảng điều khiển nổi thông minh (Floating Widget)**:
   - Hiển thị trực tiếp ở góc dưới bên phải trang Quản trị DVCQG.
   - Bảng theo dõi Step tracker trực quan thời gian thực.
   - Có thể thu nhỏ thành nút nổi tròn hoặc mở rộng.
   - Cửa sổ nhật ký (Live Log) thông báo tiến trình từng bước theo thời gian thực.
   - Cung cấp nút xem trước toàn bộ XML và sao chép vào Clipboard.

---

## 🚀 Hướng dẫn cài đặt vào Google Chrome

### Cách 1: Cài đặt từ thư mục dự án (Developer Mode)
1. Mở trình duyệt **Google Chrome**.
2. Truy cập vào trang quản lý tiện ích:
   ```text
   chrome://extensions/
   ```
3. Bật công tắc **Chế độ dành cho nhà phát triển (Developer mode)** ở góc trên bên phải màn hình.
4. Nhấn vào nút **Tải tiện ích đã giải nén (Load unpacked)** ở góc trên bên trái.
5. Chọn thư mục dự án:
   ```text
   /Volumes/DỮ LIỆU QUAN TRỌNG/WorkSpace/Check HS auto
   ```
6. Tiện ích **DVCQG Auto Sync & Review** sẽ xuất hiện trên danh sách tiện ích của Chrome kèm icon đầy đủ. Bạn nên ghim (Pin) icon tiện ích lên thanh công cụ của Chrome để tiện theo dõi.

### Cách 2: Cài đặt từ gói ZIP đóng gói sẵn (Dành cho máy khác/triển khai nhanh)
1. Sử dụng gói tệp tin đã đóng gói sẵn:
   ```text
   DVCQG-Auto-Sync-v2.2.0.zip
   ```
2. Giải nén file `.zip` vào một thư mục trên máy tính.
3. Truy cập `chrome://extensions/` ➜ Bật **Developer mode** ➜ Bấm **Load unpacked** và chọn thư mục vừa giải nén.
4. Có thể chạy lại lệnh `node generate-assets.js` bất kỳ lúc nào để tự động cập nhật icon và tạo gói ZIP mới nhất.

---

## 📖 Hướng dẫn sử dụng

### Cách 1: Chạy tự động hàng loạt (Batch Auto Flow)

1. Đăng nhập vào trang:
   `https://quantricong.dichvucong.gov.vn/quan-tri-he-thong/tra-cuu-trang-thai-dong-bo`
2. Ở góc phải màn hình, bảng điều khiển **Auto Check DVCQG** sẽ tự động hiển thị:
   - **Danh sách mã hồ sơ**: Dán danh sách các mã hồ sơ cần kiểm tra (mỗi dòng 1 mã, hoặc ngăn cách bằng dấu phẩy). Hỗ trợ dán trực tiếp từ bảng Excel/Web – hệ thống tự động bóc tách mã hồ sơ hợp lệ, loại bỏ các cột rác (STT, ngày tháng, trạng thái). Đồng thời ô **Từ ngày** tự động chọn ngày sinh của mã hồ sơ!
   - **Thời gian tra cứu**: Bấm nút **📅 Theo mã HS** để tự động đặt lại Từ ngày theo mã và Đến ngày tối đa trong tháng. Giữ bật tùy chọn **🧠 Tra cứu thông minh** để hệ thống tự động tìm kiếm từng tháng và tự động chuyển sang tháng tiếp theo nếu còn thiếu trạng thái kết thúc `TraKetQuaBN`.
   - **Theo dõi tiến trình**: Bảng **Tiến trình step** hiển thị trực quan trạng thái **✓ HOÀN THÀNH** cho từng bước nghiệp vụ (`1. Khởi tạo` ➜ `7. Trả kết quả`), số lượng bản ghi tương ứng, thanh mini progress bar và huy hiệu `7/7 steps (HOÀN THÀNH 100%)`.
3. Nhấn nút **▶ Bắt đầu Tự Động**.
4. Tiện ích sẽ tự động thực hiện:
   - Điền mã hồ sơ, tự động điền Từ ngày theo ngày sinh mã vào form tra cứu của DVCQG (hỗ trợ đầy đủ Ant Design / NG-ZORRO / Angular DatePicker).
   - Thanh tiến trình hiển thị: `Hồ sơ X/N (YY%) • X/7 steps [HOÀN THÀNH ✓]`.
   - Sau khi hoàn tất kiểm tra, tiện ích tổng hợp tất cả các khối XML đã trích xuất, chuyển tab sang `rasoat.html` -> Tự động paste an toàn vào ô `#src` -> Tự động kích hoạt Phân tích!

### Cách 2: Trích xuất nhanh từ bảng kết quả đang mở (Manual Search)

1. Nếu bạn đã tự tìm kiếm thủ công trên trang DVCQG và danh sách kết quả đang hiển thị:
2. Nhấn nút **⚡ Trích xuất bảng hiện tại** trên bảng điều khiển nổi.
3. Tiện ích sẽ quét ngay bảng hiện tại, cập nhật bảng step tracker và chuyển sang trang Rà soát.

### Cách 3: Xem trước & Sao chép dữ liệu XML

- Nhấn nút **📋 Xem XML** để mở cửa sổ xem trước toàn bộ các khối XML đã ghép.
- Nhấn **Sao chép** để copy vào bộ nhớ đệm hoặc nhấn **Gửi sang Rà soát** khi cần.

---

## 🛠 Cấu trúc thư mục tiện ích

```text
Auto Click/
├── manifest.json                  # Cấu hình Manifest V3 của Extension
├── background/
│   └── background.js              # Service Worker điều phối tab và dữ liệu rà soát
├── content-scripts/
│   ├── dvcqg-injected.js          # Script can thiệp mạng XHR/Fetch bắt gói tin XML
│   ├── dvcqg-content.js           # Content Script trang DVCQG (Bảng điều khiển & quét DOM)
│   ├── dvcqg-content.css          # Giao diện Bảng điều khiển nổi & Step Tracker
│   ├── rasoat-content.js          # Content Script trang Rà soát (Nhận XML & bấm Phân tích)
│   └── rasoat-content.css         # Thông báo Toast trên trang Rà soát
├── popup/
│   ├── popup.html                 # Giao diện khi bấm vào icon Extension trên thanh công cụ
│   ├── popup.css                  # Style giao diện Popup
│   └── popup.js                   # Xử lý sự kiện Popup
└── README.md                      # Tài liệu hướng dẫn sử dụng
```

---

## 💡 Lưu ý quan trọng
- Tiện ích tuân thủ đầy đủ tiêu chuẩn **Manifest V3** bảo mật cao nhất của Google Chrome.
- Nếu trang DVCQG có thời gian tải lâu do mạng, script đã tích hợp cơ chế chờ linh hoạt và console nhật ký chi tiết để bạn dễ dàng theo dõi trạng thái.

// background.js - Service worker for DVCQG Auto Sync & Review
'use strict';

console.log('[DVCQG Auto SW] Background service worker initialized.');

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message.action === 'TRANSFER_TO_RASOAT') {
        const { xml, maHoSo, fromDate, toDate } = message.data || {};

        // Persist pending data and last extracted data in storage so rasoat-content.js can read on load
        const payload = {
          xml,
          maHoSo,
          fromDate,
          toDate,
          timestamp: Date.now()
        };
        await chrome.storage.local.set({
          pending_rasoat_data: payload,
          last_extracted_xml: payload
        });

        const rasoatPattern = 'https://cdn.dnncloud.net/tthc/rasoat.html*';
        const existingTabs = await chrome.tabs.query({ url: rasoatPattern });

        if (existingTabs.length > 0) {
          const targetTab = existingTabs[0];
          // Bring existing tab and its window to focus
          await chrome.tabs.update(targetTab.id, { active: true });
          if (targetTab.windowId) {
            await chrome.windows.update(targetTab.windowId, { focused: true });
          }

          // Directly notify tab content script to fill and run
          try {
            await chrome.tabs.sendMessage(targetTab.id, {
              action: 'FILL_AND_ANALYZE',
              data: { xml, maHoSo, fromDate, toDate }
            });
          } catch (e) {
            console.log('[DVCQG Auto SW] Message sent, content script will load from storage.');
          }

          sendResponse({ success: true, tabAction: 'updated' });
        } else {
          // Open new tab with rasoat.html
          await chrome.tabs.create({
            url: 'https://cdn.dnncloud.net/tthc/rasoat.html',
            active: true
          });

          sendResponse({ success: true, tabAction: 'created' });
        }
      } else if (message.action === 'GET_PENDING_DATA') {
        const { pending_rasoat_data } = await chrome.storage.local.get('pending_rasoat_data');
        sendResponse({ success: true, data: pending_rasoat_data || null });
      } else {
        sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (err) {
      console.error('[DVCQG Auto SW] Error in message handler:', err);
      sendResponse({ success: false, error: err.message });
    }
  })();

  return true; // Keep message channel open for async response
});

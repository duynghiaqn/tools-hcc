// background.js - Service worker for DVCQG Auto Sync & Review
'use strict';

console.log('[DVCQG Auto SW] Background service worker initialized.');

const DEFAULT_ICON_PATHS = {
  16: 'icons/icon-16.png',
  32: 'icons/icon-32.png',
  48: 'icons/icon-48.png',
  128: 'icons/icon-128.png'
};

// Vẽ icon tiến trình động (vòng tròn % hoặc dấu ✓ hoàn thành) bằng OffscreenCanvas
function createProgressIconImageData(pct, { running = false, done = false } = {}) {
  if (typeof OffscreenCanvas === 'undefined') return null;
  const size = 32;
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  // Nền bo góc
  const r = 7;
  ctx.clearRect(0, 0, size, size);
  ctx.beginPath();
  ctx.moveTo(r, 1);
  ctx.lineTo(size - r, 1);
  ctx.quadraticCurveTo(size - 1, 1, size - 1, r);
  ctx.lineTo(size - 1, size - r);
  ctx.quadraticCurveTo(size - 1, size - 1, size - r, size - 1);
  ctx.lineTo(r, size - 1);
  ctx.quadraticCurveTo(1, size - 1, 1, size - r);
  ctx.lineTo(1, r);
  ctx.quadraticCurveTo(1, 1, r, 1);
  ctx.closePath();

  const grad = ctx.createLinearGradient(0, 0, size, size);
  if (done) {
    grad.addColorStop(0, '#15803d');
    grad.addColorStop(1, '#16a34a');
  } else {
    grad.addColorStop(0, '#0b6e6e');
    grad.addColorStop(1, '#0d9488');
  }
  ctx.fillStyle = grad;
  ctx.fill();

  const cx = size / 2;
  const cy = size / 2;
  const radius = 10.5;

  // Vòng nền mờ
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Vòng tiến trình %
  const clampedPct = done ? 100 : Math.max(0, Math.min(100, Number(pct) || 0));
  if (clampedPct > 0) {
    const startAngle = -Math.PI / 2;
    const endAngle = startAngle + (Math.PI * 2 * (clampedPct / 100));
    ctx.beginPath();
    ctx.arc(cx, cy, radius, startAngle, endAngle);
    ctx.strokeStyle = done ? '#bbf7d0' : '#2dd4bf';
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.stroke();
  }

  // Biểu tượng trung tâm
  if (done) {
    ctx.beginPath();
    ctx.moveTo(10.5, 16.5);
    ctx.lineTo(14.5, 20.5);
    ctx.lineTo(22, 12);
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2.6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
  } else if (running) {
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 9px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(Math.round(clampedPct)), cx, cy + 0.5);
  }

  return ctx.getImageData(0, 0, size, size);
}

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message.action === 'TRANSFER_TO_RASOAT') {
        const { xml, maHoSo, fromDate, toDate, targetUrl } = message.data || {};

        // Xác định URL trang rà soát mục tiêu
        let finalRasoatUrl = targetUrl;
        if (!finalRasoatUrl) {
          const { dvcqg_config } = await chrome.storage.local.get('dvcqg_config');
          finalRasoatUrl = dvcqg_config?.rasoatUrl || 'https://cdn.dnncloud.net/tthc/rasoat.html';
        }

        // Persist pending data and last extracted data in storage so rasoat-content.js can read on load
        const payload = {
          xml,
          maHoSo,
          fromDate,
          toDate,
          targetUrl: finalRasoatUrl,
          timestamp: Date.now()
        };
        await chrome.storage.local.set({
          pending_rasoat_data: payload,
          last_extracted_xml: payload
        });

        // Tìm kiếm các tab rà soát đang mở (cả máy chủ chính và dự phòng hoặc URL mục tiêu)
        const baseUrl = finalRasoatUrl.split('?')[0].split('#')[0];
        const exactTabs = await chrome.tabs.query({ url: `${baseUrl}*` });

        // Tìm thêm bất kỳ tab rà soát nào đang mở
        const anyRasoatTabs = exactTabs.length > 0 ? exactTabs : await chrome.tabs.query({
          url: [
            'https://cdn.dnncloud.net/tthc/rasoat.html*',
            'https://hcc.gialai.gov.vn/tools/rasoat.html*'
          ]
        });

        if (exactTabs.length > 0) {
          const targetTab = exactTabs[0];
          await chrome.tabs.update(targetTab.id, { active: true });
          if (targetTab.windowId) {
            await chrome.windows.update(targetTab.windowId, { focused: true });
          }

          // Directly notify tab content script to fill and run
          let notified = false;
          try {
            const resp = await chrome.tabs.sendMessage(targetTab.id, {
              action: 'FILL_AND_ANALYZE',
              data: { xml, maHoSo, fromDate, toDate }
            });
            if (resp && resp.received) {
              notified = true;
            }
          } catch (e) {
            console.log('[DVCQG Auto SW] Tab direct message failed, attempting dynamic injection...');
          }

          if (!notified) {
            // Tab có thể đã mở trước khi nạp extension hoặc content script bị mất kết nối
            try {
              if (chrome.scripting) {
                await chrome.scripting.insertCSS({
                  target: { tabId: targetTab.id },
                  files: ['content-scripts/rasoat-content.css']
                }).catch(() => {});
                await chrome.scripting.executeScript({
                  target: { tabId: targetTab.id },
                  files: ['content-scripts/rasoat-content.js']
                });
                // Chờ script khởi tạo và gửi lại
                await new Promise((r) => setTimeout(r, 250));
                await chrome.tabs.sendMessage(targetTab.id, {
                  action: 'FILL_AND_ANALYZE',
                  data: { xml, maHoSo, fromDate, toDate }
                }).catch(() => {});
              } else {
                chrome.tabs.reload(targetTab.id).catch(() => {});
              }
            } catch (injErr) {
              console.log('[DVCQG Auto SW] Không thể inject script, reload tab:', injErr.message);
              chrome.tabs.reload(targetTab.id).catch(() => {});
            }
          }

          sendResponse({ success: true, tabAction: 'updated', url: finalRasoatUrl });
        } else if (anyRasoatTabs.length > 0) {
          // Người dùng đã có sẵn tab rà soát khác -> Chuyển hướng tab đó sang URL mục tiêu đã chọn
          const existingTab = anyRasoatTabs[0];
          await chrome.tabs.update(existingTab.id, { url: finalRasoatUrl, active: true });
          if (existingTab.windowId) {
            await chrome.windows.update(existingTab.windowId, { focused: true });
          }
          sendResponse({ success: true, tabAction: 'redirected', url: finalRasoatUrl });
        } else {
          // Open new tab with selected rasoat URL
          const newTab = await chrome.tabs.create({
            url: finalRasoatUrl,
            active: true
          });

          // Hỗ trợ trường hợp URL tùy chỉnh ngoài các match tĩnh: tự động inject content script
          const isKnownDomain = finalRasoatUrl.includes('cdn.dnncloud.net') || finalRasoatUrl.includes('hcc.gialai.gov.vn');
          if (!isKnownDomain && newTab.id && chrome.scripting) {
            const listener = (tabId, changeInfo) => {
              if (tabId === newTab.id && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                chrome.scripting.insertCSS({
                  target: { tabId: newTab.id },
                  files: ['content-scripts/rasoat-content.css']
                }).catch(() => {});
                chrome.scripting.executeScript({
                  target: { tabId: newTab.id },
                  files: ['content-scripts/rasoat-content.js']
                }).catch(() => {});
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          }

          sendResponse({ success: true, tabAction: 'created', url: finalRasoatUrl });
        }
      } else if (message.action === 'GET_PENDING_DATA') {
        const { pending_rasoat_data } = await chrome.storage.local.get('pending_rasoat_data');
        sendResponse({ success: true, data: pending_rasoat_data || null });
      } else if (message.action === 'SYNC_BG_STATUS') {
        const { running, pct, done, foundCount, detailText } = message.data || {};
        const tabId = sender?.tab?.id;
        const tabTarget = tabId ? { tabId } : {};

        if (chrome.action) {
          if (running) {
            const safePct = typeof pct === 'number' ? Math.max(0, Math.min(99, Math.round(pct))) : 0;
            const txt = typeof pct === 'number' ? `${safePct}%` : '...';
            await chrome.action.setBadgeText({ text: txt, ...tabTarget }).catch(() => {});
            await chrome.action.setBadgeBackgroundColor({ color: '#0b6e6e', ...tabTarget }).catch(() => {});
            if (chrome.action.setBadgeTextColor) {
              await chrome.action.setBadgeTextColor({ color: '#FFFFFF', ...tabTarget }).catch(() => {});
            }
            const titleMsg = `Auto Check DVCQG — Đang chạy ${safePct}%${typeof foundCount === 'number' && foundCount > 0 ? ` (${foundCount} HS)` : ''}${detailText ? ` • ${detailText}` : ''}`;
            await chrome.action.setTitle({ title: titleMsg, ...tabTarget }).catch(() => {});

            try {
              const imgData = createProgressIconImageData(safePct, { running: true });
              if (imgData) {
                await chrome.action.setIcon({ imageData: { 32: imgData }, ...tabTarget }).catch(() => {});
              }
            } catch (e) {}
          } else if (done) {
            await chrome.action.setBadgeText({ text: '✓', ...tabTarget }).catch(() => {});
            await chrome.action.setBadgeBackgroundColor({ color: '#15803d', ...tabTarget }).catch(() => {});
            if (chrome.action.setBadgeTextColor) {
              await chrome.action.setBadgeTextColor({ color: '#FFFFFF', ...tabTarget }).catch(() => {});
            }
            const doneTitle = `Auto Check DVCQG — ✅ Hoàn thành 100%${typeof foundCount === 'number' ? ` (${foundCount} HS)` : ''}`;
            await chrome.action.setTitle({ title: doneTitle, ...tabTarget }).catch(() => {});

            try {
              const imgData = createProgressIconImageData(100, { done: true });
              if (imgData) {
                await chrome.action.setIcon({ imageData: { 32: imgData }, ...tabTarget }).catch(() => {});
              }
            } catch (e) {}
          } else {
            await chrome.action.setBadgeText({ text: '', ...tabTarget }).catch(() => {});
            await chrome.action.setTitle({ title: 'Auto Check DVCQG', ...tabTarget }).catch(() => {});
            await chrome.action.setIcon({ path: DEFAULT_ICON_PATHS, ...tabTarget }).catch(() => {});
          }
        }
        sendResponse({ success: true });
      } else if (message.action === 'SYNC_BG_SLEEP') {
        const ms = Math.max(0, Math.min(30000, parseInt(message.ms, 10) || 0));
        await new Promise((resolve) => setTimeout(resolve, ms));
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: 'Unknown action' });
      }
    } catch (err) {
      console.error('[DVCQG Auto SW] Error in message handler:', err);
      sendResponse({ success: false, error: err.message });
    }
  })();

  return true; // Keep message channel open for async response
});

// Kênh Port giữ sống Service Worker & chống Chrome đóng băng/ngủ đông tab DVCQG khi chạy nền
const activeKeepAlivePorts = new Set();

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'dvcqg-bg-keepalive') return;
  activeKeepAlivePorts.add(port);

  const tabId = port.sender?.tab?.id;
  if (tabId && chrome.tabs?.update) {
    chrome.tabs.update(tabId, { autoDiscardable: false }).catch(() => {});
  }

  const pendingTimers = new Map();

  port.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === 'PING') {
      try { port.postMessage({ type: 'PONG', ts: Date.now() }); } catch (e) {}
      return;
    }
    if (msg.type === 'SLEEP' && msg.id !== undefined) {
      const ms = Math.max(0, Math.min(60000, parseInt(msg.ms, 10) || 0));
      const tId = setTimeout(() => {
        pendingTimers.delete(msg.id);
        try {
          port.postMessage({ type: 'SLEEP_DONE', id: msg.id });
        } catch (e) {}
      }, ms);
      pendingTimers.set(msg.id, tId);
    }
  });

  port.onDisconnect.addListener(() => {
    activeKeepAlivePorts.delete(port);
    for (const tId of pendingTimers.values()) {
      clearTimeout(tId);
    }
    pendingTimers.clear();
    if (tabId && chrome.tabs?.update) {
      chrome.tabs.update(tabId, { autoDiscardable: true }).catch(() => {});
    }
  });
});
